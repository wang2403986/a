package soft3d;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.util.Arrays;
import java.util.List;

import static soft3d.Vec3.cross;
import static soft3d.Vec3.normalize;
import static soft3d.shader.SimpleVertexShader.vertex_shading;
import static soft3d.shader.SimpleFragmentShader.frag_shading;
//import static soft3d.shader.DepthPeelingFragmentShader.fragShader;

@Deprecated
public class SoftGraphics3D {
	public static int height;
	public static int width;
	/**
	 * ����Lighting
	 */
	public static boolean LIGHT_ON = false;
	/**
	 * ��Ȳ���
	 */
	public static boolean DEPTH_TEST = true;
	public static final short ALWAYS = 0, LESS = 1, EQUAL = 2;
	public static final short LEQUAL = 3, GREATER = 4;
	/**
	 * Specifies the depth comparison function
	 */
	public static short DepthFunc = LESS;
	/**
	 * ����Texture
	 */
	public static boolean TEXTURE_ON = true;
	/**
	 * �������
	 */
	public static boolean ALPHA_BLENDING = false;
	/**
	 * Rough blending revision(���Ե�͸������)
	 */
	public static boolean BLENDING_REVISE = false;
	public static short REVISE_FUNC = 0x0;

	public static short BLEND_FUNC = 1;
	public static final short SRCA_AND_ONE = 0, SRCA_AND_ONE_MINUS_SRCA = 1,
			ONE_MINUS_DST_AND_ONE = 2, DSTA_AND_ONE = 3;

	public static short BLEND_EQUATION = 0;
	public static final short FUNC_ADD = 0, FUNC_SUBTRACT = 1;
	/**
	 * Alpha���Բ���ֵ(��������alphaֵ���ڻ���ڲ���ֵ��ͨ��)
	 */
	public static int AlphaGreater = 16;
	/**
	 * Alpha���Բ���ֵ(��������alphaֵ�Ȳ���ֵС��ͨ��)
	 */
	public static int AlphaLess = 258;
	/**
	 * AlphaֵС�ڸ�ֵ����(blending when alpha less than this value)
	 */
	public static int BlendingLess = 240;// 240,240
	/**
	 * ���������ع���
	 */
	public static boolean PreferPerPixelLighting = false;
	public static boolean LINEAR_FILTER = false;
	/**
	 * д����Ȼ���
	 */
	public static boolean DEPTH_MASK = true;
	public static boolean CULL_BACK_FACE = false, CULL_FRONT_FACE;
	/**
	 * ͸�ӽ���,z�Ḻ�����ϵ�һ����
	 */
	public static float focusZ = -256;// focusZ = -256,screenZ = -240
	/**
	 * ͶӰƽ��
	 */
	public static float screenZ = -240;
	/**
	 * ��ͼTexture
	 */
	public static Texture texture;
	public static List<Texture> textureList;
	/**
	 * �����б�
	 */
	public Material[] materials;
	/**
	 * ����任
	 */
	public static final float[][] transform = { { 1, 0, 0, 0 }, { 0, 1, 0, 0 },
			{ 0, 0, 1, 0 }, { 0, 0, 0, 1 } };
	/**
	 * ����
	 */
	public int[] pixels;
	/**
	 * ZBuffer
	 */
	public float[] zbuffer;
	/**
	 * �ɰ建���� Stencil buffer
	 */
	public float[] stencil, blend_stencil;
	/**
	 * ���ڻ��Ƶ�ͼƬԴ
	 */
	BufferedImage image = null;
	Graphics graphics2D, bufferedGraphics;

	/**
	 * ����SoftGraphics3D
	 * 
	 * @param graphics2d
	 *            java.awt.Graphics���Ƶ�����
	 * @param w
	 *            ��
	 * @param h
	 *            ��
	 */
	public SoftGraphics3D(Graphics graphics2d, int w, int h) {
		this.graphics2D = graphics2d;
		resize(w, h);
	}
	public void resize(int w, int h) {
		width = w;
		height = h;
		zbuffer = new float[h * w];
		if (BLENDING_REVISE)
			blend_stencil = new float[h * w];
		image = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
		bufferedGraphics = image.createGraphics();
	}
	public final boolean visible(Rectangle screenRect) {
		int leftX = screenRect.x, topY = screenRect.y;
		int rectWidth = screenRect.width;
		int rectHeight = screenRect.height;
		int rightX = leftX + rectWidth;
		int bottomY = topY + rectHeight;
		boolean outside = rectWidth < 1 || rectHeight < 1 || rightX < 0
				|| leftX > width || bottomY < 0 || topY > height;
		return !outside;
	}

	/**
	 * �����������б�TRIANGLE_LIST
	 * 
	 * @param vertices
	 *            ����
	 * @param indices
	 *            ��������
	 * @param uvs
	 *            ��ͼ����
	 * @param normals
	 *            ���㷨��
	 * @param screenBuf
	 *            ��Ļ���껺��(2D)
	 * @param faceMaterials
	 *            ��������(��)
	 */
	public final void drawTriangleList(float[] vertices, int[] indices,
			float[] uvs, float[] normals, float[] screenBuf, int[] faceMaterials) {
		boolean texState = TEXTURE_ON;
		boolean lightState = LIGHT_ON;
		boolean hasUvs = texState && uvs != null;
		boolean hasNormals = LIGHT_ON && normals != null;
		boolean hasMaterial = materials != null && faceMaterials != null;
		boolean hasTexList = faceMaterials != null && textureList != null
				&& hasUvs;
		int off2d0, off2d1, off2d2, offset0, offset1, offset2;
		int maxNum = hasTexList ? textureList.size() - 1 : 0;
		Vertex v1 = pointA, v2 = pointB, v3 = pointC;
		int faceIndex = 0, texIndex = 0;
		for (int i = 0; i < indices.length; i += 3, faceIndex++) {
			if (hasTexList || hasMaterial)
				texIndex = faceMaterials[faceIndex];
			if (hasMaterial && texIndex < materials.length)
				Light.setMaterial(materials[texIndex]);
			if (hasTexList) {
				int texi = texIndex > maxNum ? maxNum : texIndex;
				texture = textureList.get(texi);
			}
			if (hasUvs && texture != null) {
				TEXTURE_ON = true;
				texWidth = texture.width;
				texData = texture.intData;
			} else
				TEXTURE_ON = false;
			offset0 = indices[i] * 3;
			offset1 = indices[i + 1] * 3;
			offset2 = indices[i + 2] * 3;
			v1.vertex(vertices, offset0);
			v2.vertex(vertices, offset1);
			v3.vertex(vertices, offset2);

			off2d0 = indices[i] << 1;
			off2d1 = indices[i + 1] << 1;
			off2d2 = indices[i + 2] << 1;
			v1.screenCoord(screenBuf[off2d0], screenBuf[off2d0 + 1]);
			v2.screenCoord(screenBuf[off2d1], screenBuf[off2d1 + 1]);
			v3.screenCoord(screenBuf[off2d2], screenBuf[off2d2 + 1]);
			if (!insideViewFrustum() || (CULL_BACK_FACE && isBackFace())
					|| (CULL_FRONT_FACE && !isBackFace()))
				continue;
			if (TEXTURE_ON) {
//				float w1 = texture.widthSub1, h1 = texture.heightSub1;
				float w1 = 1, h1 = 1;
				v1.texCoord(uvs[off2d0] * w1, uvs[off2d0 + 1] * h1);
				v2.texCoord(uvs[off2d1] * w1, uvs[off2d1 + 1] * h1);
				v3.texCoord(uvs[off2d2] * w1, uvs[off2d2 + 1] * h1);
			}
			if (hasNormals) {
				v1.normal(normals, offset0);
				v2.normal(normals, offset1);
				v3.normal(normals, offset2);
			} else if (LIGHT_ON)
				getFaceNormal();// ����ƽ�������
			if (!PreferPerPixelLighting) {
				vertex_shading(v1);
				vertex_shading(v2);
				vertex_shading(v3);
			}
			DrawTriangle();
		}
		LIGHT_ON = lightState;
		TEXTURE_ON = texState;
	}

	private final void getFaceNormal() {
		Vertex v0 = pointA, v1 = pointB, v2 = pointC;
		Vec3 buf1 = buffer1, buf2 = buffer2;
		buf1.x = v1.x - v0.x;
		buf1.y = v1.y - v0.y;
		buf1.z = v1.z - v0.z;
		buf2.x = v2.x - v1.x;
		buf2.y = v2.y - v1.y;
		buf2.z = v2.z - v1.z;
		Vec3 n = v0.n;
		cross(buf1, buf2, n);
		normalize(n);
		v1.normal(n.x, n.y, n.z);
		v2.normal(n.x, n.y, n.z);
	}

	/**
	 * �Ƿ�����׶��֮�� is in Viewing Frustum
	 * 
	 * @return
	 */
	private final boolean insideViewFrustum() {
		Vertex v1 = pointA, v2 = pointB, v3 = pointC;
		int w = width, h = height;
		if (v1.winX < 0f && v2.winX < 0f && v3.winX < 0f)
			return false;
		if (v1.winX >= w && v2.winX >= w && v3.winX >= w)
			return false;
		if (v1.winY < 0f && v2.winY < 0f && v3.winY < 0f)
			return false;
		if (v1.winY >= h && v2.winY >= h && v3.winY >= h)
			return false;
		float near = focusZ+1f, far = screenZ + 1000;
		if (v1.z > far || v2.z > far || v3.z > far)
			return false;
		if (v1.z < near && v2.z < near && v3.z < near)
			return false;
		return true;
	}

	/**
	 * begin Scene
	 */
	public final void beginScene() {
		float[] zbuffer = this.zbuffer;
		int[] pixels = this.pixels;
		int toIndex = zbuffer.length;
		int bgcolor = (255 << 24) | (0 << 16) | (0 << 8) | (0);
		for (int i = 0; i < toIndex; i++) {
			zbuffer[i] = 999999999f;
			pixels[i] = bgcolor;
		}
		if (BLENDING_REVISE) {
			if (blend_stencil == null)
				blend_stencil = new float[height * width];
			Arrays.fill(blend_stencil, 999999999f);
		}
	}
	
	/**
	 * The EndScene method handles the the image using opacity.
	 */
	public final void endScene() {
		final int[] pixels = this.pixels;
		int len = pixels.length;
		int argb;
		if (BLENDING_REVISE || BLEND_FUNC == DSTA_AND_ONE
				|| BLEND_FUNC == ONE_MINUS_DST_AND_ONE)
			for (int i = 0; i < len; i++) {
				argb = pixels[i];
				pixels[i] = -16777216 | argb;
			}
	}

	public void drawString(String str, int x, int y) {
		bufferedGraphics.drawString(str, x, y);
	}

	/**
	 * display
	 */
	public final void present() {
		graphics2D.drawImage(image, 8, 30, Color.black, null);
//		graphics2D.drawImage(image.getScaledInstance(width/2, height/2,BufferedImage .SCALE_SMOOTH), 8, 30, Color.black, null);
	}

	static final Vec3 buffer1 = new Vec3(), buffer2 = new Vec3(),
			buffer3 = new Vec3();
	final Vertex fragment = new Vertex(), color = new Vertex();

	/**
	 * ���㶥�㷨��
	 * 
	 * @param vertices
	 * @param indices
	 * @param normals
	 */
	public static void computeNormals(float[] vertices, int[] indices,
			float[] normals) {
		Arrays.fill(normals, 0f);
		int offs0, offs1, offs2;
		Vec3 vector0 = buffer1, vector1 = buffer2, result = buffer3;
		int length = indices.length;
		for (int i = 0; i < length; i += 3) {
			offs0 = indices[i] * 3;
			offs1 = indices[i + 1] * 3;
			offs2 = indices[i + 2] * 3;
			float v1x = vertices[offs1], v1y = vertices[offs1 + 1], v1z = vertices[offs1 + 2];
			vector0.x = v1x - vertices[offs0];
			vector0.y = v1y - vertices[offs0 + 1];
			vector0.z = v1z - vertices[offs0 + 2];
			vector1.x = vertices[offs2] - v1x;
			vector1.y = vertices[offs2 + 1] - v1y;
			vector1.z = vertices[offs2 + 2] - v1z;
			Vec3.cross(vector0, vector1, result);
			Vec3.normalize(result);
			float resultX = result.x, resultY = result.y, resultZ = result.z;
			normals[offs0] += resultX;
			normals[offs0 + 1] += resultY;
			normals[offs0 + 2] += resultZ;
			normals[offs1] += resultX;
			normals[offs1 + 1] += resultY;
			normals[offs1 + 2] += resultZ;
			normals[offs2] += resultX;
			normals[offs2 + 1] += resultY;
			normals[offs2 + 2] += resultZ;
		}
		Vec3.normalizeAll(normals);
	}

	public static final float scaling = 512;

	public void unProject(Vertex v) {
		float halfW = width >> 1, halfH = height >> 1, z = v.z;
		float recDifZ = 1f / (scaling * (screenZ - focusZ));
		v.x = (v.winX - halfW) * (z - focusZ) * recDifZ;
		v.y = -(v.winY - halfH) * (z - focusZ) * recDifZ;
	}

	public static float[] tmp_w = {};
	/**
	 * ͶӰ�任
	 * 
	 * @param vertices
	 * @param screenXY
	 */
	public final static void project(float[] vertices, float[] screenXY) {
		int len = vertices.length, i = 0, i2d = 0;
		float halfW = width >> 1, halfH = height >> 1;
		float difZ = screenZ - focusZ;
		if (tmp_w.length<len/3) {
//			tmp_w = new float[len/3];
		}
		int j = 0;
		while (i < len) {
			float r = 1, z = vertices[i + 2];
			if (z != focusZ)
				r = difZ / (z - focusZ);
			float ratio = scaling * r;
			screenXY[i2d] = vertices[i] * ratio + halfW;
			/** ����ƽ��ֱ������ϵ��Ϊ����ֱ������ϵ */
			screenXY[i2d + 1] = -vertices[i + 1] * ratio + halfH;
//			tmp_w[j] = 1;
			i += 3;
			i2d += 2;
			j += 1;
		}
	}

	private final Edge edges[] = { new Edge(), new Edge(), new Edge() };

	final void DrawTriangle() {
		Edge[] edges = this.edges;
		// create edges for the triangle
		// �����
		edges[0].newEdge(pointA, pointB);
		edges[1].newEdge(pointB, pointC);
		edges[2].newEdge(pointC, pointA);

		float maxLength = 0;
		int longEdge = 0;

		// find edge with the greatest length in the y axis
		for (int i = 0; i < 3; i++) {
			Edge e = edges[i];
			float length = e.point2.winY - e.point1.winY;
			if (length > maxLength) {
				maxLength = length;
				longEdge = i;
			}
		}

		int shortEdge1 = (longEdge + 1) % 3;
		int shortEdge2 = (longEdge + 2) % 3;

		// draw spans between edges; the long edge can be drawn
		// with the shorter edges to draw the full triangle
		DrawSpansBetweenEdges(edges[longEdge], edges[shortEdge1]);
		DrawSpansBetweenEdges(edges[longEdge], edges[shortEdge2]);
	}

	private final Vertex vertex1 = new Vertex(), vertex2 = new Vertex();
	int texWidth = 0;
	int[] texData = null;

	public static final int gequal(float f) {
		if (f < 0)
			return (int) f;
		int r = (int) f;
		if (r != f)
			r++;
		return r;
	}

	public static final int less(float f) {
		if (f < 0)
			return ((int) f) - 1;
		int r = (int) f;
		if (r == f)
			r--;
		return r;
	}

	/**
	 * ����������֮���ɨ����
	 * 
	 * @param e1
	 * @param e2
	 */
	final void DrawSpansBetweenEdges(Edge e1, Edge e2) {
		boolean perPixelLighting = PreferPerPixelLighting;
		Vertex e1PointA = e1.point1, e1PointB = e1.point2;
		Vertex e2PointA = e2.point1, e2PointB = e2.point2;

		int y1 = gequal(e2PointA.winY), y2 = less(e2PointB.winY);

		if (y1 > y2 || y1 >= height || y2 < 0)
			return;
		if (y1 < 0)
			y1 = 0;
		if (y2 >= height)
			y2 = height - 1;
		// calculate difference between the y coordinates of the first edge
		float e1ydiff = e1PointB.winY - e1PointA.winY;
		if (e1ydiff == 0.0f)
			return;

		// calculate difference between the y coordinates of the second edge
		float e2ydiff = e2PointB.winY - e2PointA.winY;
		if (e2ydiff == 0.0f)
			return;

		// calculate differences
		// ����
		float e1xdiff, e1zdiff, e1udiff, e1vdiff, e1diff1;
		float e1diff2 = 0, e1diff3 = 0, e1diff4 = 0, e1diff5 = 0;
		float e2xdiff, e2zdiff, e2udiff, e2vdiff, e2diff1;
		float e2diff2 = 0, e2diff3 = 0, e2diff4 = 0, e2diff5 = 0;
		e1xdiff = e1PointB.winX - e1PointA.winX;
		e1zdiff = e1PointB.z - e1PointA.z;
		e1udiff = e1PointB.u - e1PointA.u;
		e1vdiff = e1PointB.v - e1PointA.v;
		e2xdiff = e2PointB.winX - e2PointA.winX;
		e2zdiff = e2PointB.z - e2PointA.z;
		e2udiff = e2PointB.u - e2PointA.u;
		e2vdiff = e2PointB.v - e2PointA.v;

		if (perPixelLighting) {
			e1diff1 = e1PointB.nX - e1PointA.nX;
			e1diff2 = e1PointB.nY - e1PointA.nY;
			e1diff3 = e1PointB.nZ - e1PointA.nZ;
			e1diff4 = e1PointB.x - e1PointA.x;
			e1diff5 = e1PointB.y - e1PointA.y;

			e2diff1 = e2PointB.nX - e2PointA.nX;
			e2diff2 = e2PointB.nY - e2PointA.nY;
			e2diff3 = e2PointB.nZ - e2PointA.nZ;
			e2diff4 = e2PointB.x - e2PointA.x;
			e2diff5 = e2PointB.y - e2PointA.y;
		} else {
			e1diff1 = e1PointB.l - e1PointA.l;
			e2diff1 = e2PointB.l - e2PointA.l;
		}

		// calculate step values to increase
		float step1 = 1.0f / e1ydiff;
		float step2 = 1.0f / e2ydiff;

		// loop through the lines between the edges and draw spans
		float e1dy, e2dy, e1dy_step1, e2dy_step2, x1, x2;
		Vertex vertex1 = this.vertex1, vertex2 = this.vertex2;
		Vertex frag = fragment;
		Vec3 normal = frag.n;
		float near = focusZ + 1f;
		for (int y = y1; y <= y2; y++) {
			// create and draw span
			frag.winY = y;
			e1dy = frag.winY - e1PointA.winY;
			e2dy = frag.winY - e2PointA.winY;
			e1dy_step1 = e1dy * step1;
			e2dy_step2 = e2dy * step2;

			x1 = e1PointA.winX + e1xdiff * e1dy_step1;
			x2 = e2PointA.winX + e2xdiff * e2dy_step2;
			// create span;
			// ɨ����
			Vertex spanStart, spanEnd;
			int spanX1, spanX2;
			if (x1 < x2) {
				spanStart = vertex1;
				spanEnd = vertex2;
				spanX1 = gequal(x1);
				spanX2 = less(x2);
			} else {
				spanStart = vertex2;
				spanEnd = vertex1;
				spanX1 = gequal(x2);
				spanX2 = less(x1);
			}
			if (spanX1 > spanX2 || spanX1 >= width || spanX2 < 0)
				continue;
			float xdiff, zdiff, udiff, vdiff, diff1 = 0, diff2 = 0, diff3 = 0, diff4 = 0, diff5 = 0;
			vertex1.winX = x1;
			vertex2.winX = x2;
			// �ر߽��в�ֵ�������ø�����
			vertex1.z = e1PointA.z + e1zdiff * e1dy_step1;
			vertex1.u = e1PointA.u + e1udiff * e1dy_step1;
			vertex1.v = e1PointA.v + e1vdiff * e1dy_step1;
			vertex2.z = e2PointA.z + e2zdiff * e2dy_step2;
			vertex2.u = e2PointA.u + e2udiff * e2dy_step2;
			vertex2.v = e2PointA.v + e2vdiff * e2dy_step2;
			xdiff = spanEnd.winX - spanStart.winX;
			zdiff = spanEnd.z - spanStart.z;
			udiff = spanEnd.u - spanStart.u;
			vdiff = spanEnd.v - spanStart.v;
			if (perPixelLighting) {
				vertex1.nX = e1PointA.nX + e1diff1 * e1dy_step1;
				vertex1.nY = e1PointA.nY + e1diff2 * e1dy_step1;
				vertex1.nZ = e1PointA.nZ + e1diff3 * e1dy_step1;
				vertex1.x = e1PointA.x + e1diff4 * e1dy_step1;
				vertex1.y = e1PointA.y + e1diff5 * e1dy_step1;
				vertex2.nX = e2PointA.nX + e2diff1 * e2dy_step2;
				vertex2.nY = e2PointA.nY + e2diff2 * e2dy_step2;
				vertex2.nZ = e2PointA.nZ + e2diff3 * e2dy_step2;
				vertex2.x = e2PointA.x + e2diff4 * e2dy_step2;
				vertex2.y = e2PointA.y + e2diff5 * e2dy_step2;
				diff1 = spanEnd.nX - spanStart.nX;
				diff2 = spanEnd.nY - spanStart.nY;
				diff3 = spanEnd.nZ - spanStart.nZ;
				diff4 = spanEnd.x - spanStart.x;
				diff5 = spanEnd.y - spanStart.y;
			} else {
				vertex1.l = e1PointA.l + e1diff1 * e1dy_step1;
				vertex2.l = e2PointA.l + e2diff1 * e2dy_step2;
				diff1 = spanEnd.l - spanStart.l;
			}

			float step = xdiff == 0f ? 0f : 1.0f / xdiff;
			if (spanX1 < 0)
				spanX1 = 0;
			if (spanX2 >= width)
				spanX2 = width - 1;
			// draw each pixel in the span
			float dx_step, z;
			int x, a = 255, pxIndex;
			for (x = spanX1; x <= spanX2; x++) {
				pxIndex = y * width + x;
				dx_step = (x - spanStart.winX) * step;
				frag.u = spanStart.u + udiff * dx_step;
				frag.v = spanStart.v + vdiff * dx_step;
//				z = spanStart.z + zdiff * dx_step;
//				int texOff=(int) (texture.heightSub1*frag.v)*texWidth+(int)(texture.widthSub1*frag.u);
//				if(z<=zbuffer[pxIndex]){
//				pixels[pxIndex]= texData[texOff];
//				zbuffer[pxIndex] = z;
//				}
				frag.winX = x;
				dx_step = (frag.winX - spanStart.winX) * step;
				z = spanStart.z + zdiff * dx_step;
				pxIndex = y * width + x;
				boolean fail = false;
				short func = DepthFunc;
				if (func == LESS)// ��Ȳ���Depth Test
					fail = zbuffer[pxIndex] <= z;
				else if (func == LEQUAL)
					fail = zbuffer[pxIndex] < z;
				else if (func == EQUAL)
					fail = zbuffer[pxIndex] != z;
				else if (func == GREATER)
					fail = zbuffer[pxIndex] >= z;
				if (fail || near >= z)
					continue;
				if (TEXTURE_ON) {
					frag.u = spanStart.u + udiff * dx_step;
					frag.v = spanStart.v + vdiff * dx_step;
				} //else
					//frag.setRGB(255, 0, 0, 200);
				if (perPixelLighting) {
					normal.x = spanStart.nX + diff1 * dx_step;
					normal.y = spanStart.nY + diff2 * dx_step;
					normal.z = spanStart.nZ + diff3 * dx_step;
					frag.x = spanStart.x + diff4 * dx_step;
					frag.y = spanStart.y + diff5 * dx_step;
					Vec3.normalize(normal);
				}
				frag.l = spanStart.l + diff1 * dx_step;
				frag.z = z;//int dstColor = pixels[pxIndex];
				/* Fragment Shader */
				int write = 1;
				frag_shading(frag, pxIndex, a, 0);
				a = frag.a;
				if (a < AlphaGreater || a >= AlphaLess)// ͸������Alpha Test
					continue;
				if (a >= BlendingLess || DEPTH_MASK) // д��Z����
					zbuffer[pxIndex] = z;
				if (write == 0)
					continue;
				int r = frag.r, g = frag.g, b = frag.b;
				if (ALPHA_BLENDING) {// �������
					blend(pxIndex, z, a, r, g, b);
				} else {
					pixels[pxIndex] = (a << 24) | (r << 16) | (g << 8) | b;
				}
			}
		}
	}

	final void blend(int pxIndex, float z, int a, int r, int g, int b) {
		int alpha = a;// Դɫ͸����
		if (BLEND_FUNC == DSTA_AND_ONE) {
			int dest_argb = pixels[pxIndex];// ��ȡĿ��ɫ
			alpha = (dest_argb >> 24) & 0xff;// Ŀ��ɫ͸����
			if (alpha <= 2)
				return;
			int dest_r = (dest_argb >> 16) & 0xff;
			int dest_g = (dest_argb >> 8) & 0xff;
			int dest_b = dest_argb & 0xff;
			int a_alpha = a * alpha;
			r = ((r * a_alpha) >> 16) + dest_r;
			g = ((g * a_alpha) >> 16) + dest_g;
			b = ((b * a_alpha) >> 16) + dest_b;
			a = ((255 - a) * alpha) >> 8;
		} else if (BLEND_FUNC == ONE_MINUS_DST_AND_ONE) {// GL_ONE_MINUS_DST_COLOR
			int dest_argb = pixels[pxIndex];// ��ȡĿ��ɫ
			int dest_a = (dest_argb >> 24) & 0xff;// Ŀ��ɫ͸����
			int dest_r = (dest_argb >> 16) & 0xff;
			int dest_g = (dest_argb >> 8) & 0xff;
			int dest_b = dest_argb & 0xff;
			if (BLEND_EQUATION == FUNC_ADD) {
				r = ((r * alpha * (255 - dest_r)) >> 16) + dest_r;
				g = ((g * alpha * (255 - dest_g)) >> 16) + dest_g;
				b = ((b * alpha * (255 - dest_b)) >> 16) + dest_b;
			} else {
				r = -((r * alpha * (dest_r)) >> 16) + dest_r;
				g = -((g * alpha * (dest_g)) >> 16) + dest_g;
				b = -((b * alpha * (dest_b)) >> 16) + dest_b;
			}
			a = ((255 - a) * dest_a) >> 8;
		} else if (BLEND_FUNC == SRCA_AND_ONE) {
			int dest_argb = pixels[pxIndex];// ��ȡĿ��ɫ
			int dest_a = (dest_argb >> 24) & 0xff;// Ŀ��ɫ͸����
			int dest_r = (dest_argb >> 16) & 0xff;
			int dest_g = (dest_argb >> 8) & 0xff;
			int dest_b = dest_argb & 0xff;
			if (BLEND_EQUATION == FUNC_ADD) {
				r = (r * alpha >> 8) + dest_r;
				g = (g * alpha >> 8) + dest_g;
				b = (b * alpha >> 8) + dest_b;
			} else {
				r = -(r * alpha >> 8) + dest_r;
				g = -(g * alpha >> 8) + dest_g;
				b = -(b * alpha >> 8) + dest_b;
			}
			r = r > 255 ? 255 : r<0?0:r;
			g = g > 255 ? 255 : g<0?0:g;
			b = b > 255 ? 255 : b<0?0:b;
			a = ((255 - a) * dest_a) >> 8;
		} else {
			a = 255;
			if (BLENDING_REVISE) {
				if (blend_stencil[pxIndex] < z) {// �ɰ建����Z����
					int dest_argb = pixels[pxIndex];// ��ȡĿ��ɫ
					int dest_a = (dest_argb >> 24) & 0xff;// Ŀ��ɫ͸����
					if (dest_a <= 1)
						return;
					int dest_r = (dest_argb >> 16) & 0xff;
					int dest_g = (dest_argb >> 8) & 0xff;
					int dest_b = dest_argb & 0xff;
					int factor = (alpha * dest_a) >> 8;
					a = ((255 - (alpha >> 1)) * dest_a) >> 8;
					if (REVISE_FUNC == 0x0) {/* ��1�� */
						r = ((r * factor * (255 - dest_r)) >> 16) + dest_r;
						g = ((g * factor * (255 - dest_g)) >> 16) + dest_g;
						b = ((b * factor * (255 - dest_b)) >> 16) + dest_b;
					} else {
						factor = factor >> 1;/* ��2�� */
						int ifactor = (256 - factor);
						r = (r * factor + dest_r * ifactor) >> 8;
						g = (g * factor + dest_g * ifactor) >> 8;
						b = (b * factor + dest_b * ifactor) >> 8;
					}
					pixels[pxIndex] = (a << 24) | (r << 16) | (g << 8) | b;
					return;
				} else {
					a = 255 - alpha;
					blend_stencil[pxIndex] = z;
				}
			}
			if (alpha < 240) {
				int dest_argb = pixels[pxIndex];// ��ȡĿ��ɫ
				int dest_r = (dest_argb >> 16) & 0xff;
				int dest_g = (dest_argb >> 8) & 0xff;
				int dest_b = dest_argb & 0xff;
				int ialpha = 256 - alpha;
				r = (r * alpha + dest_r * ialpha) >> 8;
				g = (g * alpha + dest_g * ialpha) >> 8;
				b = (b * alpha + dest_b * ialpha) >> 8;
			}
		}
		pixels[pxIndex] = (a << 24) | (r << 16) | (g << 8) | b;
	}

	final Vertex pointA = new Vertex(), pointB = new Vertex(),
			pointC = new Vertex();

	private final boolean isBackFace() {
		// �� http://www.jurjans.lv/flash/shape.html
		float cax = pointC.winX - pointA.winX;
		float cay = pointC.winY - pointA.winY;
		float bcx = pointB.winX - pointC.winX;
		float bcy = pointB.winY - pointC.winY;
		return cax * bcy > cay * bcx;
	}

	/**
	 * Rectangle in screen Space
	 * 
	 * @param screenPoints
	 * @param rect
	 * @return
	 */
	public static void getBounds(float[] screenPoints, Rectangle rect) {
		rect.width = rect.height = 0;
		if (screenPoints != null && screenPoints.length > 1) {
		float minX = screenPoints[0], minY = screenPoints[1];
		float maxX = minX, maxY = minY;
		int len = screenPoints.length;
		for (int i = 0; i < len; i += 2) {
			float x = screenPoints[i], y = screenPoints[i + 1];
			if (x < minX) {
				minX = x;
			} else if (x > maxX)
				maxX = x;
			if (y < minY) {
				minY = y;
			} else if (y > maxY)
				maxY = y;
		}
		rect.x = (int) minX;
		rect.y = (int) minY;
		rect.width = (int) (maxX - minX);
		rect.height = (int) (maxY - minY);
		}
	}

	/**
	 * ��Edge
	 * 
	 * @author Administrator
	 * 
	 */
	public static final class Edge {
		public Vertex point1, point2;

		public final void newEdge(Vertex element1, Vertex element2) {
			if (element1.winY < element2.winY) {
				point1 = element1;
				point2 = element2;
			} else {
				point2 = element1;
				point1 = element2;
			}
		}
	}

	public static final class Vertex {
		public float winX, winY, x, y, z, u, v, l, nX, nY, nZ, d;
		public Vec3 n = new Vec3();// float la, lr, lg, lb;
		public int a, r, g, b; // int finalX,finalY;

		public final void setRGB(int a, int r, int g, int b) {
			this.a = a;
			this.r = r;
			this.g = g;
			this.b = b;
		}

		public final void vertex(float x, float y, float z) {
			this.x = x;
			this.y = y;
			this.z = z;
		}

		public final void screenCoord(float x, float y) {
			winX = x;
			winY = y;
		}

		public final void vertex(float[] src, int offset) {
			x = src[offset];
			y = src[offset + 1];
			z = src[offset + 2];
		}

		public final void texCoord(float u, float v) {
			this.u = u;
			this.v = v;
		}

		public final void normal(float x, float y, float z) {
			nX = x;
			nY = y;
			nZ = z;
			Vec3 vec3 = n;
			vec3.x = x;
			vec3.y = y;
			vec3.z = z;
		}

		public final void normal(float[] src, int offset) {
			float x = src[offset], y = src[offset + 1], z = src[offset + 2];
			normal(x, y, z);
		}
	}
}
