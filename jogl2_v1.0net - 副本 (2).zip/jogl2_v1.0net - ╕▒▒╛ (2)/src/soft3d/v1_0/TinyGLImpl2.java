package soft3d.v1_0;

import static soft3d.v1_0.GLM.*;
import static soft3d.util.math.FastMath.powf;
import soft3d.v0_1.SoftGraphics3DV0_1;
import soft3d.v1_0.compiler.types.*;

public class TinyGLImpl2 extends TinyGL {
	private float[] VSOutputBuffers = new float[1024*1024];
	static final boolean bebug=false;
	public TinyGLImpl2(){
//__init();
uniforms= new Object[0];
	}
	@Override
	public void glDrawElements(int mode, int count, int type, int[] indices) {
		// TODO
		if(bebug) System.out.println("glDrawElements");
		vec4 vertex0 = new vec4(), vertex1 = new vec4(), vertex2 = new vec4();
		final VertexAttribPointer[] vertexAttribPointers = TinyGL.vertexAttribPointers;
		int sizeOfVSOutput = 3;// x,y,w,l
//__sizeOfVSOutput();
sizeOfVSOutput = 4;
		VertexAttribPointer attribPointer0 = vertexAttribPointers[0];
		if (attribPointer0==null||attribPointer0.data==null){
			System.err.println();
		}
		int numberOfElements = attribPointer0.data.length / attribPointer0.size;
		if (numberOfElements * sizeOfVSOutput > VSOutputBuffers.length) {
			VSOutputBuffers = new float[numberOfElements * sizeOfVSOutput];
		}
		final float[] VSOutputBuffers = this.VSOutputBuffers;
		int outputId = 0;
		float gl_Position_0 = 0, gl_Position_1 = 0, gl_Position_2 = 0;
		for (int i = 0; i < numberOfElements; i++) {
			int i0 = i, offset0;
			attribPointer0 = vertexAttribPointers[0];
			offset0 = i0 * attribPointer0.size + attribPointer0.offset;
			gl_Position_0 = attribPointer0.data[offset0];
			gl_Position_1 = attribPointer0.data[offset0 + 1];
			gl_Position_2 = attribPointer0.data[offset0 + 2];
			vec4 gl_Position= vec4(gl_Position_0, gl_Position_1, gl_Position_2,1.0f);//TODO
//__vertex_shader_begin();
 vec3 position=new vec3();
 vec2 texCoord=new vec2();
 vec3 normal=new vec3();
 float light=0;
attribPointer0 = vertexAttribPointers[0];if(attribPointer0.data!=null){
offset0 = i0*attribPointer0.size+attribPointer0.offset;position.x=attribPointer0.data[offset0+0];position.y=attribPointer0.data[offset0+1];position.z=attribPointer0.data[offset0+2];
}
attribPointer0 = vertexAttribPointers[1];if(attribPointer0.data!=null){
offset0 = i0*attribPointer0.size+attribPointer0.offset;texCoord.x=attribPointer0.data[offset0+0];texCoord.y=attribPointer0.data[offset0+1];
}
attribPointer0 = vertexAttribPointers[2];if(attribPointer0.data!=null){
offset0 = i0*attribPointer0.size+attribPointer0.offset;normal.x=attribPointer0.data[offset0+0];normal.y=attribPointer0.data[offset0+1];normal.z=attribPointer0.data[offset0+2];
}
{gl_Position = vec4(position,1.0f );
gl_Position = mul(GLProjectionMatrix,gl_Position);
vec3 g_LightPos = vec3(- 600f ,0f ,- 1024f );
vec3 g_eyePos = vec3(400f ,0f ,- 800f );
g_LightPos = vec3(0f ,0f ,1000f );
g_eyePos = vec3(400f ,0f ,- 800f );
vec3 L = sub(g_LightPos , position) ;
vec3 V = sub(g_eyePos , g_LightPos) ;
vec3 H = add(L , V );
L = normalize(L );
float g_ambient = 0.1f ;
float saturate = dot(normal ,L );
saturate = saturate < 0f ? 0f :saturate  ;
float diffuse = saturate ;
float specular = powf(saturate ,7 );
light = diffuse * 2 - 1.4f + g_ambient + specular ;
light = light * 100 ;
}
			copy(vertex0, gl_Position);
			//project(vertex0);
			float yScale = height;
			vertex0.w=vertex0.w==0f?1:1/vertex0.w;
			vertex0.x=vertex0.x*vertex0.w*yScale +(width >> 1); vertex0.y=vertex0.y*vertex0.w*yScale +(height >> 1);
//			vertex0.w=vertex0.z==0f?1:1/vertex0.z;
			if(bebug)System.out.println("vertex0::"+vertex0.x +","+vertex0.y+","+vertex0.z);
			
			VSOutputBuffers[outputId++] = vertex0.x;
			VSOutputBuffers[outputId++] = vertex0.y;
			VSOutputBuffers[outputId++] = vertex0.w;
//__vertex_shader_end();
VSOutputBuffers[outputId++]=light;
		}
		for (int i = 0; i < indices.length; i += 3) {
			int i0 = indices[i], i1 = indices[i + 1], i2 = indices[i + 2];
			int offset0, offset1, offset2;
			attribPointer0 = vertexAttribPointers[0];
			offset0 = i0 * attribPointer0.size + attribPointer0.offset;
			offset1 = i1 * attribPointer0.size + attribPointer0.offset;
			offset2 = i2 * attribPointer0.size + attribPointer0.offset;
//			float v0_gl_FragDepth = attribPointer0.data[offset0 + 2];
			int v0_Offset = sizeOfVSOutput * i0, v1_Offset = sizeOfVSOutput * i1,
					v2_Offset = sizeOfVSOutput * i2;
			vertex0.x = VSOutputBuffers[v0_Offset];
			vertex0.y = VSOutputBuffers[v0_Offset + 1];
			vertex1.x = VSOutputBuffers[v1_Offset];
			vertex1.y = VSOutputBuffers[v1_Offset + 1];
			vertex2.x = VSOutputBuffers[v2_Offset];
			vertex2.y = VSOutputBuffers[v2_Offset + 1];
			if (isBackFace(vertex0, vertex1, vertex2))
				continue;
			float v0_gl_FragDepth = VSOutputBuffers[v0_Offset + 2],
					v1_gl_FragDepth = VSOutputBuffers[v1_Offset + 2],
					v2_gl_FragDepth = VSOutputBuffers[v2_Offset + 2];
			if (v0_gl_FragDepth<0||v1_gl_FragDepth<0||v2_gl_FragDepth<0 ) {
				if(bebug)
				System.err.println(v0_gl_FragDepth+","+v1_gl_FragDepth+","+v2_gl_FragDepth+",");
				continue;
			}
			if (v0_gl_FragDepth>100000||v1_gl_FragDepth>100000||v2_gl_FragDepth>100000) {
				if(bebug)
				System.err.println(v0_gl_FragDepth+","+v1_gl_FragDepth+","+v2_gl_FragDepth+",");
				continue;
			}
//__multiplyVSOutput(w);
 vec2 v0_texCoord=new vec2();
 vec2 v1_texCoord=new vec2();
 vec2 v2_texCoord=new vec2();
 float v0_light=0;
 float v1_light=0;
 float v2_light=0;
attribPointer0 = vertexAttribPointers[1];if(attribPointer0.data!=null){
offset0 = i0*attribPointer0.size+attribPointer0.offset;offset1 = i1*attribPointer0.size+attribPointer0.offset;offset2 = i2*attribPointer0.size+attribPointer0.offset;
v0_texCoord.x=attribPointer0.data[offset0 + 0];v0_texCoord.y=attribPointer0.data[offset0 + 1];
v1_texCoord.x=attribPointer0.data[offset1 + 0];v1_texCoord.y=attribPointer0.data[offset1 + 1];
v2_texCoord.x=attribPointer0.data[offset2 + 0];v2_texCoord.y=attribPointer0.data[offset2 + 1];
}
v0_light = VSOutputBuffers[v0_Offset+3];v1_light = VSOutputBuffers[v1_Offset+3];v2_light = VSOutputBuffers[v2_Offset+3];
v0_texCoord.x*=v0_gl_FragDepth;v1_texCoord.x*=v1_gl_FragDepth;v2_texCoord.x*=v2_gl_FragDepth;v0_texCoord.y*=v0_gl_FragDepth;v1_texCoord.y*=v1_gl_FragDepth;v2_texCoord.y*=v2_gl_FragDepth;
v0_light*=v0_gl_FragDepth;v1_light*=v1_gl_FragDepth;v2_light*=v2_gl_FragDepth;
			// Sort vertices by the computed window coordinates.
			vec4 vA = vertex0, vB = vertex1, vC = vertex2;
			if (vB.y < vA.y) {
				vA = vB;
				vB = vertex0;
			}
			if (vC.y < vA.y) {
				vC = vB;
				vB = vA;
				vA = vertex2;
			} else if (vC.y < vB.y) {
				vC = vB;
				vB = vertex2;
			}
			final int iWidth = width, height_1=height - 1;
			final int iWidth_1 = iWidth- 1;
			float y = vA.y,endY = vC.y;
			y = (y < -1) ? -1 : y;
			endY = (endY > height_1) ? height_1 : endY;
			y = (int)(y +1);
			endY = (int)(endY +1)-1;
			
			float midY = vB.y; // Edges : AB-AC, BC-AC
			midY = midY < -1 ? -1 : midY;
			midY = (int)(midY + 1);
			float dY01 = vB.y - vA.y;
			float dY02 = vC.y - vA.y;
			float dY12 = vC.y - vB.y;
			float fStepX0 = (dY01 > 0.0f) ? (vB.x - vA.x) / (dY01) : 0.0f;
			float fStepX1 = (dY02 > 0.0f) ? (vC.x - vA.x) / (dY02) : 0.0f;
			float fStepX2 = (dY12 > 0.0f) ? (vC.x - vB.x) / (dY12) : 0.0f;
			float fX0, fX1, fX2;
			fX0 = (y - vA.y) * fStepX0 + vA.x;
			fX1 = (y - vA.y) * fStepX1 + vA.x;
			fX2 = (midY - vB.y) * fStepX2 + vB.x;
			float fDeltaX0 = vertex1.x - vertex0.x, fDeltaX1 = vertex2.x - vertex0.x;
			float fDeltaY0 = vertex1.y - vertex0.y, fDeltaY1 = vertex2.y - vertex0.y;
			float fCommonGradient = 1.0f / (fDeltaX0 * fDeltaY1 - fDeltaX1 * fDeltaY0);
			float fDelta0, fDelta1, fDdx, fDdy;
			fDelta0 = v1_gl_FragDepth - v0_gl_FragDepth;
			fDelta1 = v2_gl_FragDepth - v0_gl_FragDepth;
			fDdx = (fDelta0 * fDeltaY1 - fDelta1 * fDeltaY0) * fCommonGradient;
			fDdy = -(fDelta0 * fDeltaX1 - fDelta1 * fDeltaX0) * fCommonGradient;
			float ddx_gl_FragDepth = fDdx, ddy_gl_FragDepth = fDdy;
//__ddx_ddy();
 vec2 ddx_texCoord=new vec2();
 vec2 ddy_texCoord=new vec2();
fDelta0 = v1_texCoord.x - v0_texCoord.x;fDelta1 = v2_texCoord.x - v0_texCoord.x;fDdx = (fDelta0 * (fDeltaY1)- fDelta1 * (fDeltaY0)) * (fCommonGradient);fDdy = -(fDelta0 * (fDeltaX1) - fDelta1 * (fDeltaX0)) * (fCommonGradient);ddx_texCoord.x =fDdx;ddy_texCoord.x =fDdy;fDelta0 = v1_texCoord.y - v0_texCoord.y;fDelta1 = v2_texCoord.y - v0_texCoord.y;fDdx = (fDelta0 * (fDeltaY1)- fDelta1 * (fDeltaY0)) * (fCommonGradient);fDdy = -(fDelta0 * (fDeltaX1) - fDelta1 * (fDeltaX0)) * (fCommonGradient);ddx_texCoord.y =fDdx;ddy_texCoord.y =fDdy;
 float ddx_light=0;
 float ddy_light=0;
fDelta0 = v1_light - v0_light;fDelta1 = v2_light - v0_light;fDdx = (fDelta0 * (fDeltaY1)- fDelta1 * (fDeltaY0)) * (fCommonGradient);fDdy = -(fDelta0 * (fDeltaX1) - fDelta1 * (fDeltaX0)) * (fCommonGradient);ddx_light =fDdx;ddy_light =fDdy;
			final float[] depthBuffer = SoftGraphics3DV0_1.zBuffer;//TODO
			final int[] colorBuffer = SoftGraphics3DV0_1.pixels;
			for (; y <= endY; y++, fX0 += fStepX0, fX1 += fStepX1) {
				if (y == midY) {
					fX0 = fX2;
					fStepX0 = fStepX2;
				}
				float start_x, end_x;
				if (fX0 < fX1) {
					start_x = fX0;
					end_x = fX1;
				} else {
					start_x = fX1;
					end_x = fX0;
				}
				if (start_x < -1)
					start_x = -1;
				if (end_x > iWidth_1)
					end_x = iWidth_1;
				int gl_FragCoord0= (int)(start_x+1), gl_FragCoord1 = (int) y;
				int i_end_x = (int)(end_x+1)-1;
				if (gl_FragCoord0 > i_end_x)
					continue;
				int line_y = gl_FragCoord1 * iWidth;
				float fOffsetX = gl_FragCoord0 - vertex0.x;
				float fOffsetY = y - vertex0.y;
				float x0_gl_FragDepth = v0_gl_FragDepth + ddx_gl_FragDepth * fOffsetX + ddy_gl_FragDepth * fOffsetY;
//__x0();
 vec2 x0_texCoord=new vec2();
 float x0_light=0;
x0_texCoord.x = v0_texCoord.x + ddx_texCoord.x * (fOffsetX) + ddy_texCoord.x * (fOffsetY);x0_texCoord.y = v0_texCoord.y + ddx_texCoord.y * (fOffsetX) + ddy_texCoord.y * (fOffsetY);x0_light = v0_light + ddx_light * (fOffsetX) + ddy_light * (fOffsetY);
if (x0_texCoord.x >1||x0_texCoord.x<0 || x0_texCoord.y >1||x0_texCoord.y<0){
	if(bebug) System.err.println("x0_texCoord::"+x0_texCoord.x + ", "+ x0_texCoord.y);
} 
for (; gl_FragCoord0 <= i_end_x; gl_FragCoord0++,
//__add_ddx();
x0_texCoord.x += ddx_texCoord.x,x0_texCoord.y += ddx_texCoord.y,x0_light += ddx_light,
				x0_gl_FragDepth += ddx_gl_FragDepth) {
					float invW = 1.0f / x0_gl_FragDepth;
					int pixelId = line_y + gl_FragCoord0;
					float dstFragDepth = depthBuffer[pixelId];
					float gl_FragDepth = x0_gl_FragDepth;
//__varying();
 vec2 texCoord=new vec2();
 float light=0;
texCoord.x = x0_texCoord.x*invW;texCoord.y = x0_texCoord.y*invW;light = x0_light*invW;
					boolean depth_test_pass = dstFragDepth > gl_FragDepth;
//__depth_test();
gl_FragDepth =invW; depth_test_pass = dstFragDepth > gl_FragDepth;
					if (!depth_test_pass)
						continue;
					boolean gl_Discard = false;
					boolean gl_DepthWriteMask = true;
					ivec4 gl_FragColor= ivec4(255, 0, 0, 255);
//__fragment_shader();
{
	if (texCoord.x >1||texCoord.x<0 || texCoord.y >1||texCoord.y<0){
		if(bebug) System.err.println(texCoord.x + ", "+ texCoord.y);
	} 
	gl_FragColor = texture2D(texture0 ,texCoord );
//	gl_FragColor=ivec4(255, 255, 255, 255);
int iLight = (int )light ;
ivec4 lightColor = ivec4(0 ,iLight ,iLight ,iLight );
gl_FragColor = add(gl_FragColor , lightColor );
gl_FragColor = clamp(gl_FragColor );
}
					if (gl_DepthWriteMask) //
						depthBuffer[pixelId] = gl_FragDepth;// д��Z����
					if (gl_Discard)
						continue;
					colorBuffer[pixelId] = (gl_FragColor.x << 24) | (gl_FragColor.y << 16) | (gl_FragColor.z << 8)
							| gl_FragColor.w;
				}
			}
			primitiveID++;
		}
	}

	private static void copy(vec4 v, vec4 v1) {
		v.x = v1.x ; v.y = v1.y ; v.z = v1.z ; v.w = v1.w ;
	}
//__functionDefs

static vec3 functionName(vec3 position,int arg1,vec3 arg2) {vec3 g_LightPos = vec3(- 600f ,0f ,- 1024f );
vec3 g_eyePos = vec3(400f ,0f ,- 800f );
vec3 L = sub(g_LightPos , position );
vec3 V = sub(g_eyePos , g_LightPos) ;
vec3 H = add(L , V) ;
L = normalize(L );
return L ;
}


}