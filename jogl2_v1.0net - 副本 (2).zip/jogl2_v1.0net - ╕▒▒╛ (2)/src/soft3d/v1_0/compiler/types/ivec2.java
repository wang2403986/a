package soft3d.v1_0.compiler.types;

public final class ivec2 {
	public int x,y;
}
