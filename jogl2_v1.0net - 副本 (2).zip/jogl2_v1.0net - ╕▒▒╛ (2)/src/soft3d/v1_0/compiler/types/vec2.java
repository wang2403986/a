package soft3d.v1_0.compiler.types;

public final class vec2 {
public float x,y;
}
