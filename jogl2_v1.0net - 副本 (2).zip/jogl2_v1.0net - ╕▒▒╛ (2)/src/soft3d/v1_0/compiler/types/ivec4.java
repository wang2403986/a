package soft3d.v1_0.compiler.types;

public final class ivec4 {
	public int x,y,z,w;
}
