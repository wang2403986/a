package soft3d.v1_0.compiler.types;

public final class mat4 {
	public float m00=1,m01,m02,m03;
	public float m10,m11=1,m12,m13;
	public float m20,m21,m22=1,m23;
	public float m30,m31,m32,m33=1;
}
