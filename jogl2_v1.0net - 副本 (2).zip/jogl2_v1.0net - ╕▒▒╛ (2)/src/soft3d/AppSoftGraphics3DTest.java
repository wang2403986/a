package soft3d;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseWheelEvent;
import java.io.IOException;
import java.util.Arrays;

import javax.swing.JFrame;
import javax.swing.Timer;

import loader.xfile.XModel;
import loader.xfile.XModelSerializer;
import soft3d.util.BasicGeometry;
import soft3d.util.Extent;
import soft3d.util.Mesh;
import soft3d.v0_1.SoftGraphics3DV0_1;
import soft3d.v0_1.VertexBuffer;
import soft3d.v1_0.Camera;
import soft3d.v1_0.GLM;
import soft3d.v1_0.Matrix4;
import soft3d.v1_0.TinyGL;
import soft3d.v1_0.TrackballControls;
import soft3d.v1_0.compiler.ShaderCompiler;
import soft3d.v1_0.compiler.types.*;

import static soft3d.Matrix.loadIdentity;
import static soft3d.Matrix.mul;
import static soft3d.Matrix.rotate;
import static soft3d.Matrix.translate;
import static soft3d.SoftGraphics3D.transform;
import static soft3d.v1_0.VertexAttribPointer.*;

public class AppSoftGraphics3DTest extends JFrame implements ActionListener{	
	private static final long serialVersionUID = 1L;
	String folder="D:/Download/anew/models/exp/";//a1-18 a13
	String f0=System.getProperty("user.dir")+"\\models\\";
	String f1="D:/Download/anew/models/models/";//teapot a1 tiny lxq
	String f2="D:/Download/anew/models/tmp/";//a1 a2 a3
	String f3="D:/�û�Ŀ¼/Downloads/Xģ��/";//������ ��ӣ�� Ů�� ��Ů
	String t1="D:/�û�Ŀ¼/Documents/20140822/�����/";
	String f4=t1+"\\model-2014-5\\";//a1-7
	String f5=t1+"\\tmp2\\";//a1-6 teapot teapot1-3
	String f6=t1+"/newModels/";//a1
	String f7="C:/Users/Administrator.USER-20140913MT/Desktop/9-30-model/";
	String f8="C:/Users/Administrator.USER-20140913MT/Desktop/";
//	LoopSubdivision subdivision=new LoopSubdivision();
//	PNTriangles PN=new PNTriangles();
//	PhongTessellation phongTess=new PhongTessellation();
	Mesh mesh1=new Mesh();
	public AppSoftGraphics3DTest() {
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		SoftGraphics3DV0_1.CULL_BACK = true;
		SoftGraphics3DV0_1.LIGHT_ON = true;
//		SoftGraphics3D.LIGHT_ON = true;
		// SoftGraphics3D.PreferPerPixelLighting=true;
		// SoftGraphics3D.TEXTURE_ON=false;
		// SoftGraphics3DV0_1.TEXTURE_ON=false;
		SoftGraphics3DV0_1.ALPHA_BLENDING = false;
		// SoftGraphics3D.ALPHA_BLENDING=true;
		// SoftGraphics3D.BLENDING_REVISE=true;
		SoftGraphics3D.REVISE_FUNC = 0;
		// SoftGraphics3D.DEPTH_MASK=false;
		SoftGraphics3D.BLEND_FUNC = SoftGraphics3D.SRCA_AND_ONE_MINUS_SRCA;
		SoftGraphics3D.CULL_BACK_FACE = true;
		// SoftGraphics3D.LINEAR_FILTER=true;
		folder = f0;
		xfile = "teapot.X";
		init();
		model=new XModelSerializer().importFromFile(folder+xfile);
//		folder=folder+xfile.substring(0, xfile.length()-2)+"/";
		model.loadTexture(folder);
//		model.updateByTime(200);model.calcExtent(extent,true);
		rangeCheck();
//		BasicGeometry.CreateGrid(16, 16,1,1, meshData);
//		BasicGeometry.CreateBox(16, 16, 8, meshData);
//		BasicGeometry.CreateSphere(16,14, 14, meshData);//160
//		BasicGeometry.CreateGrid(200, 200, 8, 8, mesh1);
//		meshData.passConvert();
//		float[][] tmat= new float[4][4];
//		Matrix.translate(0, 16, 0, tmat);
//		Matrix.transform(meshData.vertices, tmat, meshData.vertices);
//		Vec3 lampPos = Vec3.vec3(-60f,0f,-60f);
//		Vec3 lampLookAt = Vec3.vec3(0, 0, 0);
//		ShadowMapShader.LightViewMat(lampPos, lampLookAt, null);
		
//		meshData=MeshData.create(model.frames.get(0).mesh);
//		PN.tessellate(meshData);PN.convertToMesh();
//		phongTess.tessellate(meshData);phongTess.convertToMesh();
//		meshData.creatSimpleMesh2();
//		meshData.passConvert();
//		SoftGraphics3D.computeNormals(meshData.vertices, meshData.indices, meshData.normals);
//		subdivision.loadModel(meshData);//model.frames.get(0).mesh
//		for (int i = 0; i < 4; i++)
//		subdivision.loopSubdivision();
//		subdivision.convertToMesh();
		initGL();
	}
	long frameTime=System.currentTimeMillis();
	int frameCount=0,frameRate=0;
	public void initGL(){
		glBindAttribLocation(0, 0, "position");//position
		glBindAttribLocation(0, 1, "texCoord");//texCoord
		glBindAttribLocation(0, 2, "normal");//normal
		glVertexAttribPointer(0, 3, 0, true, 0, 0);//position
		glVertexAttribPointer(1, 2, 0, true, 0, 0);//texCoord
		glVertexAttribPointer(2, 3, 0, true, 0, 0);//normal
		gl = new soft3d.v1_0.TinyGLImpl2();
//		gl=ShaderCompiler.createProgram("kernels/vertexShader.txt","kernels/fragShader.txt");
		gl.texture0 = SoftGraphics3DV0_1.texture;
		trackball=new TrackballControls(this);
		trackball.handleResize(TinyGL.width, TinyGL.height);
		camera = new  Camera(this);
		camera.reshape(gl.width,gl.height);
	}
	TrackballControls trackball;
	Camera camera;
	protected void render() {
		mat4 idt = new mat4();
		Matrix4.identity(TinyGL.GLProjectionMatrix);
		Matrix4.identity(TinyGL.GLViewMatrix);
		
		Matrix4.perspective(TinyGL.GLProjectionMatrix,45, 1f, 1f, 1000.0f);
		trackball.update();
		vec3 eye=trackball.object.position, target= trackball.object.target,
				up=trackball.object.up;
		Matrix4.lookAt(TinyGL.GLViewMatrix, eye, target, up);
//		camera.update(.1f);
//		Matrix4.copy(TinyGL.GLViewMatrix, camera.view_matrix());
		
//		Matrix4.translate(TinyGL.GLProjectionMatrix, 10, 13, 0);
//		Matrix4.rotateY(TinyGL.GLViewMatrix, (float)Math.toRadians(90));
//		Matrix4.scale(TinyGL.GLViewMatrix, 2, 2, 2);
//		Matrix4.translate(TinyGL.GLViewMatrix, 0, 13, -20);//39 20   13 -10
		Matrix4.copy(transform, TinyGL.GLViewMatrix);//�� (arg2)  ��(arg1),
		SoftGraphics3DV0_1.screenZ=SoftGraphics3D.screenZ;
		SoftGraphics3DV0_1.focusZ=SoftGraphics3D.focusZ;
		if (!isShowing()) {
			return;
		}
		graphics3d.beginScene();
		long time=System.currentTimeMillis()-beginTime;
		model.updateByTime(time<<2);model.draw(gl);
//		meshData.update();

//		graphics3d.LIGHT_ON=false;
//		meshData.draw(graphics3d);
//		graphics3d.flush();
		gl.texture0 = SoftGraphics3DV0_1.texture;
//		gl.faceId=0;
//		glBindBufferData(0, 0, 3, meshData.verticesBuf, 0);//position
//		glBindBufferData(0, 1, 2, meshData.texCoords, 0);//texCoord
//		glBindBufferData(0, 2, 3, meshData.normalsBuf, 0);//normal
//		gl.glDrawElements(0, 0, 0, meshData.indices);
		/*************shadowMap***********/
//		graphics3d.fragPass = shadowMapShader;
//		shadowMapShader.pass=0;
//		shadowMapShader.resize(graphics3d.width, graphics3d.height);
//		graphics3d.WRITE_COLOR = true;
//		graphics3d.LIGHT_ON = false;
//		graphics3d.CULL_FRONT=true;graphics3d.CULL_BACK=false;
//		float[][] save_mat = {{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
//		Matrix.matcopy(transform, save_mat);
//		Matrix.mul(transform ,ShadowMapShader.LightViewMat,transform);
//		meshData.update();meshData.draw(graphics3d);
//		mesh1.update();mesh1.draw(graphics3d);
//		System.arraycopy(graphics3d.zBuffer, 0, shadowMapShader.stencil1, 0, graphics3d.zBuffer.length);
//		shadowMapShader.pass=1;
//		graphics3d.WRITE_COLOR = true;
//		graphics3d.LIGHT_ON = false;
//		graphics3d.CULL_FRONT=false;graphics3d.CULL_BACK=true;
//		Matrix.matcopy(save_mat,transform);
//		Arrays.fill(graphics3d.zBuffer, 999999999f);// -32767f
//		meshData.update();meshData.draw(graphics3d);
//		graphics3d.LIGHT_ON = true;
//		mesh1.update();mesh1.draw(graphics3d);
		/*********************************/
//		subdivision.update();subdivision.draw(graphics3d);
//		PN.update();PN.draw(graphics3d);
//		phongTess.update();phongTess.draw(graphics3d);
//		model.updateByTime(time<<2);multiple_pass();
		if(System.currentTimeMillis()-frameTime>1000){
			frameTime=System.currentTimeMillis();
			frameRate=frameCount;
			frameCount=0;
		}
		frameCount++;
		graphics3d.drawString("����֡�ʣ�"+frameRate, 20,20);
//		graphics3d.endScene();
		graphics3d.present();
		 
	}
	
	public static void main(String[] s) {
		AppSoftGraphics3DTest app=new AppSoftGraphics3DTest();
		app.setVisible(true);
		Timer timer=new Timer(10, app);
		timer.start();
	}
	
	// �����¼�
//	private void formKeyPressed(java.awt.event.KeyEvent evt) {
//		float m_rate=1f/(SoftGraphics3D.screenZ-SoftGraphics3D.focusZ);
//		switch (evt.getKeyCode()) {
//		case KeyEvent.VK_LEFT:
//			ry += 0.1f;
//			break;
//		case KeyEvent.VK_RIGHT:
//			ry -= 0.1f;
//			break;
//		case KeyEvent.VK_UP:
//			rx += 0.1f;
//			break;
//		case KeyEvent.VK_DOWN:
//			rx -= 0.1f;
//			break;
//		case KeyEvent.VK_W:
//			ty += m_rate;
//			break;
//		case KeyEvent.VK_S:
//			ty -= m_rate;
//			break;
//		case KeyEvent.VK_A:
//			tx -= m_rate;
//			break;
//		case KeyEvent.VK_D:
//			tx += m_rate;
//			break;
//		case KeyEvent.VK_X:
//			SoftGraphics3D.screenZ += 10;
//			break;
//		case KeyEvent.VK_Y:
//			SoftGraphics3D.screenZ -= 10;
//			break;
//		case KeyEvent.VK_EQUALS:
//			SoftGraphics3D.focusZ += 1;
//			break;
//		case KeyEvent.VK_MINUS:
//			SoftGraphics3D.focusZ -= 1;
//			break;
//		default:
//			break;
//		}
//	}
//	SoftGraphics3D graphics3d;
	SoftGraphics3DV0_1 graphics3d;
	TinyGL gl=new TinyGL() {
	}; 
//	JOCLSample joclSample;
	void init(){
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(1048, 700);
		this.setVisible(true);
//		graphics3d=new SoftGraphics3D(getGraphics(),1024,680);
		graphics3d=new SoftGraphics3DV0_1(getGraphics(),1024,680);
		SoftGraphics3D.width=1024;SoftGraphics3D.height=680;
		try {
			SoftGraphics3D.texture=new Texture("D:/�û�Ŀ¼/Pictures/a1.bmp");
			SoftGraphics3DV0_1.texture=SoftGraphics3D.texture;
//			joclSample = new JOCLSample();
//			joclSample.CreateBuffer(graphics3d);
//			graphics3d.joclSample=joclSample;
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		//�������¼�
//		addMouseWheelListener(new MouseAdapter() {
//			public void mouseWheelMoved(MouseWheelEvent e) {
//				int num = e.getWheelRotation();
//				synchronized (rendering) {
//					SoftGraphics3D.screenZ += 0.2f * num;
//					rangeCheck();
//				}
//			}
//		});
//		//�����¼�
//		addKeyListener(new java.awt.event.KeyAdapter() {
//			public void keyPressed(java.awt.event.KeyEvent evt) {
//				synchronized (rendering) {
//					formKeyPressed(evt);
//					rangeCheck();
//				}
//			}
//		});
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		render();
	}
	void rangeCheck(){
		
		if (rx > (Math.PI * 2))
			rx = 0;
		if (ry > (Math.PI * 2))
			ry = 0;
//		if(SoftGraphics3D.screenZ-SoftGraphics3D.focusZ<1f)
//			SoftGraphics3D.focusZ=SoftGraphics3D.screenZ-1f;
		SoftGraphics3DV0_1.screenZ=SoftGraphics3D.screenZ;
		SoftGraphics3DV0_1.focusZ=SoftGraphics3D.focusZ;
		loadIdentity(transform);
		if(extent.empty)translate( tx,  ty,0, mat4);
		else
		translate(-extent.centre[0]+tx, -extent.centre[1]+ty, 0, mat4);
		mul(transform, mat4, transform);
		rotate(rx, ry, 0, mat4);
		mul(transform, mat4, transform);
//		Matrix.scale(8, 8, 8, mat4);
//		mul(transform, mat4, transform);
	}
	float rx=0,ry=0,tx=0,ty=0;
	final float[][] mat4 ={{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
	private Object rendering=new Object();
	
	XModel model=null;
	Mesh meshData=new Mesh();
	final Extent extent=new Extent();
	long beginTime=System.currentTimeMillis();
	String xfile="";
	
//	public void multiple_pass() {	
//		graphics3d.blendingLess=240;
//		SoftGraphics3D.DepthFunc=SoftGraphics3D.LEQUAL;
//		SoftGraphics3D.LIGHT_ON=false;
//		SoftGraphics3D.ALPHA_BLENDING=true;
//		SoftGraphics3D.DEPTH_MASK=false;
//		SoftGraphics3D.BLEND_FUNC=SoftGraphics3D.DSTA_AND_ONE;
//		DepthPeelingFragmentShader.clear();
//        pass=pass_find_topmost;
//        completed=true;
//        //pass
//        model.draw(graphics3d);
//        pass=pass_front_to_back;
//        graphics3d.blendingLess=258;
//        float bottomZ=999999999f;
//        int n=5;
//        for (int i = 0; i < n; i++) {
//            completed=true;
//            //pass
//            model.draw(graphics3d);
//          if (completed) {
////        	  System.out.println(i);
//              break;
//          }
//          float[] frontZBuf1=frontZNext;
//          float[] frontZBuf=frontZBuffer;
//          int toIndex=frontZBuf1.length;
//          for (int j = 0; j < toIndex; j++) {
//              frontZBuf[j]=frontZBuf1[j];
//              frontZBuf1[j]=bottomZ;
//          }
//        }
//	}
}
