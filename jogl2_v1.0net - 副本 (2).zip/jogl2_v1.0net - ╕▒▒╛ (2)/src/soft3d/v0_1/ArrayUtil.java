package soft3d.v0_1;

public final class ArrayUtil {

	public static void array_set(float[] array, float v0, float v1, float v2,
			float v3, float v4) {
		array[0] = v0;
		array[1] = v1;
		array[2] = v2;
		array[3] = v3;
		array[4] = v4;
	}

	public static void array_set(float[] array, float v0, float v1, float v2,
			float v3, float v4, float v5) {
		array[0] = v0;
		array[1] = v1;
		array[2] = v2;
		array[3] = v3;
		array[4] = v4;
		array[5] = v5;
	}

	public static void array_set(float[] array, int pos, float v0, float v1,
			float v2, float v3) {
		array[pos] = v0;
		array[pos + 1] = v1;
		array[pos + 2] = v2;
		array[pos + 3] = v3;
	}

	public static void array_set(float[] array, int pos, float v0, float v1,
			float v2) {
		array[pos] = v0;
		array[pos + 1] = v1;
		array[pos + 2] = v2;
	}
}
