package soft3d.v0_1;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.util.Arrays;
import java.util.List;

import soft3d.Light;
import soft3d.Matrix;
import soft3d.SoftGraphics3D;
import soft3d.Texture;
import soft3d.Vec3;
import soft3d.util.SpinLock;
import soft3d.v0_1.RenderBuffer.PixelBuffer;
import static soft3d.v0_1.SoftMath.*;

public class SoftGraphics3DV0_1 {
	public static int height;
	public static int width;
	public static boolean LIGHT_ON = false, DEPTH_TEST = true,
			TEXTURE_ON = true, ALPHA_BLENDING = false, DEPTH_MASK = true,
			CULL_BACK, CULL_FRONT, PER_PIXEL_LIGHT, WRITE_COLOR= true;
	public static int depthFunc = 0, blendEquation = 0;
	public int srcFactor = 0x0, dstFactor = 0x0, srcAlphaFactor = 0x0,
			dstAlphaFactor = 0;
	public int blendFuncAlpha = 0, blendFunc = 0;
	public static boolean BLENDING_REVISE = false;
	public static int reviseFunc = 0x0;
	public static int alphaGreater = 16, alphaLess = 258, blendLess = 240;

	/**
	 * ͸�ӽ���
	 */
	public static float focusZ = -256;// 256
	/**
	 * ͶӰƽ��
	 */
	public static float screenZ = -240;// 255

	public static Texture texture;
	public static List<Texture> textureList;
	public static final float[][] transform = { { 1, 0, 0, 0 }, { 0, 1, 0, 0 },
			{ 0, 0, 1, 0 }, { 0, 0, 0, 1 } };
	public static int[] pixels;
	public static float[] zBuffer;
	public float[] stencil, blend_stencil;
	public static int[] faceIds;
	float[] pRenderBuffer;
	public int sizePerPixel = 4;
	int iRenderedPixels;
	/**
	 * Fragment Parameters
	 */
	public float y, endY;
	/**
	 * �����εĶ���
	 */
	public final Point3D pointA = new Point3D(), pointB = new Point3D(),
			pointC = new Point3D();
	public final Point3D frag = new Point3D();
	/**
	 * ���ڻ��Ƶ�ͼƬԴ
	 */
	BufferedImage image;
	Graphics graphics2D, bufferedGraphics;

	public SoftGraphics3DV0_1(Graphics graphics2d, int w, int h) {
		width = w;
		height = h;
		zBuffer = new float[h * w];
		faceIds = new int[h * w];
		pRenderBuffer = new float[h * w * sizePerPixel];//TODO
		this.graphics2D = graphics2d;
		Matrix.loadIdentity(transform);
		image = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
		bufferedGraphics = image.createGraphics();
	}
	public void resize(int w, int h){
		if (w * h > zBuffer.length || w * h > width * height) {
			zBuffer = new float[h * w];
			faceIds = new int[h * w];
			image = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
			pixels = ((DataBufferInt) image.getRaster().getDataBuffer())
					.getData();
			bufferedGraphics = image.createGraphics();
		}
		width = w;
		height = h;
	}
	public void blend(Point3D color, int pxIndex) {
		int dsta = 0, dstr = 0, dstg = 0, dstb = 0;
		int f_sr = color.r, f_sg = color.g, f_sb = color.b;
		int f_a = 255, f_dr = 0, f_dg = 0, f_db = 0;
		switch (srcFactor) {
		case 0:
			if (color.a < 240)
				break;
			f_sr = color.r * color.a;
			f_sg = color.g * color.a;
			f_sb = color.b * color.a;
			break;
		case 1:
			if (dsta <= 2)
				return;
			f_sr = color.r * color.a * dsta;
			f_sg = color.g * color.a * dsta;
			f_sb = color.b * color.a * dsta;
			break;
		case 2:
			f_sr = color.r * color.a * (256 - dstr);
			f_sg = color.g * color.a * (256 - dstg);
			f_sb = color.b * color.a * (256 - dstb);
			break;
		}
		switch (dstFactor) {
		case 3:
			f_dr = dstr * (256 - color.a);
			f_dg = dstg * (256 - color.a);
			f_db = dstb * (256 - color.a);
			break;
		}
		if (srcAlphaFactor == 1)
			f_a = (256 - color.a) * dsta;
		if (blendEquation == 0)
			color.setRGB(f_a, f_sr + f_dr, f_sg + f_dg, f_sb + f_db);
		else
			color.setRGB(f_a, f_sr - f_dr, f_sg - f_dg, f_sb - f_db);
	}

	public static final void project(Vec3 vertex, float halfW, float halfH) {
//		float halfW = width >> 1, halfH = height >> 1;
		float difZ = screenZ - focusZ;
		float r = 1, z = vertex.z;
		if (z != focusZ)
			r = difZ / (z - focusZ);
		float ratio = 512.0f * r;
		vertex.x = vertex.x * ratio + halfW;
		/** ����ƽ��ֱ������ϵ��Ϊ����ֱ������ϵ */
		vertex.y = -vertex.y * ratio + halfH;
	}
	public final void drawTriangleList(float[] vertices, int[] indices,
			float[] uvs, float[] normals, float[] screenBuf, int[] faceMaterials) {
		Point3D v1 = pointA, v2 = pointB, v3 = pointC;
		boolean lightState = LIGHT_ON;
		boolean textureState = TEXTURE_ON;
		boolean faceMtrl = faceMaterials != null;
		boolean hasUV = textureState && uvs != null;
		boolean hasTexList = faceMtrl && textureList != null && hasUV;
		if (normals == null)
			LIGHT_ON = false;
		int faceIndex = 0;
		
		int off2d0 = 0, off2d1, off2d2, offs0, offs1, offs2;
		
		for (int i = 0; i < indices.length; i += 3, faceIndex++) {
			TEXTURE_ON = false;
			if (hasTexList)
				texture = textureList.get(faceMaterials[faceIndex]);
			if (hasUV && texture != null)
				TEXTURE_ON = true;
//			float[] ws= SoftGraphics3D.tmp_w;
//			v1.w = ws[indices[i]];v2.w = ws[indices[i + 1]];v3.w = ws[indices[i + 2]];
			
			offs0 = indices[i] * 3;
			v1.objX = vertices[offs0];
			v1.objY = vertices[offs0 + 1];
			v1.objZ = vertices[offs0 + 2];
			offs1 = indices[i + 1] * 3;
			v2.objX = vertices[offs1];
			v2.objY = vertices[offs1 + 1];
			v2.objZ = vertices[offs1 + 2];
			offs2 = indices[i + 2] * 3;
			v3.objX = vertices[offs2];
			v3.objY = vertices[offs2 + 1];
			v3.objZ = vertices[offs2 + 2];
			off2d0 = indices[i] << 1;
			v1.winX = screenBuf[off2d0];
			v1.winY = screenBuf[off2d0 + 1];
			off2d1 = indices[i + 1] << 1;
			v2.winX = screenBuf[off2d1];
			v2.winY = screenBuf[off2d1 + 1];
			off2d2 = indices[i + 2] << 1;
			v3.winX = screenBuf[off2d2];
			v3.winY = screenBuf[off2d2 + 1];
			if (!drawPass1() || (CULL_BACK && isBackFace())
					|| (CULL_FRONT && !isBackFace()))
				continue;
			if (TEXTURE_ON) {
				v1.texX = uvs[off2d0];
				v1.texY = uvs[off2d0 + 1];
				v2.texX = uvs[off2d1];
				v2.texY = uvs[off2d1 + 1];
				v3.texX = uvs[off2d2];
				v3.texY = uvs[off2d2 + 1];
			}
			if (LIGHT_ON) {
				v1.nrmX = normals[offs0];
				v1.nrmY = normals[offs0 + 1];
				v1.nrmZ = normals[offs0 + 2];
				v2.nrmX = normals[offs1];
				v2.nrmY = normals[offs1 + 1];
				v2.nrmZ = normals[offs1 + 2];
				v3.nrmX = normals[offs2];
				v3.nrmY = normals[offs2 + 1];
				v3.nrmZ = normals[offs2 + 2];
				lighting();
			}
			fragPass.id = faceIndex;
			drawTriangle();// TODO
		}
		LIGHT_ON = lightState;
		TEXTURE_ON = textureState;
	}
	int[] texData;
	float texWidth;

	public FragPass fragPass=new SimpleFragPass();
	private int maxAttribs = 0;
	public float[] attribute0 = { 0, 0, 0, 0 }, pDdx = { 0, 0, 0, 0 }, pDdy = {
			0, 0, 0, 0 }, vs_output = { 0, 0, 0, 0 },
			ps_input = { 0, 0, 0, 0 }, attribute1 = { 0, 0, 0, 0 },
			attribute2 = { 0, 0, 0, 0 };
	public void setVertexMaxAttribs(int n){
		maxAttribs=n;
		pDdx = new float[n];
		pDdy = new float[n];
		vs_output = new float[n];
		ps_input = new float[n];
		attribute0 = new float[n];
		attribute1= new float[n];
		attribute2=new float[n];
	};
	public void flush(){
//		System.out.println("main thread starting...");  
		  
		Thread[] list = new Thread[4];  
		 int fromIndex=0;
		 int toIndex=width*height/4;
		int add = toIndex;
//		flush(0, width*height);
        for (int i = 0; i < 4; i++)  
        {  
        	final int i0= fromIndex+i*add;
			final int i1=toIndex+i*add;
            Thread my = new Thread(new Runnable() {
				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					SoftGraphics3DV0_1.this.flush(i0,i1);
				}
			});
            my.start();  
            list[i]=(my);  
        }  
  
        try  
        {  
            for (Thread my : list)  
            {  
            	if(my!=null)
                my.join();  
            }  
        }  
        catch (InterruptedException e)  
        {  
            e.printStackTrace();  
        }  
  
//        System.out.println("main thread end...");  
	}
	void flush(int fromIndex, int toIndex){
		Point3D frag  = new Point3D();
		int max = width*height;
		int[] _rgb={0,0,0,0};
		int iRenderedPixels;
		float ps_input[] = pRenderBuffer;
		for (int i = fromIndex; i < toIndex; ++i) {
			iRenderedPixels = i*sizePerPixel;
//			int pxIndex = ((int*)pRenderBuffer)[iRenderedPixels];
			int pxIndex = i;
			
			if (zBuffer[pxIndex]!=999999999f) {

				float u = ps_input[iRenderedPixels+1], v=ps_input[iRenderedPixels+2];
				if (TEXTURE_ON)
				texture.getRGB(u, v, frag);
//				fragPass.passPixel(frag);
//				Math.atan(1.33333);
				if (LIGHT_ON)
					frag.addRGB((int) ps_input[iRenderedPixels+3]);
				if (frag.a < alphaGreater || frag.a >= alphaLess)
					continue;
//				if (DEPTH_MASK || frag.a >= blendLess)//
//					zBuffer[pxIndex] = z;// д��Z����
				if (!WRITE_COLOR)
					continue;
				if (ALPHA_BLENDING) {// Alpha���
					blend(pxIndex, frag);
					pixels[pxIndex] = (frag.a << 24) | (frag.r << 16)
							| (frag.g << 8) | frag.b;
				} else
					pixels[pxIndex] = (255 << 24) | (frag.r << 16)
							| (frag.g << 8) | frag.b;
			}
		}

	}
	
	private static final void add_ddx(float vsoutput[], float pDdx[], int n){
		for (int i = 0; i < n; ++i){
			vsoutput[i] += pDdx[i];
		}
	}
	public final void drawTriangleZPrePass(int faceId) {
		float []attribute0=this.attribute0,
				pDdx=this.pDdx,
				pDdy=this.pDdy,
				vs_output=this.vs_output,
				ps_input=this.ps_input;
		   // Sort vertices by the computed window coordinates.
		   Point3D pV0 = pointA, pV1 = pointB, pV2 = pointC, pT0 = pointA;
		   if (pV1.winY < pV0.winY) {
		    pV0 = pV1;
		    pV1 = pT0;
		   }
		   pT0 = pV2;
		   if (pV2.winY < pV0.winY) {
		    pV2 = pV1;
		    pV1 = pV0;
		    pV0 = pT0;
		   } else if (pV2.winY < pV1.winY) {
		    pV2 = pV1;
		    pV1 = pT0;
		   }
		   Point3D vA = pV0,vB = pV1,vC = pV2;
		   float y = s_floor( vA.winY )+1;
		   float endY =s_floor( vC.winY );
		   if (y<0)y=0;
		   if (endY>=height)endY=height-1;
		   float midY  = vB.winY; // !!! Edges are: AB-AC, BC-AC
		   midY = s_floor(midY) + 1;
		   if(midY<0) midY = 0;
		   float dY01 = vB.winY - vA.winY;
		   float dY02 = vC.winY - vA.winY;
		   float dY12 = vC.winY - vB.winY;
		   float fStepX0 = (dY01> 0.0f) ?
					(vB.winX - vA.winX) / (dY01) : 0.0f;
		float fStepX1 = (dY02> 0.0f) ?
				(vC.winX - vA.winX) / (dY02) : 0.0f;
		float fStepX2 = (dY12> 0.0f) ?
				(vC.winX - vB.winX) / (dY12) : 0.0f;
				float fStepX3= fStepX1;
			float fX0, fX1,fX2,fX3;
			fX0 = (y - vA.winY)*fStepX0+vA.winX;
			fX1 = (y - vA.winY)*fStepX1+vA.winX;
			fX2 = (midY - vB.winY)*fStepX2+vB.winX;
			fX3 = (midY - vA.winY)*fStepX3+vA.winX;
			float f;
		   if (fStepX0>fStepX1) {
			   f =  fX0;
				fX0 = fX1;
				fX1 = f;
				f =  fStepX0;
				fStepX0 = fStepX1;
				fStepX1 = f;
		   }
		   if (fStepX2<fStepX3) {
			    f=  fX2;
				fX2 = fX3;
				fX3 = f;
				f =  fStepX2;
				fStepX2 = fStepX3;
				fStepX3 = f;
		   }
		   Point3D v0=pointA,v1=pointB,v2=pointC;
		   float fDeltaX0=pointB.winX - pointA.winX,fDeltaX1=pointC.winX
					- pointA.winX;
		   float fDeltaY0 = pointB.winY - pointA.winY,fDeltaY1= pointC.winY
					- pointA.winY ;
			float fCommonGradient = 1.0f
					/ (fDeltaX0 * fDeltaY1 - fDeltaX1 * fDeltaY0);
			   final int iNumOutput = 4;
//			   float vsoutput0[] = {v0.objZ, v0.texX, v0.texY, 1};
//			   float vsoutput1[] = {v1.objZ, v1.texX, v1.texY, 1};
//			   float vsoutput2[] = {v2.objZ, v2.texX, v2.texY, 1};
//			   float vsoutput0[] =attribute0,vsoutput1[] =attribute1,vsoutput2[] =attribute2;
//			   vsoutput0[0]=v0.objZ; vsoutput0[1]=v0.texX; vsoutput0[2]=v0.texY; vsoutput0[3]=1;
//			   vsoutput1[0]=v1.objZ; vsoutput1[1]=v1.texX; vsoutput1[2]=v1.texY; vsoutput1[3]=1;
//			   vsoutput2[0]=v2.objZ; vsoutput2[1]=v2.texX; vsoutput2[2]=v2.texY; vsoutput2[3]=1;
//			   for (int i = 0; i < iNumOutput; ++i) {
//				   vsoutput0[i] = vsoutput0[i] * (v0.w);
//				   vsoutput1[i] = vsoutput1[i] * (v1.w);
//				   vsoutput2[i] = vsoutput2[i] * (v2.w);
//			   }
//			   for (int i = 0; i < iNumOutput; ++i) {
				float fDelta0 = v1.objZ - v0.objZ, fDelta1 = v2.objZ - v0.objZ;
				float fDdx = (fDelta0 * (fDeltaY1)
						- fDelta1 * (fDeltaY0))
						* (fCommonGradient);
				float fDdy = -(fDelta0 * (fDeltaX1)
						- fDelta1 * (fDeltaX0))
						* (fCommonGradient);
				float ddxW=fDdx;
				float ddyW =fDdy;
//			   }
//			   for (int i = 0; i < iNumOutput; ++i) {
//					float fDelta0 = vsoutput1[i] - vsoutput0[i], fDelta1 = vsoutput2[i] - vsoutput0[i];
//					float fDdx = (fDelta0 * (fDeltaY1)
//							- fDelta1 * (fDeltaY0))
//							* (fCommonGradient);
//					float fDdy = -(fDelta0 * (fDeltaX1)
//							- fDelta1 * (fDeltaX0))
//							* (fCommonGradient);
//					pDdx[i]=fDdx;
//					pDdy[i]=fDdy;
//				   }		
			   
			   int iWidth = width;
			   int iWidth_1 = iWidth-1;
			   Point3D frag = this.frag;
			   float[]pRenderBuffer=this.pRenderBuffer;
		boolean lazyEvaluation = true;
		for (; y <= endY; y++, fX0 += fStepX0, fX1 +=
				fStepX1) {
			if (y==midY) {
				fX0=fX2;
				fX1 = fX3;
				fStepX0=fStepX2;
				fStepX1 = fStepX3;
			}
			int iX = s_ifloor(fX0);
			int x = iX + 1;
			int i2X = s_ifloor(fX1);
			int endX = i2X;
			if (x<0)
				x = 0;
			if (endX>iWidth_1)
				endX = iWidth_1;
			if (x > endX)
				continue;
//			frag.winY = y;
			int size_y = (int) ( y) * width;
			float i_fX = (float) x, i_fY = (float) y;
			float fOffsetX = (i_fX - v0.winX);
			float fOffsetY = (i_fY - v0.winY);
			float fW = v0.objZ + ddxW * (fOffsetX) + ddyW * (fOffsetY);
//			for (int i = 0; i < iNumOutput; ++i) {
//				vs_output[i] = vsoutput0[i] + pDdx[i] * (fOffsetX)
//										+ pDdy[i] * (fOffsetY);
//			}
			for (; x <= endX; x++, fW += ddxW/*add_ddx(vs_output, pDdx, iNumOutput)*/) {
				
				int pxIndex = size_y + (x);
//				float w = vs_output[0];
//				float inv_w = 1/w;
				// frag.winX=x
				float destZ = zBuffer[pxIndex];
				float z = fW;
//				float z = vs_output[0];
				// Depth Test
				int func = depthFunc;
				boolean fail = func == 0 ? destZ <= z : func == 1 ? destZ < z
						: func == 2 ? destZ != z : func == 3 ? destZ >= z
								: false;
						fail = 	fail /* || near >= z */;
						
				if (fail){
					continue;
				}
				zBuffer[pxIndex] = z;
				faceIds[pxIndex] = faceId;
//				pixels[pxIndex] =-1;
			}
		}
	}
	private final void drawTriangle() {
		float[] attribute0 = this.attribute0, pDdx = this.pDdx, pDdy = this.pDdy, vs_output = this.vs_output, ps_input = this.ps_input;
		   // Sort vertices by the computed window coordinates.
		   Point3D pV0 = pointA, pV1 = pointB, pV2 = pointC, pT0 = pointA;
		   if (pV1.winY < pV0.winY) {
		    pV0 = pV1;
		    pV1 = pT0;
		   }
		   pT0 = pV2;
		   if (pV2.winY < pV0.winY) {
		    pV2 = pV1;
		    pV1 = pV0;
		    pV0 = pT0;
		   } else if (pV2.winY < pV1.winY) {
		    pV2 = pV1;
		    pV1 = pT0;
		   }
		   Point3D vA = pV0,vB = pV1,vC = pV2;
		   float midY  = vB.winY; // !!! Edges are: AB-AC, BC-AC
		   midY = s_floor(midY) + 1;
		   if (midY<0) midY = 0;
			float fStepX[] = {
					(vB.winY - vA.winY > 0.0f) ?
							(vB.winX - vA.winX) / (vB.winY - vA.winY) : 0.0f,
					(vC.winY - vA.winY > 0.0f) ?
							(vC.winX - vA.winX) / (vC.winY - vA.winY) : 0.0f,
					(vC.winY - vB.winY > 0.0f) ?
							(vC.winX - vB.winX) / (vC.winY - vB.winY) : 0.0f, 0 };
			fStepX[3]=fStepX[1];
			float fY[]={y,y,midY,midY};
			float leftX[] = {vA.winX,vA.winX,  vB.winX,vA.winX};
			float leftY[] = {vA.winY,vA.winY,vB.winY,vA.winY};
			float fX[]={0,0,0,0};
			for (int i = 0;  i < 4; ++ i) {
				fX[i] = (fY[i] - leftY[i])*fStepX[i]+leftX[i];
			}
			float f;
		   if (fStepX[0]>fStepX[1]) {
			   f =  fX[0];
				fX[0] = fX[1];
				fX[1] = f;
				f =  fStepX[0];
				fStepX[0] = fStepX[1];
				fStepX[1] = f;
		   }
		   if (fStepX[2]<fStepX[3]) {
			    f=  fX[2];
				fX[2] = fX[3];
				fX[3] = f;
				f =  fStepX[2];
				fStepX[2] = fStepX[3];
				fStepX[3] = f;
		   }
		   Point3D v0=pointA,v1=pointB,v2=pointC;
			float fDeltaX[] = { pointB.winX - pointA.winX, pointC.winX
					- pointA.winX };
			float fDeltaY[] = { pointB.winY - pointA.winY, pointC.winY
					- pointA.winY };
			float fCommonGradient = 1.0f
					/ (fDeltaX[0] * fDeltaY[1] - fDeltaX[1] * fDeltaY[0]);
			   int iNumOutput = 4;
			   float vsoutput0[] = {v0.objZ, v0.texX, v0.texY, v0.light};
			   float vsoutput1[] = {v1.objZ, v1.texX, v1.texY, v1.light};
			   float vsoutput2[] = {v2.objZ, v2.texX, v2.texY, v2.light};
//			   for (int i = 0; i < iNumOutput; ++i) {
//				   vsoutput0[i] = vsoutput0[i] * (v0.w);
//				   vsoutput1[i] = vsoutput1[i] * (v1.w);
//				   vsoutput2[i] = vsoutput2[i] * (v2.w);
//			   }
			   for (int i = 0; i < iNumOutput; ++i) {
				float fDelta0 = vsoutput1[i] - vsoutput0[i], fDelta1 = vsoutput2[i] - vsoutput0[i];
				float fDdx = (fDelta0 * (fDeltaY[1])
						- fDelta1 * (fDeltaY[0]))
						* (fCommonGradient);
				float fDdy = -(fDelta0 * (fDeltaX[1])
						- fDelta1 * (fDeltaX[0]))
						* (fCommonGradient);
				pDdx[i]=fDdx;
				pDdy[i]=fDdy;
			   }		
			   float y = this.y;
			   int iWidth = width;
			   int iWidth_1 = iWidth-1;
//			   Fragment frag = this.frag;
		boolean lazyEvaluation = true;
		for (; y <= endY; y++, fX[0] += fStepX[0], fX[1] +=
				fStepX[1]) {
			if (y==midY) {
				fX[0]=fX[2];
				fX[1] = fX[3];
				fStepX[0]=fStepX[2];
				fStepX[1] = fStepX[3];
			}
			int iX = s_ifloor(fX[0]);
			int x = iX + 1;
			int i2X = s_ifloor(fX[1]);
			int endX = i2X;
			if (x<0)
				x = 0;
			if (endX>iWidth_1)
				endX = iWidth_1;
			if (x > endX)
				continue;
			int size_y = (int) (frag.winY = y) * width;
			float i_fX = (float) x, i_fY = (float) y;
			float fOffsetX = (i_fX - v0.winX);
			float fOffsetY = (i_fY - v0.winY);
			for (int i = 0; i < iNumOutput; ++i) {
				vs_output[i] = vsoutput0[i] + pDdx[i] * (fOffsetX)
										+ pDdy[i] * (fOffsetY);
			}
			for (; x <= endX; x++,add_ddx(vs_output,pDdx,iNumOutput)) {
				
				int pxIndex = size_y + (int) (x);
//				float w = vs_output[0];
//				float inv_w = 1/w;
				// frag.winX=x
				float destZ = zBuffer[pxIndex];
				float z = vs_output[0];
				// Depth Test
				int func = depthFunc;
				boolean fail = func == 0 ? destZ <= z : func == 1 ? destZ < z
						: func == 2 ? destZ != z : func == 3 ? destZ >= z
								: false;
						fail = 	fail /* || near >= z */;
						
				if (fail){
					continue;
				}
				zBuffer[pxIndex] = z;
//				faceIds[pxIndex] = 1;
//				pixels[pxIndex] =-1;
//				pxIndex = pxIndex*sizePerPixel;
//				for (int i = 0; i < iNumOutput; ++i) {
//					pRenderBuffer[pxIndex + i] = vs_output[i];
//				}
//				final Fragment frag = new Fragment();
				// TODO
				for(int i = 0; i < iNumOutput; ++i)
				{
					ps_input[i] = vs_output[i];
				}
				float u = ps_input[1], v=ps_input[2];
				if (TEXTURE_ON)
					texture.getRGB(u, v, frag);
				fragPass.passPixel(frag);
				if (LIGHT_ON)
					frag.addRGB((int) ps_input[3]);
				if (frag.a < alphaGreater || frag.a >= alphaLess)
					continue;
				if (DEPTH_MASK || frag.a >= blendLess)//
					zBuffer[pxIndex] = z;// д��Z����
				if (!WRITE_COLOR)
					continue;
				if (ALPHA_BLENDING) {// Alpha���
					blend(pxIndex, frag);
					pixels[pxIndex] = (frag.a << 24) | (frag.r << 16)
							| (frag.g << 8) | frag.b;
				} else
					pixels[pxIndex] = (255 << 24) | (frag.r << 16)
							| (frag.g << 8) | frag.b;
			}
		}
	}
	public final void drawTriangle(Point3D pointA,Point3D pointB,Point3D pointC,Point3D frag,int faceId) {
		float [] pDdx={0,0,0,0},
				pDdy={0,0,0,0},
				vs_output={0,0,0,0},ps_input={0,0,0,0};
		   // Sort vertices by the computed window coordinates.
		   Point3D pV0 = pointA, pV1 = pointB, pV2 = pointC, pT0 = pointA;
		   if (pV1.winY < pV0.winY) {
		    pV0 = pV1;
		    pV1 = pT0;
		   }
		   pT0 = pV2;
		   if (pV2.winY < pV0.winY) {
		    pV2 = pV1;
		    pV1 = pV0;
		    pV0 = pT0;
		   } else if (pV2.winY < pV1.winY) {
		    pV2 = pV1;
		    pV1 = pT0;
		   }
		   Point3D vA = pV0,vB = pV1,vC = pV2;
		   float y = s_floor( vA.winY )+1;
		   float endY =s_floor( vC.winY );
		   if (y<0)y=0;
		   if (endY>=height)endY=height-1;
		   float midY  = vB.winY; // !!! Edges are: AB-AC, BC-AC
		   midY = s_floor(midY) + 1;
		   midY=(midY<0)?0:midY;
			float fStepX[] = {
					(vB.winY - vA.winY > 0.0f) ?
							(vB.winX - vA.winX) / (vB.winY - vA.winY) : 0.0f,
					(vC.winY - vA.winY > 0.0f) ?
							(vC.winX - vA.winX) / (vC.winY - vA.winY) : 0.0f,
					(vC.winY - vB.winY > 0.0f) ?
							(vC.winX - vB.winX) / (vC.winY - vB.winY) : 0.0f, 0 };
			fStepX[3]=fStepX[1];
			float fY[]={y,y,midY,midY};
			float leftX[] = {vA.winX,vA.winX,  vB.winX,vA.winX};
			float leftY[] = {vA.winY,vA.winY,vB.winY,vA.winY};
			float fX[]={0,0,0,0};
			for (int i = 0;  i < 4; ++ i) {
				fX[i] = (fY[i] - leftY[i])*fStepX[i]+leftX[i];
			}
			float f;
		   if (fStepX[0]>fStepX[1]) {
			   f =  fX[0];
				fX[0] = fX[1];
				fX[1] = f;
				f =  fStepX[0];
				fStepX[0] = fStepX[1];
				fStepX[1] = f;
		   }
		   if (fStepX[2]<fStepX[3]) {
			    f=  fX[2];
				fX[2] = fX[3];
				fX[3] = f;
				f =  fStepX[2];
				fStepX[2] = fStepX[3];
				fStepX[3] = f;
		   }
		   Point3D v0=pointA,v1=pointB,v2=pointC;
			float fDeltaX[] = { pointB.winX - pointA.winX, pointC.winX
					- pointA.winX };
			float fDeltaY[] = { pointB.winY - pointA.winY, pointC.winY
					- pointA.winY };
			float fCommonGradient = 1.0f
					/ (fDeltaX[0] * fDeltaY[1] - fDeltaX[1] * fDeltaY[0]);
			   int iNumOutput = 4;
			   float vsoutput0[] = {v0.objZ, v0.texX, v0.texY, 1};
			   float vsoutput1[] = {v1.objZ, v1.texX, v1.texY, 1};
			   float vsoutput2[] = {v2.objZ, v2.texX, v2.texY, 1};
			   for (int i = 0; i < iNumOutput; ++i) {
				   vsoutput0[i] = vsoutput0[i] * (v0.w);
				   vsoutput1[i] = vsoutput1[i] * (v1.w);
				   vsoutput2[i] = vsoutput2[i] * (v2.w);
			   }
			   for (int i = 0; i < iNumOutput; ++i) {
				float fDelta0 = vsoutput1[i] - vsoutput0[i], fDelta1 = vsoutput2[i] - vsoutput0[i];
				float fDdx = (fDelta0 * (fDeltaY[1])
						- fDelta1 * (fDeltaY[0]))
						* (fCommonGradient);
				float fDdy = -(fDelta0 * (fDeltaX[1])
						- fDelta1 * (fDeltaX[0]))
						* (fCommonGradient);
				pDdx[i]=fDdx;
				pDdy[i]=fDdy;
			   }		
			   
			   int iWidth = width;
			   int iWidth_1 = iWidth-1;
		boolean lazyEvaluation = true;
		for (; y <= endY; y++, fX[0] += fStepX[0], fX[1] +=
				fStepX[1]) {
			if (y==midY) {
				fX[0]=fX[2];
				fX[1] = fX[3];
				fStepX[0]=fStepX[2];
				fStepX[1] = fStepX[3];
			}
			int iX = s_ifloor(fX[0]);
			int x = iX + 1;
			int i2X = s_ifloor(fX[1]);
			int endX = i2X;
			if (x<0)
				x = 0;
			if (endX>iWidth_1)
				endX = iWidth_1;
			if (x > endX)
				continue;
			int size_y = (int) (frag.winY = y) * width;
			float i_fX = (float) x, i_fY = (float) y;
			float fOffsetX = (i_fX - v0.winX);
			float fOffsetY = (i_fY - v0.winY);
			for (int i = 0; i < iNumOutput; ++i) {
				vs_output[i] = vsoutput0[i] + pDdx[i] * (fOffsetX)
										+ pDdy[i] * (fOffsetY);
			}
			for (; x <= endX; x++,add_ddx(vs_output,pDdx,iNumOutput)) {
				
//				float w = vs_output[0];
//				float inv_w = 1/w;
//				frag.winX = x;
				int pxIndex = size_y + (int) (x);// frag.winX=x
				int func = depthFunc;
				if(func == 8 && faceIds[pxIndex]!=faceId)continue;
				float destZ = zBuffer[pxIndex];
				float z = vs_output[0];
				// Depth Test
				boolean fail = func == 0 ? destZ <= z : func == 1 ? destZ < z
						: func == 2 ? destZ != z : func == 3 ? destZ >= z
								: false;
						fail = 	fail /* || near >= z */;
						
				if (fail){
					continue;
				}
				
				for(int i = 0; i < iNumOutput; ++i)
				{
					ps_input[i] = vs_output[i];
				}
				float u = ps_input[1], v=ps_input[2];
				if (TEXTURE_ON)
					texture.getRGB(u, v, frag);
				fragPass.passPixel(frag);
				if (LIGHT_ON)
					frag.addRGB((int) ps_input[3]);
				if (frag.a < alphaGreater || frag.a >= alphaLess)
					continue;
//				if (DEPTH_MASK || frag.a >= blendLess)//
//					zBuffer[pxIndex] = z;// д��Z����
				if (!WRITE_COLOR)
					continue;
				if (ALPHA_BLENDING) {// Alpha���
					blend(pxIndex, frag);
					pixels[pxIndex] = (frag.a << 24) | (frag.r << 16)
							| (frag.g << 8) | frag.b;
				} else
					pixels[pxIndex] = (255 << 24) | (frag.r << 16)
							| (frag.g << 8) | frag.b;
			}
		}
	}

	private final void lighting() {
		pointA.normal.set(pointA.nrmX, pointA.nrmY, pointA.nrmZ);
		pointB.normal.set(pointB.nrmX, pointB.nrmY, pointB.nrmZ);
		pointC.normal.set(pointC.nrmX, pointC.nrmY, pointC.nrmZ);
		Light.blinn_phong_lighting(pointA);
		Light.blinn_phong_lighting(pointB);
		Light.blinn_phong_lighting(pointC);
	}

	private final boolean isBackFace() {
		// �� http://www.jurjans.lv/flash/shape.html
		float cax = pointC.winX - pointA.winX;
		float cay = pointC.winY - pointA.winY;
		float bcx = pointB.winX - pointC.winX;
		float bcy = pointB.winY - pointC.winY;
		return cax * bcy > cay * bcx;
	}
	public final boolean isBackFace(Point3D pointA,Point3D pointB,Point3D pointC) {
		// �� http://www.jurjans.lv/flash/shape.html
		float cax = pointC.winX - pointA.winX;
		float cay = pointC.winY - pointA.winY;
		float bcx = pointB.winX - pointC.winX;
		float bcy = pointB.winY - pointC.winY;
		return cax * bcy > cay * bcx;
	}
	public final void blend(int pxIndex, Point3D frgColor) {
		int alpha, ialpha;
		int dsta, dstr, dstg, dstb, dstColor;
		dstColor = pixels[pxIndex];
		dsta = (dstColor >> 24) & 0xff;
		alpha = frgColor.a;
		ialpha = 256 - alpha;
		dstr = (dstColor >> 16) & 0xff;
		dstg = (dstColor >> 8) & 0xff;
		dstb = dstColor & 0xff;
		frgColor.r = (frgColor.r * alpha + dstr * ialpha) >> 8;
		frgColor.g = (frgColor.g * alpha + dstg * ialpha) >> 8;
		frgColor.b = (frgColor.b * alpha + dstb * ialpha) >> 8;
		frgColor.a = dsta * (256 - alpha);
	}

	private final boolean drawPass1() {
		float winY0 = pointA.winY, winY1 = pointB.winY;
		float winY2 = pointC.winY;
		int w = width, h = height;
		if ((pointA.winX < 0 && pointB.winX < 0 && pointC.winX < 0)
				|| (pointA.winX >= w && pointB.winX >= w && pointC.winX >= w))
			return false;
		y = winY0 < winY1 ? winY0 : winY1;
		y = y < winY2 ? y : winY2;
		endY = winY0 > winY1 ? winY0 : winY1;
		endY = endY > winY2 ? endY : winY2;
		if (endY < 0 || y > h || y == endY)
			return false;
		// ˮƽɨ���ߵ���ʼ������y����
		float iY = s_floor(y) + 1, i2Y = s_floor(endY);
		y = (iY);
		endY = i2Y;
		if (y < 0)
			y = 0;
		if (endY >= h)
			endY = h - 1;
		float far = screenZ + 10000000;
		float near = screenZ - 100000;
		if ((y > endY)
				|| (pointA.objZ > far || pointB.objZ > far || pointC.objZ > far)
				|| (pointA.objZ < near && pointB.objZ < near && pointC.objZ < near))
			return false;
		return true;
	}
	public final boolean drawPass1(Point3D pointA,Point3D pointB,Point3D pointC) {
		float winY0 = pointA.winY, winY1 = pointB.winY;
		float winY2 = pointC.winY;
		int w = width, h = height;
		if ((pointA.winX < 0 && pointB.winX < 0 && pointC.winX < 0)
				|| (pointA.winX >= w && pointB.winX >= w && pointC.winX >= w))
			return false;
		float y = winY0 < winY1 ? winY0 : winY1;
		y = y < winY2 ? y : winY2;
		float endY = winY0 > winY1 ? winY0 : winY1;
		endY = endY > winY2 ? endY : winY2;
		if (endY < 0 || y > h || y >= endY)
			return false;
		// ˮƽɨ���ߵ���ʼ������y����
//		if (y < 0)
//			y = 0;
//		if (endY >= h)
//			endY = h - 1;
//		float iY = (int) (y), i2Y = (int) (endY);
//		y = iY + 1;
//		endY = i2Y;
		float far = screenZ + 10000000;
		float near = screenZ - 100000;
		if ((y > endY)
				|| (pointA.objZ > far || pointB.objZ > far || pointC.objZ > far)
				|| (pointA.objZ < near && pointB.objZ < near && pointC.objZ < near))
			return false;
		return true;
	}
	public static float zBufferInit=999999999f;//999999999f
	public final void beginScene() {
		Arrays.fill(zBuffer, zBufferInit);// -32767f
		Arrays.fill(pixels, 0);
		Arrays.fill(faceIds, -1);
	}

	public final void present() {
		graphics2D.drawImage(image, 8, 30, java.awt.Color.black, null);
	}

	/**
	 * ���㶥�㷨��
	 * 
	 * @param vertices
	 * @param indices
	 * @param normals
	 */
	public static void computeNormals(float[] vertices, int[] indices,
			float[] normals) {
		Arrays.fill(normals, 0f);
		int offs0, offs1, offs2;
		float[] vec0 = { 0, 0, 0 }, vec1 = { 0, 0, 0 }, result = { 0, 0, 0 };
		for (int i = 0; i < indices.length; i += 3) {
			offs0 = indices[i] * 3;
			offs1 = indices[i + 1] * 3;
			offs2 = indices[i + 2] * 3;
			vec0[0] = vertices[offs1] - vertices[offs0];
			vec0[1] = vertices[offs1 + 1] - vertices[offs0 + 1];
			vec0[2] = vertices[offs1 + 2] - vertices[offs0 + 2];
			vec1[0] = vertices[offs2] - vertices[offs1];
			vec1[1] = vertices[offs2 + 1] - vertices[offs1 + 1];
			vec1[2] = vertices[offs2 + 2] - vertices[offs1 + 2];
			Vec3.cross(vec0, vec1, result);
			Vec3.normalize(result);
			normals[offs0] += result[0];
			normals[offs0 + 1] += result[1];
			normals[offs0 + 2] += result[2];
			normals[offs1] += result[0];
			normals[offs1 + 1] += result[1];
			normals[offs1 + 2] += result[2];
			normals[offs2] += result[0];
			normals[offs2 + 1] += result[1];
			normals[offs2 + 2] += result[2];
		}
		Vec3.normalizeAll(normals);
	}

	public void drawString(String str, int x, int y) {
		bufferedGraphics.drawString(str, x, y);
	}
	SpinLock spinLock=new SpinLock();
	public final void flush_buffer(int iRenderedPixels,RenderBuffer renderBuffer) {
		PixelBuffer[] buffers = renderBuffer.buffer;
		final int size = renderBuffer.iRenderedPixels;
		spinLock.lock();
		for (int i=0; i < size; i++){
			PixelBuffer buffer = buffers[i];
			int pxIndex = buffer.pixelId;
			int icolor = buffer.color;
			float z = buffer.z;
			int faceId = buffer.faceId;
			if (zBuffer[pxIndex] >= z && faceIds[pxIndex] < faceId) {
				faceIds[pxIndex] = faceId;
				pixels[pxIndex] = icolor;
				zBuffer[pxIndex] = z;
			}
		}
		spinLock.unlock();
		renderBuffer.iRenderedPixels = 0;
	}
	public final void drawTriangle(Point3D pointA,Point3D pointB,Point3D pointC,Point3D frag,int faceId,RenderBuffer renderBuffer) {
		float[] pDdx = { 0, 0, 0, 0 }, pDdy = { 0, 0, 0, 0 }, vs_output = { 0,
				0, 0, 0 }, ps_input = { 0, 0, 0, 0 };
		   // Sort vertices by the computed window coordinates.
		   Point3D pV0 = pointA, pV1 = pointB, pV2 = pointC, pT0 = pointA;
		   if (pV1.winY < pV0.winY) {
		    pV0 = pV1;
		    pV1 = pT0;
		   }
		   pT0 = pV2;
		   if (pV2.winY < pV0.winY) {
		    pV2 = pV1;
		    pV1 = pV0;
		    pV0 = pT0;
		   } else if (pV2.winY < pV1.winY) {
		    pV2 = pV1;
		    pV1 = pT0;
		   }
		   final Point3D vA = pV0,vB = pV1,vC = pV2;
		   float y = s_floor( vA.winY )+1;
		   float endY =s_floor( vC.winY );
		   y = (y<0)?0:y;
		   endY = (endY>=height)?height-1:endY;
		   float midY  = vB.winY; // !!! Edges are: AB-AC, BC-AC
		   midY = s_floor(midY) + 1;
		   midY = midY<0?0:midY;
		   float dY01 = vB.winY - vA.winY;
		   float dY02 = vC.winY - vA.winY;
		   float dY12 = vC.winY - vB.winY;
		   float fStepX0 = (dY01> 0.0f) ?
					(vB.winX - vA.winX) / (dY01) : 0.0f;
		float fStepX1 = (dY02> 0.0f) ?
				(vC.winX - vA.winX) / (dY02) : 0.0f;
		float fStepX2 = (dY12> 0.0f) ?
				(vC.winX - vB.winX) / (dY12) : 0.0f;
				float fStepX3= fStepX1;
			float fX0, fX1,fX2,fX3;
			fX0 = (y - vA.winY)*fStepX0+vA.winX;
			fX1 = (y - vA.winY)*fStepX1+vA.winX;
			fX2 = (midY - vB.winY)*fStepX2+vB.winX;
			fX3 = (midY - vA.winY)*fStepX3+vA.winX;
			float f;
		   if (fStepX0>fStepX1) {
			   f =  fX0;
				fX0 = fX1;
				fX1 = f;
				f =  fStepX0;
				fStepX0 = fStepX1;
				fStepX1 = f;
		   }
		   if (fStepX2<fStepX3) {
			    f=  fX2;
				fX2 = fX3;
				fX3 = f;
				f =  fStepX2;
				fStepX2 = fStepX3;
				fStepX3 = f;
		   }
		   final Point3D v0=pointA,v1=pointB,v2=pointC;
		   float fDeltaX0=pointB.winX - pointA.winX,fDeltaX1=pointC.winX
					- pointA.winX;
		   float fDeltaY0 = pointB.winY - pointA.winY,fDeltaY1= pointC.winY
					- pointA.winY ;
			float fCommonGradient = 1.0f
					/ (fDeltaX0 * fDeltaY1 - fDeltaX1 * fDeltaY0);
			   final int iNumOutput = 4;
			   float vsoutput0[] = {v0.objZ, v0.texX, v0.texY, v0.light};
			   float vsoutput1[] = {v1.objZ, v1.texX, v1.texY, v1.light};
			   float vsoutput2[] = {v2.objZ, v2.texX, v2.texY, v2.light};
//			   float vsoutput0[] =attribute0,vsoutput1[] =attribute1,vsoutput2[] =attribute2;
//			   vsoutput0[0]=v0.objZ; vsoutput0[1]=v0.texX; vsoutput0[2]=v0.texY; vsoutput0[3]=1;
//			   vsoutput1[0]=v1.objZ; vsoutput1[1]=v1.texX; vsoutput1[2]=v1.texY; vsoutput1[3]=1;
//			   vsoutput2[0]=v2.objZ; vsoutput2[1]=v2.texX; vsoutput2[2]=v2.texY; vsoutput2[3]=1;
//			   for (int i = 0; i < iNumOutput; ++i) {
//				   vsoutput0[i] = vsoutput0[i] * (v0.w);
//				   vsoutput1[i] = vsoutput1[i] * (v1.w);
//				   vsoutput2[i] = vsoutput2[i] * (v2.w);
//			   }
//			   for (int i = 0; i < iNumOutput; ++i) {
//				float fDelta0 = v1.objZ - v0.objZ, fDelta1 = v2.objZ - v0.objZ;
//				float fDdx = (fDelta0 * (fDeltaY1)
//						- fDelta1 * (fDeltaY0))
//						* (fCommonGradient);
//				float fDdy = -(fDelta0 * (fDeltaX1)
//						- fDelta1 * (fDeltaX0))
//						* (fCommonGradient);
//				float ddxW=fDdx;
//				float ddyW =fDdy;
//			   }
			   for (int i = 0; i < iNumOutput; ++i) {
					float fDelta0 = vsoutput1[i] - vsoutput0[i], fDelta1 = vsoutput2[i] - vsoutput0[i];
					float fDdx = (fDelta0 * (fDeltaY1)
							- fDelta1 * (fDeltaY0))
							* (fCommonGradient);
					float fDdy = -(fDelta0 * (fDeltaX1)
							- fDelta1 * (fDeltaX0))
							* (fCommonGradient);
					pDdx[i]=fDdx;
					pDdy[i]=fDdy;
				   }		
			   
			   int iWidth = width;
			   int iWidth_1 = iWidth-1;
			   PixelBuffer[] buffers=renderBuffer.buffer;
		boolean lazyEvaluation = true;
		for (; y <= endY; y++, fX0 += fStepX0, fX1 +=
				fStepX1) {
			if (y==midY) {
				fX0=fX2;
				fX1 = fX3;
				fStepX0=fStepX2;
				fStepX1 = fStepX3;
			}
			int iX = s_ifloor(fX0);
			int x = iX + 1;
			int i2X = s_ifloor(fX1);
			int endX = i2X;
			if (x<0)
				x = 0;
			if (endX>iWidth_1)
				endX = iWidth_1;
			if (x > endX)
				continue;
//			frag.winY = y;
			int size_y = (int) ( y) * width;
			float i_fX = (float) x, i_fY = (float) y;
			float fOffsetX = (i_fX - v0.winX);
			float fOffsetY = (i_fY - v0.winY);
//			float fW = v0.objZ + ddxW * (fOffsetX) + ddyW * (fOffsetY);
			for (int i = 0; i < iNumOutput; ++i) {
				vs_output[i] = vsoutput0[i] + pDdx[i] * (fOffsetX)
										+ pDdy[i] * (fOffsetY);
			}
			for (; x <= endX; x++, /*fW += ddxW*/add_ddx(vs_output, pDdx, iNumOutput)) {
				
				int pxIndex =  size_y + (int)(x);
//				float w = vs_output[0];
//				float inv_w = 1/w;
				// frag.winX=x
				float destZ = zBuffer[pxIndex];
//				float z = fW;
				float z = vs_output[0];
				// Depth Test
				int func = depthFunc;
				boolean fail = func == 0 ? destZ <= z : func == 1 ? destZ < z
						: func == 2 ? destZ != z : func == 3 ? destZ >= z
								: false;
						fail = 	fail /* || near >= z */;
						
				if (fail){
					continue;
				}
//				zBuffer[pxIndex] = z;
//				faceIds[pxIndex] = faceId;
//				pixels[pxIndex] =-1;
				
				for(int i = 0; i < iNumOutput; ++i)
				{
					ps_input[i] = vs_output[i];
				}
				float u = ps_input[1], v=ps_input[2];
				if (TEXTURE_ON)
					texture.getRGB(u, v, frag);
				fragPass.passPixel(frag);
				if (LIGHT_ON)
					frag.addRGB((int) ps_input[3]);
				if (frag.a < alphaGreater || frag.a >= alphaLess)
					continue;
//				if (DEPTH_MASK || frag.a >= blendLess)//
//					zBuffer[pxIndex] = z;// д��Z����
				if (!WRITE_COLOR)
					continue;
//				if (ALPHA_BLENDING) {// Alpha���
//					blend(pxIndex, frag);
//					pixels[pxIndex] = (frag.a << 24) | (frag.r << 16)
//							| (frag.g << 8) | frag.b;
//				} else
//					pixels[pxIndex] = (255 << 24) | (frag.r << 16)
//							| (frag.g << 8) | frag.b;
				
				int color = (255 << 24) | (frag.r << 16)
						| (frag.g << 8) | frag.b;
				PixelBuffer pixel= buffers[renderBuffer.iRenderedPixels++];
				pixel.z  = z;
				pixel.color  = color;
				pixel.pixelId  = pxIndex;
				pixel.faceId  = faceId;
				if (renderBuffer.iRenderedPixels>=RenderBuffer.max_local_memory) {
					flush_buffer(0, renderBuffer);
				}
			}
		}
	}
}