///*
// * JOCL - Java bindings for OpenCL
// * 
// * Copyright 2009 Marco Hutter - http://www.jocl.org/
// */
//
//package soft3d.v0_1;
//
//import static org.jocl.CL.*;
//
//import java.io.BufferedReader;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.io.InputStreamReader;
//
//import org.jocl.*;
//
///**
// * A small JOCL sample.
// */
//public class JOCLSample
//{
//	public void begin(SoftGraphics3DV0_1 g){
//		
//	}
//	public void finish(SoftGraphics3DV0_1 gl){
//		int dataDst[] = gl.pixels;
////        clEnqueueReadBuffer(commandQueue, memObjects[1], 
////            CL_TRUE, 0,dataDst.length * Sizeof.cl_uint, 
////            Pointer.to(dataDst), 0, null, null);
//   }
//	final long globalWorkSize[] = new long[]{0};
//    final long localWorkSize[] = new long[]{1};
//	public void Execute(int n){
//		
//    	// Set the work-item dimensions
//		globalWorkSize[0] = n;
//        // Execute the kernel
//        clEnqueueNDRangeKernel(commandQueue, clKernel, 1, null, 
//                globalWorkSize, localWorkSize, 0, null, null);
//        clFinish(commandQueue);
//    }
//	Pointer[] pointers;
//	int[] intBuffer1 ={0,0};
//	public void CreateBuffer(SoftGraphics3DV0_1 gl){
//		//1024,680;
//    	int imageSizeX = 1024;
//        int imageSizeY = 680;
//        if (gl.RasterCoords == null) {
//        	gl.RasterCoords = new float[imageSizeX*imageSizeY *2];
//		}
//        pointers = new Pointer[16];
//        memObjects = new cl_mem[16];
//        // Create the memory object for the input- and output image
//      
//        pointers[0] = Pointer.to(gl.RasterCoords);
//        memObjects[0] = clCreateBuffer(context, 
//            CL_MEM_READ_WRITE | CL_MEM_USE_HOST_PTR, 
//            gl.RasterCoords.length * Sizeof.cl_uint, 
//            pointers[0], null);
//
//        pointers[1] = Pointer.to(gl.pixels);
//        memObjects[1] = clCreateBuffer(context,
//        		CL_MEM_READ_WRITE| CL_MEM_USE_HOST_PTR,
//            imageSizeX * imageSizeY * Sizeof.cl_uint, pointers[1] , null);
//        pointers[2] =Pointer.to(intBuffer1);
//        memObjects[2] = clCreateBuffer(context, 
//                CL_MEM_READ_WRITE | CL_MEM_USE_HOST_PTR, 
//                intBuffer1.length * Sizeof.cl_uint, 
//                pointers[2], null);
//        pointers[3] =Pointer.to(gl.zBuffer);
//        memObjects[3] = clCreateBuffer(context, 
//                CL_MEM_READ_WRITE | CL_MEM_USE_HOST_PTR, 
//                gl.zBuffer.length * Sizeof.cl_uint, 
//                pointers[3], null);
//        pointers[4] = Pointer.to(gl.texture.intData);
//        memObjects[4] = clCreateBuffer(context, 
//                CL_MEM_READ_WRITE | CL_MEM_USE_HOST_PTR, 
//                gl.texture.intData.length * Sizeof.cl_uint, 
//                pointers[4], null);
//        pointers[5] = Pointer.to(gl.vertexAttribs0);
//        memObjects[5] = clCreateBuffer(context, 
//                CL_MEM_READ_WRITE | CL_MEM_USE_HOST_PTR, 
//                gl.vertexAttribs0.length * Sizeof.cl_uint, 
//                pointers[5], null);
//        pointers[6] = Pointer.to(gl.vertexAttribs1);
//        memObjects[6] = clCreateBuffer(context, 
//                CL_MEM_READ_WRITE | CL_MEM_USE_HOST_PTR, 
//                gl.vertexAttribs1.length * Sizeof.cl_uint, 
//                pointers[6], null);
//        pointers[7] = Pointer.to(gl.vertexAttribs2);
//        memObjects[7] = clCreateBuffer(context, 
//                CL_MEM_READ_WRITE | CL_MEM_USE_HOST_PTR, 
//                gl.vertexAttribs2.length * Sizeof.cl_uint, 
//                pointers[7], null);
//        
////        float[] RasterCoords
////	    ,int[]output
////	    ,int[]Size
////	    ,float[] zBuffer
////	    ,int[] texData
////	    ,float[] vertexAttribs0
////	    ,float[] vertexAttribs1
////	    ,float[] vertexAttribs2
//        for(int i=0;i<8;i++){
//        	Pointer t=Pointer.to(memObjects[i]);
//        clSetKernelArg(clKernel, i, Sizeof.cl_mem, t);
//        }
////        clSetKernelArg(clKernel, 0, Sizeof.cl_mem, Pointer.to(memObjects[0]));
////        clSetKernelArg(clKernel, 1, Sizeof.cl_mem, Pointer.to(memObjects[1]));
////        clSetKernelArg(clKernel, 2, Sizeof.cl_mem, Pointer.to(memObjects[2]));
////        clSetKernelArg(clKernel, 3, Sizeof.cl_mem, Pointer.to(memObjects[3]));
////        clSetKernelArg(clKernel, 4, Sizeof.cl_mem, Pointer.to(memObjects[4]));
////        clSetKernelArg(clKernel, 5, Sizeof.cl_mem, Pointer.to(memObjects[5]));
////        clSetKernelArg(clKernel, 6, Sizeof.cl_mem, Pointer.to(memObjects[6]));
////        clSetKernelArg(clKernel, 7, Sizeof.cl_mem, Pointer.to(memObjects[7]));
//
//	}
//    private cl_context context;
//    private cl_command_queue commandQueue;
//    cl_program program;
//    private cl_kernel clKernel;
//    private cl_mem memObjects[];
//    public JOCLSample()
//    {
//        // Create input- and output data 
//
//        // The platform, device type and device number
//        // that will be used
//        final int platformIndex = 0;
//        final long deviceType = CL_DEVICE_TYPE_CPU;
//        final int deviceIndex = 0;
//
//        // Enable exceptions and subsequently omit error checks in this sample
//        CL.setExceptionsEnabled(true);
//
//        // Obtain the number of platforms
//        int numPlatformsArray[] = new int[1];
//        clGetPlatformIDs(0, null, numPlatformsArray);
//        int numPlatforms = numPlatformsArray[0];
//
//        // Obtain a platform ID
//        cl_platform_id platforms[] = new cl_platform_id[numPlatforms];
//        clGetPlatformIDs(platforms.length, platforms, null);
//        cl_platform_id platform = platforms[platformIndex];
//
//        // Initialize the context properties
//        cl_context_properties contextProperties = new cl_context_properties();
//        contextProperties.addProperty(CL_CONTEXT_PLATFORM, platform);
//        
//        // Obtain the number of devices for the platform
//        int numDevicesArray[] = new int[1];
//        clGetDeviceIDs(platform, deviceType, 0, null, numDevicesArray);
//        int numDevices = numDevicesArray[0];
//        
//        // Obtain a device ID 
//        cl_device_id devices[] = new cl_device_id[numDevices];
//        clGetDeviceIDs(platform, deviceType, numDevices, devices, null);
//        cl_device_id device = devices[deviceIndex];
//
//        // Create a context for the selected device
//        context = clCreateContext(
//            contextProperties, 1, new cl_device_id[]{device}, 
//            null, null, null);
//        
//        // Create a command-queue for the selected device
//        commandQueue = 
//            clCreateCommandQueue(context, device, 0, null);
//
//        // Allocate the memory objects for the input- and output data
////        cl_mem memObjects[] = new cl_mem[3];
////        memObjects[0] = clCreateBuffer(context, 
////            CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR,
////            Sizeof.cl_float * n, srcA, null);
////        memObjects[1] = clCreateBuffer(context, 
////            CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR,
////            Sizeof.cl_float * n, srcB, null);
////        memObjects[2] = clCreateBuffer(context, 
////            CL_MEM_READ_WRITE, 
////            Sizeof.cl_float * n, null, null);
//        
//        // Create the program from the source code
//        String programSource = readFile("kernels/SimpleConvolution.cl");
//        program = clCreateProgramWithSource(context,
//            1, new String[]{ programSource }, null, null);
//        
//        // Build the program
//        clBuildProgram(program, 0, null, null, null, null);
//        
//        // Create the kernel
//        clKernel = clCreateKernel(program, "convolution", null);
//        
////        // Set the arguments for the kernel
////        clSetKernelArg(clKernel, 0, 
////            Sizeof.cl_mem, Pointer.to(memObjects[0]));
////        clSetKernelArg(clKernel, 1, 
////            Sizeof.cl_mem, Pointer.to(memObjects[1]));
////        clSetKernelArg(clKernel, 2, 
////            Sizeof.cl_mem, Pointer.to(memObjects[2]));
////        
////        // Set the work-item dimensions
////        long global_work_size[] = new long[]{n};
////        long local_work_size[] = new long[]{1};
////        
////        // Execute the kernel
////        clEnqueueNDRangeKernel(commandQueue, clKernel, 1, null,
////            global_work_size, local_work_size, 0, null, null);
////        
////        // Read the output data
////        clEnqueueReadBuffer(commandQueue, memObjects[2], CL_TRUE, 0,
////            n * Sizeof.cl_float, dst, 0, null, null);
//        
//        // Release kernel, program, and memory objects
//        
//        
//    }
//    public void release(){
//    	clReleaseMemObject(memObjects[0]);
//        clReleaseMemObject(memObjects[1]);
//        clReleaseMemObject(memObjects[2]);
//        clReleaseKernel(clKernel);
//        clReleaseProgram(program);
//        clReleaseCommandQueue(commandQueue);
//        clReleaseContext(context);
//        
//    }
//    private static String readFile(String fileName)
//    {
//        try
//        {
//            BufferedReader br = new BufferedReader(
//                new InputStreamReader(new FileInputStream(fileName)));
//            StringBuffer sb = new StringBuffer();
//            String line = null;
//            while (true)
//            {
//                line = br.readLine();
//                if (line == null)
//                {
//                    break;
//                }
//                sb.append(line).append("\n");
//            }
//            return sb.toString();
//        }
//        catch (IOException e)
//        {
//            e.printStackTrace();
//            System.exit(1);
//            return null;
//        }
//    }
//	public void Execute(SoftGraphics3DV0_1 g) {
//		int n = g.nRasterCoords;
////		clEnqueueWriteBuffer(commandQueue, memObjects[0], true, 0, n*2*Sizeof.cl_float, pointers[0], 0, null, null);
//		
////		Execute(n);
//		// TODO Auto-generated method stub
//		int[] texData =  g.texture.intData;
//		for (int i = 0; i < g.nRasterCoords; i++)
//		__kernel(g.RasterCoords, g.pixels, null, g.zBuffer,texData, g.vertexAttribs0, g.vertexAttribs1, g.vertexAttribs2, i);
//	}
//	 void __kernel(
//		     float []RasterCoords,
//		     int []output,
//		     int []Size,
//		     float []zBuffer,
//		     int []texData,
//		     float []vertexAttribs0,
//		     float []vertexAttribs1,
//		     float []vertexAttribs2
//		     ,int get_global_id)
//		{
//		    int gx = get_global_id;
//		    gx = gx*2;
//		    float x =  RasterCoords[gx];
//		    float y = RasterCoords[gx +1];
//		    int width = 1024, height = 680;
//		    int texWidth = 512,  texHeight = 512;
//		    int pxIndex = (int) (y) * width + (int) (x);
//		    float winX0 = vertexAttribs0[0];
//		    float winY0 = vertexAttribs0[1];
//			float difWinX = x - winX0;
//			float difWinY = y - winY0;
//			
//			float winX01 = vertexAttribs1[0]-vertexAttribs0[0];
//			float winX02 = vertexAttribs2[0]-vertexAttribs0[0];
//			float winY01 = vertexAttribs1[1]-vertexAttribs0[1];
//			float winY02 = vertexAttribs2[1]-vertexAttribs0[1];
//			
//			float t = winY02 * winX01 - winY01 * winX02;
//			t =  t  == 0.0f ? 0.0f : 1.0f / t;
//			winY02*=t;winX02*=t;winX01*=t;winY01*=t;
//			
//			float a = winY02 * difWinX - winX02 * difWinY;
//			float b = winX01 * difWinY - winY01 * difWinX;
//			int vi = 2;
//			float z = vertexAttribs0[vi] + a * (vertexAttribs1[vi]-vertexAttribs0[vi]) + b * (vertexAttribs2[vi]-vertexAttribs0[vi]);
//			float destZ = zBuffer[pxIndex];
//			if (destZ <= z) {
//				return;
//			}
//			vi ++;
//			float u = vertexAttribs0[vi] + a * (vertexAttribs1[vi]-vertexAttribs0[vi]) + b * (vertexAttribs2[vi]-vertexAttribs0[vi]);
//			vi ++;
//			float v = vertexAttribs0[vi] + a * (vertexAttribs1[vi]-vertexAttribs0[vi]) + b * (vertexAttribs2[vi]-vertexAttribs0[vi]);
//			
//			int texOff=((int) ((texHeight - 1)*v))*texWidth+(int)((texWidth - 1)*u);
//			output[pxIndex]= texData[texOff];
//			zBuffer[pxIndex]= z;
//		}
//	 void __kernel1(
//		     float []RasterCoords,
//		     int []output,
//		     int []Size,
//		     float []zBuffer,
//		     int []texData,
//		     float []vertexAttribs0,
//		     float []vertexAttribs1,
//		     float []vertexAttribs2,
//		     float []geometryVarying,
//		     float[][]vertexAttribPointer,
//		     int get_global_id)
//		{
//		    int gx = get_global_id;
//		    gx = gx*2;
//		    float x =  RasterCoords[gx];
//		    float y = RasterCoords[gx +1];
//		    int width = 1024, height = 680;
//		    int texWidth = 512,  texHeight = 512;
//		    int pxIndex = (int) (y) * width + (int) (x);
//		    float winX0 = vertexAttribs0[0];
//		    float winY0 = vertexAttribs0[1];
//			float difWinX = x - winX0;
//			float difWinY = y - winY0;
//			
//			float winX01 = vertexAttribs1[0]-vertexAttribs0[0];
//			float winX02 = vertexAttribs2[0]-vertexAttribs0[0];
//			float winY01 = vertexAttribs1[1]-vertexAttribs0[1];
//			float winY02 = vertexAttribs2[1]-vertexAttribs0[1];
//			
//			float t = winY02 * winX01 - winY01 * winX02;
//			t =  t  == 0.0f ? 0.0f : 1.0f / t;
//			winY02*=t;winX02*=t;winX01*=t;winY01*=t;
//			
//			float a = winY02 * difWinX - winX02 * difWinY;
//			float b = winX01 * difWinY - winY01 * difWinX;
//			int vi = 2;
//			float z = vertexAttribs0[vi] + a * (vertexAttribs1[vi]-vertexAttribs0[vi]) + b * (vertexAttribs2[vi]-vertexAttribs0[vi]);
//			float destZ = zBuffer[pxIndex];
//			if (destZ <= z) {
//				return;
//			}
//			vi ++;
//			float u = vertexAttribs0[vi] + a * (vertexAttribs1[vi]-vertexAttribs0[vi]) + b * (vertexAttribs2[vi]-vertexAttribs0[vi]);
//			vi ++;
//			float v = vertexAttribs0[vi] + a * (vertexAttribs1[vi]-vertexAttribs0[vi]) + b * (vertexAttribs2[vi]-vertexAttribs0[vi]);
//			
//			int texOff=((int) ((texHeight - 1)*v))*texWidth+(int)((texWidth - 1)*u);
//			output[pxIndex]= texData[texOff];
//			zBuffer[pxIndex]= z;
//		}
//}
