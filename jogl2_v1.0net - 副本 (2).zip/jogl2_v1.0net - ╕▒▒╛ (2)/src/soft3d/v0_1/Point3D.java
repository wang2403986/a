package soft3d.v0_1;

import soft3d.Vec3;

public class Point3D {

public int id;
public int a, r, g, b;
public float w = 1;
public float winX, winY;
public float objX, objY, objZ;
public float texX, texY, light;
public float nrmX, nrmY, nrmZ;
public final Vec3 normal = new Vec3();

public final void normal(float x, float y, float z) {
nrmX = x;
nrmY = y;
nrmZ = z;
Vec3 n = normal;
n.x = x;
n.y = y;
n.z = z;
}

public final void screenCoord(float x, float y) {
winX = x;
winY = y;
}

public final void vertex(float x, float y, float z) {
objX = x;
objY = y;
objZ = z;
}

public final void addRGB(int ligh2) {
int ar = r + ligh2;
int ag = g + ligh2;
int ab = b + ligh2;
r = ar > 255 ? 255 : (ar < 0 ? 0 : ar);
g = ag > 255 ? 255 : (ag < 0 ? 0 : ag);
b = ab > 255 ? 255 : (ab < 0 ? 0 : ab);
}

public final void setRGB(int a, int r, int g, int b) {
this.a = a;
this.b = b;
this.g = g;
this.r = r;
}
}
