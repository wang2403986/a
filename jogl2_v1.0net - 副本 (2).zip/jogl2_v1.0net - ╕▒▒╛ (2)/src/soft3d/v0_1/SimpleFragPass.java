package soft3d.v0_1;

import soft3d.v0_1.Point3D;
public final class SimpleFragPass extends FragPass{
	
	public final void passGeometry(Point3D p0, Point3D p1, Point3D p2) {}

	public final void passScanline(Point3D frag, float a, float b, float toX) {}

	public final void increment() {};
	
	public final void passPixel(Point3D frag) {}
}
