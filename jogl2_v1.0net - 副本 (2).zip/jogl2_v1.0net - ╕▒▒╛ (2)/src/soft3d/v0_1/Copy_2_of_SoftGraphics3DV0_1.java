//package soft3d.v0_1;
//
//import java.awt.Graphics;
//import java.awt.image.BufferedImage;
//import java.awt.image.DataBufferInt;
//import java.util.List;
//
//import static soft3d.v0_1.FragPass.*;
//import soft3d.Light;
//import soft3d.Matrix;
//import soft3d.Texture;
//import soft3d.Vec3;
//
//public class Copy_2_of_SoftGraphics3DV0_1 {
//	public static int height, width;
//	public static boolean LIGHT_ON = false, DEPTH_TEST = true,
//			TEXTURE_ON = true, ALPHA_BLENDING = false, DEPTH_MASK = true,
//			CULL_BACK = true, CULL_FRONT, PER_PIXEL_LIGHT, WRITE_COLOR = true;
//	public static final short SRCA_ADD_ONE = 8, SRCA_RSUB_ONE = 9,
//			SRCA_ADD_ONE_MINUS_SRCA = 1, SRCA_RSUB_ONE_MINUS_SRCA = 10,
//			ONE_MINUS_DST_ADD_ONE = 3, DSTA_ADD_ONE = 2, BLEND_REVISE = 0,
//			SRCARGB = 4;
//	public static short depthFunc, blendFunc = 1, blendFuncAlpha, reviseFunc;
//	public static int alphaGreater = 16, alphaLess = 258, blendLess = 240;
//	/** ͸�ӽ��� */
//	public static float focusZ = -256;// 256
//	/** ͶӰƽ�� */
//	public static float screenZ = -240;// 255
//	public static Texture texture;
//	public static List<Texture> textureList;
//	public static final float[][] transform = { { 1, 0, 0, 0 }, { 0, 1, 0, 0 },
//			{ 0, 0, 1, 0 }, { 0, 0, 0, 1 } };
//	public static int[] pixels;
//	public static float[] zBuffer;
//	public float[] stencil, blend_stencil;
//	/** ��y���� */
//	float order0, order1, order2, order3, order4, order5;
//	/** ���� */
//	float winX01, winY01, winX02, winY02, u01, v01, u02, v02, clrA01, clrA02,
//			objZ01, objZ02;
//	/** ��Ļ(����)���� */
//	public float winX0, winX1, winY0, winY1, winX2, winY2;
//	private float k01, k02, k12;
//	public float y, endY, _x, _endX;
//	/** �����εĶ��� */
//	public final Fragment pointA = new Fragment(), pointB = new Fragment(),
//			pointC = new Fragment();
//	public final Fragment frag = new Fragment();
//	public FragPass fragPass = new SimpleFragPass();// new FragPass(){};
//	/** ���ڻ��Ƶ�ͼƬԴ */
//	BufferedImage image;
//	Graphics graphics2D, bufferedGraphics;
//
//	public Copy_2_of_SoftGraphics3DV0_1(Graphics graphics2d, int w, int h) {
//		width = w;
//		height = h;
//		zBuffer = new float[height * width];
//		this.graphics2D = graphics2d;
//		Matrix.loadIdentity(transform);
//		image = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
//		pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
//		bufferedGraphics = image.createGraphics();
//	}
//	private final void revise_blend1(Fragment color, int pxIndex) {
//		
//	}
//	private final void blend(Fragment color, int pxIndex) {
//		
//	}
//
//	public final void drawTriangleList(float[] vertices, int[] indices,
//			float[] uvs, float[] normals, float[] screenBuf, int[] faceMaterials) {
//		Fragment v1 = pointA, v2 = pointB, v3 = pointC;
//		boolean lightState = LIGHT_ON;
//		boolean textureState = TEXTURE_ON;
//		boolean hasNormals = normals != null;
//		boolean faceMtrl = faceMaterials != null;
//		boolean hasUV = textureState && uvs != null;
//		boolean hasTexList = faceMtrl && textureList != null && hasUV;
//		LIGHT_ON = hasNormals? LIGHT_ON : false;
//		int faceIndex = 0;
//		for (int i = 0; i < indices.length; i += 3, faceIndex++) {
//			int offs0 = indices[i] * 3, offs1 = indices[i + 1] * 3;
//			int offs2 = indices[i + 2] * 3, off2d0 = indices[i] * 2;
//			int off2d1 = indices[i + 1] * 2, off2d2 = indices[i + 2] * 2;
//			v1.objX = vertices[offs0];
//			v1.objY = vertices[offs0 + 1];
//			v1.objZ = vertices[offs0 + 2];
//			v2.objX = vertices[offs1];
//			v2.objY = vertices[offs1 + 1];
//			v2.objZ = vertices[offs1 + 2];
//			v3.objX = vertices[offs2];
//			v3.objY = vertices[offs2 + 1];
//			v3.objZ = vertices[offs2 + 2];
//			v1.winX = screenBuf[off2d0];
//			v1.winY = screenBuf[off2d0 + 1];
//			v2.winX = screenBuf[off2d1];
//			v2.winY = screenBuf[off2d1 + 1];
//			v3.winX = screenBuf[off2d2];
//			v3.winY = screenBuf[off2d2 + 1];
//			if (!drawPass1() || (CULL_BACK && isBackFace())
//					|| (CULL_FRONT && !isBackFace()))
//				continue;
//			if (hasTexList)
//				texture = textureList.get(faceMaterials[faceIndex]);
//			TEXTURE_ON = hasUV && texture != null? true:false;
//			if (uvs != null) {
//				v1.texX = uvs[off2d0];
//				v1.texY = uvs[off2d0 + 1];
//				v2.texX = uvs[off2d1];
//				v2.texY = uvs[off2d1 + 1];
//				v3.texX = uvs[off2d2];
//				v3.texY = uvs[off2d2 + 1];
//			}
//			if (hasNormals) {
//				v1.nrmX = normals[offs0];
//				v1.nrmY = normals[offs0 + 1];
//				v1.nrmZ = normals[offs0 + 2];
//				v2.nrmX = normals[offs1];
//				v2.nrmY = normals[offs1 + 1];
//				v2.nrmZ = normals[offs1 + 2];
//				v3.nrmX = normals[offs2];
//				v3.nrmY = normals[offs2 + 1];
//				v3.nrmZ = normals[offs2 + 2];
//			}
//			if (!PER_PIXEL_LIGHT && LIGHT_ON) {
//				vertexLight(v1);
//				vertexLight(v2);
//				vertexLight(v3);
//			}
//			drawTriangle();
//		}
//		LIGHT_ON = lightState;
//		TEXTURE_ON = textureState;
//	}
//
//	private final void putOrderedY() {
//		if (winY0 < winY1) {
//			order0 = winY0;
//			order1 = winY1;
//		} else {
//			order0 = winY1;
//			order1 = winY0;
//		}
//		if (winY0 < winY2) {
//			order2 = winY0;
//			order3 = winY2;
//		} else {
//			order2 = winY2;
//			order3 = winY0;
//		}
//		if (winY1 < winY2) {
//			order4 = winY1;
//			order5 = winY2;
//		} else {
//			order4 = winY2;
//			order5 = winY1;
//		}
//	}
//
//	final float[] vertexAttribs0 = new float[2+1+2];
//    final float[] vertexAttribs1= new float[2+1+2];
//    final float[] vertexAttribs2= new float[2+1+2];
//    public void putVertexAttribs(){
//		vertexAttribs0[0] = pointA.winX;
//		vertexAttribs0[1] = pointA.winY;
//		vertexAttribs0[2] = pointA.objZ;
//		vertexAttribs0[3] = pointA.texX;
//		vertexAttribs0[4] = pointA.texY;
//
//		vertexAttribs1[0] = pointB.winX;
//		vertexAttribs1[1] = pointB.winY;
//		vertexAttribs1[2] = pointB.objZ;
//		vertexAttribs1[3] = pointB.texX;
//		vertexAttribs1[4] = pointB.texY;
//
//		vertexAttribs2[0] = pointC.winX;
//		vertexAttribs2[1] = pointC.winY;
//		vertexAttribs2[2] = pointC.objZ;
//		vertexAttribs2[3] = pointC.texX;
//		vertexAttribs2[4] = pointC.texY;
//    }
//    float[] RasterCoords;
//    int nRasterCoords;
//	/** ��������� */
//	private final void drawTriangle() {
//		nRasterCoords = 0;
//		int ipos = 0;
//		putOrderedY(); // �Ѷ���Y���갴˳��ź�
//		getIncrements(); // ��������
//		putVertexAttribs();
//		float near = screenZ + 2, y = this.y;
//		float y02 = 0, y01 = 0, x02 = 0, x01 = 0;
//		float uAdd = 0, vAdd = 0, zAdd = 0, cAdd = 0;
//		boolean need = true;
//		for (; y <= endY; y++) {
//			intersection(y); // �����ɨ���ߵĽ���
//			float x = _x, endX = _endX;
//			if (x >= width || endX < 0)
//				continue;
//			if (x < 0)
//				x = 0;
//			if (endX >= width)
//				endX = width;
//			float ceil = (int) x, floor = (int) (endX);
//			x = (ceil == x) ? ceil : ceil + 1;
//			endX = endX == floor ? endX - 1 : floor;
//			if (x > endX)
//				continue;
//			for (; x <= endX; x++ ) {
//				RasterCoords[ipos] = x;
//				RasterCoords[ipos+1] = y;
//				ipos+=2;
//				nRasterCoords+=1;
//			}
//		}
//		if(nRasterCoords>0)
//		joclSample.Execute(nRasterCoords);
////		System.out.println(nRasterCoords);
//	}
//
//	/** ���㶥����� */
//	private final void vertexLight(Fragment p) {
//		p.normal.set(p.nrmX, p.nrmY, p.nrmZ);
//		Light.blinn_phong_lighting(p);
//	}
//
//	private final boolean isBackFace() {
//		// �� http://www.jurjans.lv/flash/shape.html
//		float cax = pointC.winX - pointA.winX;
//		float cay = pointC.winY - pointA.winY;
//		float bcx = pointB.winX - pointC.winX;
//		float bcy = pointB.winY - pointC.winY;
//		return cax * bcy > cay * bcx;
//	}
//	
//	private final void getIncrements() {
//		Fragment v0 = pointA, v1 = pointB, v2 = pointC;
//		winX01 = v1.winX - v0.winX;
//		winX02 = v2.winX - v0.winX;
//		winY01 = v1.winY - v0.winY;
//		winY02 = v2.winY - v0.winY;
//		objZ01 = v1.objZ - v0.objZ;
//		objZ02 = v2.objZ - v0.objZ;
//		clrA01 = v1.light - v0.light;
//		clrA02 = v2.light - v0.light;
//		if (TEXTURE_ON) {
//			u01 = v1.texX - v0.texX;
//			v01 = v1.texY - v0.texY;
//			u02 = v2.texX - v0.texX;
//			v02 = v2.texY - v0.texY;
//		}
//		float winY12 = winY2 - winY1, winX12 = winX2 - winX1;
//		k01 = winY01 == 0f ? 0 : winX01 / winY01;// ���ߵ�б�ʵĵ���
//		k02 = winY02 == 0f ? 0 : winX02 / winY02;
//		k12 = winY12 == 0f ? 0 : winX12 / winY12;
//	}
//	
//	private final void intersection(float y) {
//		int npoints = 0;
//		float intersect0 = 0, intersect1 = 0, intersect2 = 0;
//		if (order0 <= y && order1 >= y) {
//			intersect0 = (y - winY0) * k01 + winX0;
//			npoints++;
//		}
//		if (order2 <= y && order3 >= y) {
//			if (npoints == 1)
//				intersect1 = (y - winY0) * k02 + winX0;
//			else
//				intersect0 = (y - winY0) * k02 + winX0;
//			npoints++;
//		}
//		if (order4 <= y && order5 >= y) {
//			if (npoints == 1)
//				intersect1 = (y - winY1) * k12 + winX1;
//			else
//				intersect2 = (y - winY1) * k12 + winX1;
//			npoints++;
//		}
//		if (intersect0 < intersect1) {
//			_x = intersect0;
//			_endX = intersect1;
//		} else {
//			_x = intersect1;
//			_endX = intersect0;
//		}
//		if (npoints == 3) {
//			if (intersect2 < _x)
//				_x = intersect2;
//			else if (intersect2 > _endX)
//				_endX = intersect2;
//		}
//	}
//
//	private final boolean drawPass1() {
//		Fragment v0 = pointA, v1 = pointB, v2 = pointC;
//		winX0 = v0.winX;
//		winX1 = v1.winX;
//		winX2 = v2.winX;
//		winY0 = v0.winY;
//		winY1 = v1.winY;
//		winY2 = v2.winY;
//		int w = width, h = height;
//		if ((v0.winX < 0 && v1.winX < 0 && v2.winX < 0)
//				|| (v0.winX >= w && v1.winX >= w && v2.winX >= w))
//			return false;
//		y = winY0 < winY1 ? winY0 : winY1;
//		y = y < winY2 ? y : winY2;
//		endY = winY0 > winY1 ? winY0 : winY1;
//		endY = endY > winY2 ? endY : winY2;
//		if (endY < 0 || y > h || y == endY)
//			return false;
//		// ˮƽɨ���ߵ���ʼ������y����
//		if (y < 0)
//			y = 0;
//		if (endY >= h)
//			endY = h;
//		float ceil = (int) (y), floor = (int) (endY);
//		y = ceil == y ? ceil : ceil + 1;
//		endY = endY == floor ? floor - 1 : floor;
//		float far = screenZ + 1000;
//		float near = screenZ;
//		if ((y > endY) || (v0.objZ > far || v1.objZ > far || v2.objZ > far)
//				|| (v0.objZ < near && v1.objZ < near && v2.objZ < near))
//			return false;
//		return true;
//	}
//
//	public JOCLSample joclSample;
//	public final void beginScene() {
//		int[] a = pixels;
//		float[] buf1 = zBuffer;
//		for (int i = 0, len = a.length; i < len; i++) {
//			a[i] = 0;
//			buf1[i] = 999999999f;
//		}
//		if (ALPHA_BLENDING && blendFunc == BLEND_REVISE
//				&& (blend_stencil == null || blend_stencil.length < a.length))
//			blend_stencil = new float[a.length];
//		joclSample.begin(this);
//	}
//
//	public final void present() {
//		joclSample.finish(this);
//		graphics2D.drawImage(image, 8, 30, java.awt.Color.gray, null);// java.awt.Color.black
//	}
//
//	public void drawString(String str, int x, int y) {
//		bufferedGraphics.drawString(str, x, y);
//	}
//
//	public static void project(Vec3 v0, int i, int j) {
//		// TODO Auto-generated method stub
//		
//	}
//}