package soft3d.v0_1;

public class SoftMath {

	public static final float s_floor(float f){
		int iTruncate= (int)f;
		float fTruncate = iTruncate;
		if (f<0.0f && fTruncate!=f) {
			fTruncate = (float)(iTruncate-1);
		}
		return fTruncate;
	};
	public static final int s_ifloor(float f){
		int iTruncate= (int)f;
		float fTruncate = iTruncate;
		if (f<0.0f && fTruncate!=f) {
			iTruncate = (iTruncate-1);
		}
		return iTruncate;
	};
}
