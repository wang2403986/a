package soft3d.v0_1;

import java.util.Arrays;

import soft3d.Light;

public class VertexBuffer {
	
	public static int position = 0;
	public static int vertexSize = 8;
	
	public static int bufferPosition = 0;
	public static float[][] ensureCapacity(float[][] v,int capacity){
		if (v.length< capacity) {
			float[][] org = v;
			v = new float[org.length*3/2][];
			System.arraycopy(org, 0, v, 0, org.length);
		}
		return v;
	}
	public static int[][] ensureCapacity(int[][] v,int capacity){
		if (v.length< capacity) {
			int[][] org = v;
			v = new int[org.length*3/2][];
			System.arraycopy(org, 0, v, 0, org.length);
		}
		return v;
	}
	public static void pushBuffer(float[] vertices, int[] indices,
			float[] uvs, float[] normals,float[] screenBuf){
		int capacity = bufferPosition;
		if(faceBuffer.length< capacity) {
		
			faceBuffer = ensureCapacity(faceBuffer, capacity);
			vertexBuffer = ensureCapacity(vertexBuffer, capacity);
			texBuffer = ensureCapacity(texBuffer, capacity);
			winBuffer = ensureCapacity(winBuffer, capacity);
			normalBuffer = ensureCapacity(normalBuffer, capacity);
		}
		
		faceBuffer[bufferPosition]=indices;
		vertexBuffer[bufferPosition]=vertices;
		texBuffer[bufferPosition]=uvs;
		winBuffer[bufferPosition]=screenBuf;
		normalBuffer[bufferPosition] = normals;
		bufferPosition++;
	}
	public static int[][] faceBuffer= new int[10][];
	public static float[][] vertexBuffer= new float[10][];
	public static float[][] texBuffer= new float[10][];
	public static float[][] winBuffer= new float[10][];
	public static float[][] normalBuffer= new float[10][];
	
	public static int[] triangles=null;
	public static void pushTriangle(int indicesId,int offset){
		triangles[position++]=indicesId;
		triangles[position++]=offset;
	}
	public static void begin(){
		if (triangles==null) {
			triangles=new int[80000*2];
		}
		for (int i = 0; i < bufferPosition; i++) {
			int[] indices = faceBuffer[i];
			if (triangles.length< position + indices.length/3*2) {
				triangles = Arrays.copyOf(triangles, triangles.length + indices.length);
			}
			for (int j = 0; j < indices.length; j+=3) {
				pushTriangle(i, j);
			}
			
		}
	}
	public static int ZPrePass = 1;
	public static void drawElement(int pos,SoftGraphics3DV0_1 g,Point3D v1,Point3D v2,Point3D v3,Point3D frag,RenderBuffer renderBuffer){
		
		int id = VertexBuffer.triangles[pos];
		int offset = VertexBuffer.triangles[pos+1];
		int[] indices = faceBuffer[id];
		float[] vertices = vertexBuffer[id];
		float[] uvs = texBuffer[id];
		float[]screenBuf = winBuffer[id];
		float[] normals = normalBuffer[id];
		
		int off2d0 = 0, off2d1, off2d2, offs0, offs1, offs2;
		int i = offset;
		
		offs0 = indices[i] * 3;
		v1.objX = vertices[offs0];
		v1.objY = vertices[offs0 + 1];
		v1.objZ = vertices[offs0 + 2];
		offs1 = indices[i + 1] * 3;
		v2.objX = vertices[offs1];
		v2.objY = vertices[offs1 + 1];
		v2.objZ = vertices[offs1 + 2];
		offs2 = indices[i + 2] * 3;
		v3.objX = vertices[offs2];
		v3.objY = vertices[offs2 + 1];
		v3.objZ = vertices[offs2 + 2];
		off2d0 = indices[i] << 1;
		v1.winX = screenBuf[off2d0];
		v1.winY = screenBuf[off2d0 + 1];
		off2d1 = indices[i + 1] << 1;
		v2.winX = screenBuf[off2d1];
		v2.winY = screenBuf[off2d1 + 1];
		off2d2 = indices[i + 2] << 1;
		v3.winX = screenBuf[off2d2];
		v3.winY = screenBuf[off2d2 + 1];
		
		v1.texX = uvs[off2d0];
		v1.texY = uvs[off2d0 + 1];
		v2.texX = uvs[off2d1];
		v2.texY = uvs[off2d1 + 1];
		v3.texX = uvs[off2d2];
		v3.texY = uvs[off2d2 + 1];
		
		if (!g.drawPass1(v1, v2, v3) || (g.isBackFace(v1, v2, v3))){
			return;
		}
		if(normals!=null) {
			v1.nrmX = normals[offs0];
			v1.nrmY = normals[offs0 + 1];
			v1.nrmZ = normals[offs0 + 2];
			v2.nrmX = normals[offs1];
			v2.nrmY = normals[offs1 + 1];
			v2.nrmZ = normals[offs1 + 2];
			v3.nrmX = normals[offs2];
			v3.nrmY = normals[offs2 + 1];
			v3.nrmZ = normals[offs2 + 2];
			v1.normal.set(v1.nrmX, v1.nrmY, v1.nrmZ);
			v2.normal.set(v2.nrmX, v2.nrmY, v2.nrmZ);
			v3.normal.set(v3.nrmX, v3.nrmY, v3.nrmZ);
			Light.blinn_phong_lighting(v1);
			Light.blinn_phong_lighting(v2);
			Light.blinn_phong_lighting(v3);
		}
		if(renderBuffer==null){
			int fun = g.depthFunc;
			if (ZPrePass == 1)
				g.drawTriangleZPrePass(pos);
			else {
				g.depthFunc = 8;
				g.drawTriangle(v1, v2, v3, frag, pos);
			}
			g.depthFunc = fun;
		} else 
			g.drawTriangle(v1, v2, v3, frag, pos,renderBuffer);
	}
//	public void push(float[] e,int from, int size){
//		if (buffer.length< position+size ) {
//			float[] org = buffer;
//			buffer = new float[org.length*3/2];
//			System.arraycopy(org, 0, buffer, 0, org.length);
//		}
//		for (int i = 0; i < size; i++) {
//			buffer[position+i] = e[from+i];
//		}
//		position += vertexSize;
//	}
	public static void clear(){
		position = 0;
	}
	public static void clearBuffer(){
		VertexBuffer.bufferPosition=0;
	}
	static RenderBuffer[] renderBuffers=null;
	
	public static void flush(final SoftGraphics3DV0_1 g){
		if (renderBuffers==null) {
			RenderBuffer[] aaa={new RenderBuffer(),new RenderBuffer(),new RenderBuffer(),new RenderBuffer()};
			renderBuffers = aaa;
		}
//		System.out.println("main thread starting...");  
		  final int nThreads = 3;
		Thread[] list = new Thread[nThreads];  
		 int fromIndex=0;
		 int toIndex=position/2/nThreads;
		 final int endPos = position-1;
		int add = toIndex;
//		flush(0, width*height);
//		for (int j = 0; j < position; j+=2) {
//			test1(j, g, g.pointA, g.pointB, g.pointC, g.frag, renderBuffers[0]);
//		}
        for (int i = 0; i < nThreads ; i++)  
        {  
        	final int beginPos = i*2;
        	final RenderBuffer renderBuffer = renderBuffers[i];
        	final int i0= fromIndex+i*add;
			final int i1=toIndex+i*add;
			final Point3D v1=new Point3D();
			final Point3D v2=new Point3D();
			final Point3D v3=new Point3D();
			final Point3D v4=new Point3D();
            Thread my = new Thread(new Runnable() {
				
				@Override
				public void run() {
					renderBuffer.iRenderedPixels=0;
					// TODO Auto-generated method stub
					for (int j =beginPos/* i0*2*/; j < endPos/*i1*2*/; j+= 2*nThreads) {
						drawElement(j, g, v1, v2, v3, v4, renderBuffer);
					}
					g.flush_buffer(0, renderBuffer);
				}
			});
            my.start();  
            list[i]=(my);  
        }  
  
        try  
        {  
            for (Thread my : list)  
            {  
            	if(my!=null)
                my.join();  
            }  
        }  
        catch (InterruptedException e)  
        {  
            e.printStackTrace();  
        }  
 
//        System.out.println("main thread end...");  
	}
	public static void draw(final SoftGraphics3DV0_1 g){
		
		  
		// TODO Auto-generated method stub
		ZPrePass = 1;
		for (int j = 0; j < position; j+=2) {
			drawElement(j, g, g.pointA, g.pointB, g.pointC, g.frag,null);
		}
		ZPrePass = 0;
	}
}
