package soft3d.v0_1;
import static soft3d.Vec3.normalize;
import static soft3d.v0_1.ArrayUtil.array_set;
import soft3d.Light;
import soft3d.Vec3;
import soft3d.v0_1.Point3D;

public class GeneralFragPass extends FragPass {

	public GeneralFragPass(){
		final int maxVertexAttribs = 5;
		initVertexAttribs(maxVertexAttribs);// 17
	}
	@Override
	public void passGeometry(Point3D v0, Point3D v1, Point3D v2) {
		array_set(vertex0Attribs, v0.objX, v0.objY, v0.nrmX, v0.nrmY, v0.nrmZ);
		array_set(vertex1Attribs, v1.objX, v1.objY, v1.nrmX, v1.nrmY, v1.nrmZ);
		array_set(vertex2Attribs, v2.objX, v2.objY, v2.nrmX, v2.nrmY, v2.nrmZ);
		vectorsPassGeometry();
	}

	@Override
	public void passScanline(Point3D frag, float a, float b, float toX) {
		vectorsPassSpan(a, b);
	}

	@Override
	public void increment() {
		vectorsIncrement();
	}

	@Override
	public void passPixel(Point3D frag) {
		Vec3 nor = frag.normal;
		nor.set(varying[2], varying[3], varying[4]);
		frag.objX = varying[0];
		frag.objY = varying[1];
		normalize(nor);
		Light.blinn_phong_lighting(frag);
	}
	
}
