package soft3d.v0_1;

import static java.lang.Math.abs;
import static soft3d.Vec3.dot;
import static soft3d.Vec3.normalize;
import static soft3d.Vec3.vec3;
import static soft3d.v0_1.ArrayUtil.array_set;

import java.io.IOException;

import soft3d.Light;
import soft3d.Texture;
import soft3d.Vec3;
import soft3d.v0_1.Point3D;

/** ��Ⱦͨ· Pass */
public class FragPass {
	Point3D v0;
	public int id;
	float winY02, winY01;
	float winX01, winX02;
	float objX, objX01, objX02, objXAdd;
	float objY, objY01, objY02, objYAdd;
	float nrmX, nrmX01, nrmX02, nrmXAdd;
	float nrmY, nrmY01, nrmY02, nrmYAdd;
	float nrmZ, nrmZ01, nrmZ02, nrmZAdd;
	float d, d0, d01,d02, dAdd;
	
	public int maxVertexAttribs = 0;
	public float[] varying, vertex0Attribs, vertex1Attribs,
			vertex2Attribs, incs, dAttribs01, dAttribs02;
	public void initVertexAttribs(int MaxVertexAttribs){
		this.maxVertexAttribs = MaxVertexAttribs;
		varying = new float[MaxVertexAttribs];
		vertex0Attribs= new float[MaxVertexAttribs];
		vertex1Attribs= new float[MaxVertexAttribs];
		vertex2Attribs= new float[MaxVertexAttribs];
		incs = new float[MaxVertexAttribs];
		dAttribs01 = new float[MaxVertexAttribs];
		dAttribs02= new float[MaxVertexAttribs];
	}
	public final void vectorsPassGeometry(){
		for (int i = 0; i < maxVertexAttribs; i++) {
			dAttribs01[i] = vertex1Attribs[i] - vertex0Attribs[i];
			dAttribs02[i] = vertex2Attribs[i] - vertex0Attribs[i];
			incs[i] = winY02 * dAttribs01[i] - winY01 * dAttribs02[i];
		}
	}
	public final void vectorsPassSpan(float a, float b){
		for (int i = 0; i < maxVertexAttribs; i++) {
			varying[i] = vertex0Attribs[i] + a * dAttribs01[i] + b * dAttribs02[i];
		}
	}
	public final void vectorsIncrement(){
		for (int i = 0; i < maxVertexAttribs; i++) {
			varying[i] += incs[i];
		}
	}

	public void passGeometry(Point3D v0, Point3D v1, Point3D v2) {
		if (textures == null) {
			textures = new Texture[] { SoftGraphics3DV0_1.texture };
		}
		this.v0 = v0;
		objX01 = (v1.objX - v0.objX);
		objX02 = (v2.objX - v0.objX);
		objXAdd = winY02 * objX01 - winY01 * objX02;

		objY01 = (v1.objY - v0.objY);
		objY02 = (v2.objY - v0.objY);
		objYAdd = winY02 * objY01 - winY01 * objY02;

		nrmX01 = (v1.nrmX - v0.nrmX);
		nrmX02 = (v2.nrmX - v0.nrmX);
		nrmXAdd = winY02 * nrmX01 - winY01 * nrmX02;

		nrmY01 = (v1.nrmY - v0.nrmY);
		nrmY02 = (v2.nrmY - v0.nrmY);
		nrmYAdd = winY02 * nrmY01 - winY01 * nrmY02;

		nrmZ01 = (v1.nrmZ - v0.nrmZ);
		nrmZ02 = (v2.nrmZ - v0.nrmZ);
		nrmZAdd = winY02 * nrmZ01 - winY01 * nrmZ02;
	}

	public void passScanline(Point3D frag, float a, float b, float toX) {
		objX = v0.objX + a * objX01 + b * objX02;
		objY = v0.objY + a * objY01 + b * objY02;
		nrmX = v0.nrmX + a * nrmX01 + b * nrmX02;
		nrmY = v0.nrmY + a * nrmY01 + b * nrmY02;
		nrmZ = v0.nrmZ + a * nrmZ01 + b * nrmZ02;
	}

	public void increment() {
		objX += objXAdd;
		objY += objYAdd;
		nrmX += nrmXAdd;
		nrmY += nrmYAdd;
		nrmZ += nrmZAdd;
	}

	static final Vec3 L = vec3(0, 0, 0), NL = vec3(0, 0, 0),
			V = vec3(0, 0, 0);
	public static final Vec3 g_LightPos = vec3(-600f, 0f, -1024f),
			g_eyePos = vec3(0f, 0f, 0f);
	final float[] texcoord = { 0, 0, 0, 0 }, newCoord = { 0, 0, 0, 0 };

	public void passPixel(Point3D frag) {

		Vec3 nor = frag.normal;
		nor.set(nrmX, nrmY, nrmZ);
		normalize(nor);
		frag.objX=objX;
		frag.objY=objY;
		Light.blinn_phong_lighting(frag);
		/**
		L.set(frag.objX, frag.objY, frag.objZ);
		normalize(L);
		
		reflect(L, N);
		normalize(R);
		texcoord[0] = R.x;
		texcoord[1] = R.y;
		texcoord[2] = R.z;
//		texcoord[0] = -N.x;
//		texcoord[1] = -N.y;
//		texcoord[2] = -N.z;
		Texture t = choose_cube_face(textures, texcoord, newCoord);
		float u = newCoord[0];
		float v = newCoord[1];
		t.getRGB(u, v, frag);
		**/
	}

	public static final int getA(int c) {
		return c >> 24 & 0xff;
	}

	public static final int getR(int c) {
		return c >> 16 & 0xff;
	}

	public static final int getG(int c) {
		return c >> 8 & 0xff;
	}

	public static final int getB(int c) {
		return c & 0xff;
	}

	public static Texture[] textures;
	static {
		try { // ����cube map
			String f = "C:/Users/Admin/Desktop/���н�ͼ/image/";
			textures = new Texture[] { new Texture(f + "POS_X.jpg"),
					new Texture(f + "NEG_X.jpg"),
					new Texture(f + "NEG_Y.jpg"),
					new Texture(f + "POS_Y.jpg"),
					new Texture(f + "POS_Z.jpg"),
					new Texture(f + "NEG_Z.jpg") };
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	static final Vec3 R = vec3(0f, 0f, 0f);

	static final void reflect(Vec3 L, Vec3 n) {
		/* L-2*(L*n)*n */; // 2 * ( N dot L) * N - L
		float dot = dot(L, n);
		if (dot < 0)
			dot = 0;
		R.x = L.x - 2 * dot * n.x;
		R.y = L.y - 2 * dot * n.y;
		R.z = L.z - 2 * dot * n.z;
	}

	static final int FACE_POS_X = 0, FACE_NEG_X = 1, FACE_POS_Y = 2,
			FACE_NEG_Y = 3, FACE_POS_Z = 4, FACE_NEG_Z = 5;

	// static final int FACE_POS_X = 0, FACE_NEG_X = 3, FACE_POS_Y = 1,
	// FACE_NEG_Y = 4, FACE_POS_Z = 2, FACE_NEG_Z = 5;
	static final Texture choose_cube_face(Texture[] texObj, float[] texcoord,
			float[] newCoord) {
		/*
		 * major axis direction target sc tc ma ----------
		 * ------------------------------- --- --- --- +rx
		 * TEXTURE_CUBE_MAP_POSITIVE_X_EXT -rz -ry rx -rx
		 * TEXTURE_CUBE_MAP_NEGATIVE_X_EXT +rz -ry rx +ry
		 * TEXTURE_CUBE_MAP_POSITIVE_Y_EXT +rx +rz ry -ry
		 * TEXTURE_CUBE_MAP_NEGATIVE_Y_EXT +rx -rz ry +rz
		 * TEXTURE_CUBE_MAP_POSITIVE_Z_EXT +rx -ry rz -rz
		 * TEXTURE_CUBE_MAP_NEGATIVE_Z_EXT -rx -ry rz
		 */
		float rx = texcoord[0];
		float ry = texcoord[1];
		float rz = texcoord[2];
		float arx = abs(rx), ary = abs(ry), arz = abs(rz);
		int face;
		float sc, tc, ma;

		if (arx >= ary && arx >= arz) {
			if (rx >= 0.0F) {
				face = FACE_POS_X;
				sc = -rz;
				tc = -ry;
				ma = arx;
			} else {
				face = FACE_NEG_X;
				sc = rz;
				tc = -ry;
				ma = arx;
			}
		} else if (ary >= arx && ary >= arz) {
			if (ry >= 0.0F) {
				face = FACE_POS_Y;
				sc = rx;
				tc = rz;
				ma = ary;
			} else {
				face = FACE_NEG_Y;
				sc = rx;
				tc = -rz;
				ma = ary;
			}
		} else {
			if (rz > 0.0F) {
				face = FACE_POS_Z;
				sc = rx;
				tc = -ry;
				ma = arz;
			} else {
				face = FACE_NEG_Z;
				sc = -rx;
				tc = -ry;
				ma = arz;
			}
		}

		{
			float ima = 1.0F / ma;
			newCoord[0] = (sc * ima + 1.0F) * 0.5F;
			newCoord[1] = (tc * ima + 1.0F) * 0.5F;
		}

		return texObj[face];
	}

}
