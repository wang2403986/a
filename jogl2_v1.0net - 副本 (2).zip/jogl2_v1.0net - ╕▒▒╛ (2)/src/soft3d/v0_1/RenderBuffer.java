package soft3d.v0_1;

public class RenderBuffer {

	public static final int size_of_each_element =4;
	public static final int max_local_memory =256*8;
	
	public PixelBuffer[] buffer= new PixelBuffer[max_local_memory];
	public RenderBuffer() {
		// TODO Auto-generated constructor stub
		for (int i = 0; i < buffer.length; i++) {
			buffer[i] = new PixelBuffer();
		}
	}
	public int iRenderedPixels = 0;
	
	
	public static class PixelBuffer{
		public int faceId;
		public int pixelId;
		public int color;
		public float z;
	}
}
