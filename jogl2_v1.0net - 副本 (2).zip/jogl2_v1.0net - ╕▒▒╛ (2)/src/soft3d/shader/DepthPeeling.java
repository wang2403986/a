package soft3d.shader;


/**
 * depth peeling Test
 * @author Administrator
 *
 */
public class DepthPeeling {
//	public static final boolean PreferDepthPeeling=false;
	public static final boolean PreferDepthPeeling=false;
	public static final int width=PreferDepthPeeling?1024:1;
	public static final int height=PreferDepthPeeling?680:1;
	public static final float[] frontZBuffer = new float[width*height];
	public static final float[] frontZNext = new float[width*height];
//	public static final float[] headZBuffer = new float[width*height];
//	float[] backZBuffer,backZBuffer1;
//	public static final int[] nLayersBuffer = new int[width*height];
	public static int nLayers=0;
	public static int pass=0;
	public static boolean completed=true;
	public DepthPeeling(){
		
	}
	public static final short pass_front_to_back=1,pass_find_topmost=2;
	
	public static void clear() {
//		float bottomZ=Float.MAX_VALUE;
		int toIndex=frontZBuffer.length;
		for (int i = 0; i < toIndex; i++) {
			frontZBuffer[i]=999999999f;
			frontZNext[i]=999999999f;
//			nLayersBuffer[i]=0;
		}
		nLayers=0;
	}
}
