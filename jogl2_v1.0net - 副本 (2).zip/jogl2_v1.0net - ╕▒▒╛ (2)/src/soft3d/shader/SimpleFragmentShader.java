package soft3d.shader;

import soft3d.Light;
import soft3d.SoftGraphics3D.Vertex;
import static soft3d.SoftGraphics3D.PreferPerPixelLighting;
import static soft3d.SoftGraphics3D.LINEAR_FILTER;
import static soft3d.SoftGraphics3D.texture;
import static soft3d.SoftGraphics3D.LIGHT_ON;
import static soft3d.SoftGraphics3D.TEXTURE_ON;
import static soft3d.SoftGraphics3D.AlphaGreater;
import static soft3d.SoftGraphics3D.AlphaLess;

/**
 * �����ع���
 * @author Administrator
 *
 */
public final class SimpleFragmentShader {
	public static final Vertex fragColor=new Vertex();
	static{
		fragColor.setRGB(255, 128, 128, 128);
	}
	/**
	 * Fragment Shader
	 * @param v
	 * @param index
	 * @param src_a
	 * @param dstColor
	 * @return
	 */
	public static final int frag_shading(Vertex frag,int index,int src_a,int dstColor) {
		
		if (LINEAR_FILTER)
			texture.getBilinearRGB(frag);
		else if(TEXTURE_ON)
			texture.getRGB(frag);
		else {
			frag.setRGB(255,128,128,128);
		}
		int a=frag.a;
		if (a < AlphaGreater || a >= AlphaLess)// ͸������Alpha Test
			return 0;
		/* �����ع���*/
//		if(PreferPerPixelLighting)
//			Light.blinn_phong_lighting(frag);
		if (LIGHT_ON) {
			int l = (int) frag.l;
			int ar = frag.r + l, ag = frag.g + l, ab = frag.b + l;
			frag.r = ar > 255 ? 255 : ar < 0 ? 0 : ar;
			frag.g = ag > 255 ? 255 : ag < 0 ? 0 : ag;
			frag.b = ab > 255 ? 255 : ab < 0 ? 0 : ab;
		}
		
		return 1;
	}
	
}
