package soft3d.shader;

import soft3d.Light;
import soft3d.SoftGraphics3D.Vertex;

public class SimpleVertexShader {
 public static int vertex_shading(Vertex v) {
	return Light.blinn_phong_lighting(v);
	
}
}
