package soft3d.shader;

import soft3d.SoftGraphics3D.Vertex;
import static soft3d.shader.DepthPeeling.*;

/**
 * ˳���޹ص�͸��(OIT,Order-independent Transparent): Depth Peeling Shader
 * 
 * @author Admin
 * @version $Id: DepthPeelingFragmentShader.java, v 0.1 2014��10��9�� ����2:53:11 Admin Exp $
 */
public class DepthPeelingFragmentShader {
	
    public static final int frag_shading(Vertex vertex,int index,int src_a,int dstColor) {
        
        float z=vertex.z;
        if (pass==pass_front_to_back) {
        	float bufz=frontZBuffer[index];
            if (z==bufz) {         
//                int dest_a = (dstColor >> 24) & 0xff;// Ŀ��ɫ͸����
//                if (dest_a<=2)return 0;
            	//DepthPeeling.headZBuffer[index]=z;
                if(src_a<=240)completed=false;
                return 1;
            } else if (z>bufz&&z<frontZNext[index]) {
            	frontZNext[index]=z;
            }
        }else if (pass==pass_find_topmost) {
            if (z<frontZBuffer[index]) {
                frontZBuffer[index]=z;
            }
         }
        return 0;
    }
    public static final void clear() {
        float bottomZ=999999999f;
        float[] frontZBuf1=frontZNext;
        float[] frontZBuf=frontZBuffer;
        int toIndex=frontZBuf1.length;
        for (int j = 0; j < toIndex; j++) {
            frontZBuf[j]=bottomZ;
            frontZBuf1[j]=bottomZ;
      }
    }
}