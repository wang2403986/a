package soft3d.util.math;

import static java.lang.Float.floatToRawIntBits;
import static java.lang.Float.intBitsToFloat;

public class FastMath {
	public static float powf(final double a, final double b) {
		final int x = (int) (Double.doubleToRawLongBits(a) >> 32);
		final int y = (int) (b * (x - 1072632447) + 1072632447);
		return (float) Double.longBitsToDouble(((long) y) << 32);
	}
	public static double pow(final double a, final double b) {
		final int x = (int) (Double.doubleToRawLongBits(a) >> 32);
		final int y = (int) (b * (x - 1072632447) + 1072632447);
		return Double.longBitsToDouble(((long) y) << 32);
	}

	public static double exp(double val) {
		final long tmp = (long) (1512775 * val + 1072632447);
		return Double.longBitsToDouble(tmp << 32);
	}

	public static double log(double x) {
		return 6 * (x - 1) / (x + 1 + 4 * (Math.sqrt(x)));
	}

	public static double pow1(double a, double b) {
		final long tmp = (long) (9076650 * (a - 1) / (a + 1 + 4 * (sqrt(a)))
				* b + 1072632447);
		return Double.longBitsToDouble(tmp << 32);
	}

	/**
	 * fast inverse square root : 1.0/sqrt(value)
	 * 
	 * @param x
	 * @return
	 */
	public static final float fastInvSqrt(float x) {
		float xhalf = 0.5f * x;
		int i = floatToRawIntBits(x); // get bits for floating VALUE
		i = 0x5f375a86 - (i >> 1); // gives initial guess y0
		x = intBitsToFloat(i); // convert bits BACK to float
		x = x * (1.5f - xhalf * x * x); // Newton step, repeating increases
										// accuracy
										// x = x * (1.5f - (xhalf * x * x)); //
										// 2nd iteration, this can be removed
		return x;
	}

	/**
	 * The second pass gives you almost the exact value of the square root. <br>
	 * 
	 * sqrt 17022.533813476562 <br>
	 * better 17010.557763511835 <br>
	 * evenbetter 17010.553547724947 <br>
	 * Math.sqrt() 17010.553547724423 <br>
	 **/
	public static double sqrt(double d) {
		// double d = 289358932.0;
		double sqrt = Double
				.longBitsToDouble(((Double.doubleToRawLongBits(d) - (1l << 52)) >> 1)
						+ (1l << 61));
		// double better = (sqrt + d/sqrt)/2.0;
		// double evenbetter = (better + d/better)/2.0;

		return sqrt;
	}

	public static float sqrt(final float x) {
		int ui = Float.floatToRawIntBits(x);
		ui = (1 << 29) + (ui >> 1) - (1 << 22);
		float ux = Float.intBitsToFloat(ui);

		// Two Babylonian Steps (simplified from:)
		// u.x = 0.5f * (u.x + x/u.x);
		// u.x = 0.5f * (u.x + x/u.x);
		ux = ux + x / ux;
		ux = 0.25f * ux + x / ux;

		return ux;
	}

	public static int roundUpToNextPowerOfTwo(int x) {
		x--;
		x |= x >> 1; // handle 2 bit numbers
		x |= x >> 2; // handle 4 bit numbers
		x |= x >> 4; // handle 8 bit numbers
		x |= x >> 8; // handle 16 bit numbers
		x |= x >> 16; // handle 32 bit numbers
		x++;

		return x;
	}
	public static double sin(double x){
		double sin, cos;
		//always wrap input angle to -PI..PI
		if (x< -3.14159265)
		    x+= 6.28318531;
		else
		if (x>  3.14159265)
		    x-= 6.28318531;

		//compute sine
		if (x< 0)
		    sin= 1.27323954 * x+ .405284735 * x* x;
		else
		    sin= 1.27323954 * x- 0.405284735 * x* x;

		//compute cosine: sin(x + PI/2) = cos(x)
//		x+= 1.57079632;
//		if (x>  3.14159265)
//		    x-= 6.28318531;
//
//		if (x< 0)
//		    cos= 1.27323954 * x+ 0.405284735 * x* x;
//		else
//		    cos= 1.27323954 * x- 0.405284735 * x* x;
		return sin;
	}
	public static double cos(double x){
		double sin, cos;
		//always wrap input angle to -PI..PI
		if (x< -3.14159265)
		    x+= 6.28318531;
		else
		if (x>  3.14159265)
		    x-= 6.28318531;

		//compute sine
//		if (x< 0)
//		    sin= 1.27323954 * x+ .405284735 * x* x;
//		else
//		    sin= 1.27323954 * x- 0.405284735 * x* x;

		//compute cosine: sin(x + PI/2) = cos(x)
		x+= 1.57079632;
		if (x>  3.14159265)
		    x-= 6.28318531;

		if (x< 0)
		    cos= 1.27323954 * x+ 0.405284735 * x* x;
		else
		    cos= 1.27323954 * x- 0.405284735 * x* x;
		return cos;
	}
	public static double w_sin(double x){
		double sin,cos;
	//always wrap input angle to -PI..PI
	if (x< -3.14159265)
	    x+= 6.28318531;
	else
	if (x>  3.14159265)
	    x-= 6.28318531;

	//compute sine
	if (x< 0)
	{
	    sin= 1.27323954 * x+ .405284735 * x* x;

	   if (sin< 0)
	        sin= .225 * (sin*-sin- sin) + sin;
	   else
	        sin= .225 * (sin* sin- sin) + sin;
	}
	else
	{
	    sin= 1.27323954 * x- 0.405284735 * x* x;

	   if (sin< 0)
	        sin= .225 * (sin*-sin- sin) + sin;
	   else
	        sin= .225 * (sin* sin- sin) + sin;
	}

	//compute cosine: sin(x + PI/2) = cos(x)
	x+= 1.57079632;
	if (x>  3.14159265)
	    x-= 6.28318531;

	if (x< 0)
	{
	    cos= 1.27323954 * x+ 0.405284735 * x* x;

	   if (cos< 0)
	        cos= .225 * (cos*-cos- cos) + cos;
	   else
	        cos= .225 * (cos* cos- cos) + cos;
	}
	else
	{
	    cos= 1.27323954 * x- 0.405284735 * x* x;

	   if (cos< 0)
	        cos= .225 * (cos*-cos- cos) + cos;
	   else
	        cos= .225 * (cos* cos- cos) + cos;
	}
	return sin;
	}
	public static void main(String[]ss){
		for (double i =-Math.PI; i < Math.PI; i+=Math.PI/20) {
			System.out.println("ours sin = "+w_sin(i)+",Math.sin = " + Math.sin(i));
		}
		for (double i =-Math.PI; i < Math.PI; i+=Math.PI/20) {
			System.out.println("ours cos = "+cos(i)+",Math.cos = " + Math.cos(i));
		}
	}
}
