package soft3d.util;
/**
 * һ��ͨ�õĶ���ṹ
 * @author Administrator
 *
 */
public class CustomVertex {
	public float[]	pos;
	public float[]	normal;
	public float[]	tangent;
	public float[]	tex;
	
}
