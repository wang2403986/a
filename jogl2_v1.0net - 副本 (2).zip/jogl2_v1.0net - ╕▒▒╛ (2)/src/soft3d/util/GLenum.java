package soft3d.util;

public class GLenum {
	public static final int ZERO = 0;
	public static final int SRC_ALPHA = 1;
	public static final int ONE_MINUS_SRC_ALPHA = 2;
	public static final int ONE_MINUS_DST_COLOR = 3;
	public static final int ONE = 4;
	public static final int DST_ALPHA = 5;
	public static final int ONE_MINUS_SRC_ALPHA_MUL_DST_ALPHA = 0xff;
}
