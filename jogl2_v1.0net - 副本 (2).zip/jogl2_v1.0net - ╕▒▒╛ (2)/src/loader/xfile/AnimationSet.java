package loader.xfile;

import java.util.List;

public class AnimationSet {
	public String name;
	public List<Animation> animations;
}
