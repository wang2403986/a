package loader.xfile;

import java.awt.Rectangle;
import java.util.Arrays;
import java.util.List;

import soft3d.Matrix;
import soft3d.SoftGraphics3D;
import soft3d.Texture;
import soft3d.Vec3;
import static soft3d.SoftGraphics3D.LIGHT_ON;
import static soft3d.SoftGraphics3D.computeNormals;

public class XMesh {
	//public Extent extent;
	public Rectangle screenBounds = new Rectangle(10,10);
	public boolean visible = true;
	public int nVertices;
	public int[] indices;
	public float[] vertices;
	public float[] texCoords;
	public float[] normals;
	
	public float[] normalsBuf;
	public float[] verticesBuf;
	public float[] screenBuf;
	/**
	 * faceStart-faceEnd-materialIndex
	 */
	public List<int[]> faceGroups;
	
	public List<SkinWeights> skinWeightsList;
	public int[] materialIndices;
	public List<Material> materials;
	public List<Texture> textures;
	public List<String> materialNames;
	
	private final float[][] _mat0={{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};
	private final float[][] buf1={{1,0,0,0},{0,1,0,0},{0,0,1,0},{0,0,0,1}};
	public void updateNoskin(XFrame frame) {
		//����ǰ��׼������
		if (LIGHT_ON && (normals == null||normals.length!=vertices.length)){
			normals = new float[vertices.length];
			computeNormals(vertices, indices, normals);
		}
		final float[][] mat0=_mat0;
		float interp = frame.interpolation;
//		interp = 0;
		float[][] transfrom= frame.frameTransformMatrix;
		Matrix.mul(transfrom, SoftGraphics3D.transform, mat0);
		Matrix.transform(vertices,mat0, verticesBuf, 1-interp);
		Matrix.getNormalMatrix(mat0, buf1);
		Matrix.transform(normals,buf1, normalsBuf, 1-interp);
		if(interp != 0.0f) {
		transfrom = frame.nextKeyframeTransform;
		Matrix.mul(transfrom, SoftGraphics3D.transform, mat0);
		Matrix.transform(vertices,mat0, verticesBuf, interp);
		Matrix.getNormalMatrix(mat0, buf1);
		Matrix.transform(normals,buf1, normalsBuf, interp);
		}
		
		if (screenBuf == null)
			screenBuf = new float[nVertices*2];
		SoftGraphics3D.project(verticesBuf, screenBuf);
		//��������Ļ�ϵĴ�С
		SoftGraphics3D.getBounds(screenBuf,screenBounds);
		/* Need to be normalized?*/
		if (normalsBuf.length>3) {
			float x0=normalsBuf[0];
			float y0=normalsBuf[1];
			float z0=normalsBuf[2];
			float m=x0*x0+y0*y0+z0*z0;
			if (m>0.6f&&m<1.4f) {
				
			} else if(m!=0f){//Need to be normalized
				Vec3.normalizeAll(normalsBuf);
			}
		}
//		if (LIGHT_ON)computeNormals(verticesBuf, indices, normals);
	}
	public void update(XFrame frame) {
		if (verticesBuf==null) {
			verticesBuf=new  float[vertices.length];
		}
		final float[][] mat0=_mat0;
		Arrays.fill(verticesBuf, 0);
		if (normalsBuf==null) {
			normalsBuf=new float[vertices.length];
		} else Arrays.fill(normalsBuf, 0);
		if (skinWeightsList==null) {
			updateNoskin(frame);
			return;
		}
		Matrix.loadIdentity(mat0);
		Matrix.loadIdentity(buf1);
		boolean needCalcNormal=normals == null||normals.length!=vertices.length;
		for (SkinWeights skin :skinWeightsList) {
			XFrame node = skin.node;
			if (node==null||skin.vertexIndices==null) {
				continue;
			}
			float[][] boneTrans=skin.matrixOffset;
			float[][] transfrom= node.frameTransformMatrix;
			Matrix.mul(boneTrans, transfrom, mat0);
			Matrix.mul(mat0, SoftGraphics3D.transform, mat0);
			int[] indices=skin.vertexIndices;
			float[] weights=skin.weights;
//			node.interpolation=0;
			float interp = node.interpolation;
			Matrix.transform(vertices,mat0,weights,indices, verticesBuf, 1-interp);
			float[][] normMat = Matrix.getNormalMatrix(mat0, buf1);
			if(!needCalcNormal)
			Matrix.transform(normals,normMat,weights,indices, normalsBuf, 1-interp);
			
			if(interp==0.0f) continue;
			transfrom= node.nextKeyframeTransform;
			Matrix.mul(boneTrans, transfrom, mat0);
			Matrix.mul(mat0, SoftGraphics3D.transform, mat0);
			Matrix.transform(vertices,mat0,weights,indices, verticesBuf, interp);
			normMat = Matrix.getNormalMatrix(mat0, buf1);
			if(!needCalcNormal)
			Matrix.transform(normals,normMat,weights,indices, normalsBuf, interp)
			;
		}
		
		//����ǰ��׼������
		if (SoftGraphics3D.LIGHT_ON && needCalcNormal){
			if (normals!=null&&vertices.length!=normals.length)
				System.err.println("length of vertices no equals length of normals !");
			normals = new float[vertices.length];
			computeNormals(vertices, indices, normals);
		}
		if (screenBuf == null)
			screenBuf = new float[nVertices*2];
		SoftGraphics3D.project(verticesBuf, screenBuf);
		//��������Ļ�ϵĴ�С
		SoftGraphics3D.getBounds(screenBuf,screenBounds);
//		if (LIGHT_ON)computeNormals(verticesBuf, indices, normals);
	}
	public void reset() {
		for (int i = 0; i < vertices.length; i++) {
			verticesBuf[i]=vertices[i];
		}
	}
}
