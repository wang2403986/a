package loader.xfile;

public class SkinWeights {
	public String nodeName;
	public XFrame node;
	public int nWeights;
	
	public int[] vertexIndices;
	public float[] weights;
	
	public float[][] matrixOffset;
}
