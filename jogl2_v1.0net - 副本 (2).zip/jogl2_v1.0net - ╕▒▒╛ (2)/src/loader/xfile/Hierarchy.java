package loader.xfile;

import java.util.ArrayList;
import java.util.List;

public class Hierarchy {
	public String header;
	public List<String> datas=new ArrayList<String>();
	
	public List<Hierarchy> children=new ArrayList<Hierarchy>();
	
}
