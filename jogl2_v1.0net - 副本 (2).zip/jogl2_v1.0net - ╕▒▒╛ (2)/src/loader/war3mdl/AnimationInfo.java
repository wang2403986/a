package loader.war3mdl;

public class AnimationInfo {
	public String name;
	public int[] Interval;
	public boolean NonLooping=false;
	public float[] MinimumExtent;
	public float[] MaximumExtent;
	public float BoundsRadius;
}
