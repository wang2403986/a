package loader.war3mdl;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;

import com.sun.opengl.util.texture.Texture;
import com.sun.opengl.util.texture.TextureData;
import com.sun.opengl.util.texture.TextureIO;

import javax.media.opengl.GL2;
import javax.media.opengl.glu.GLU;

/**
 * ħ������3 MDL ģ����
 * @version CopyRright @ 2013 �Ϸ���ͬ��Ϣ����
 * @author <a href="http://www.zhitong.com">����<a/>
 * @since 2013-11-29
 * 
 */
public class War3MdlModel {
	public List<Geoset> geosets;
	public List<Bone> bones;
	public List<Bone> rootList;
	public Textures textures;
	int[] texIndices;
	public Materials materials;
	public Sequences sequences;
	/**
	 * ���ĵ�
	 */
	public List<float[]> pivotPoints;
	boolean loaded = false;
	public float[] localRot=new float[4];
	public float[] localTrans=new float[4];
	public float[] localScale=new float[]{1,1,1};
	/**
	 * Animation
	 */
	public int animation= -1;
	/**
	 * ״̬��0��վ��,1:�ƶ���
	 */
	public int status = 0;
	public long time=System.currentTimeMillis();
	public long moveStartTime,moveEndTime;
	public final float[] startPosition=new float[4];

	public TokenStack stack = new TokenStack();
	public static String delim = "\t\n\r\f ,";

	public List<Texture> creatTexture(GL2 gl, GLU glu,
			String folder) {
		texIndices = new int[this.textures.imageNames.size()];
		this.textures.texArray = new ArrayList<Texture>(
				this.textures.imageNames.size());
		try {
			for (String s : this.textures.imageNames) {
				s = s.substring(0, s.length() - 1 - 3) + ".JPG";
				InputStream stream = new FileInputStream(folder + s);
				TextureData data = TextureIO.newTextureData(stream, false,
						"JPG");
				Texture texture = TextureIO.newTexture(data);
				this.textures.texArray.add(texture);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

		return this.textures.texArray;

	}
	float[] quat ={0,0,0,1};
	/**
	 * ���ֲ���
	 * @param array Array
	 * @param n ������index
	 * @param v ֵ
	 * @param trs Array������TRS
	 * @param bone ����
	 * @return
	 */
	int binarySearch(List<float[]> array, int n, float v, int trs, Bone bone) {
		int left, right, middle = 0;

		left = 0;
		right = n;
		boolean hit = false;
		
		boolean middleHigher=true;

		while (left < right) {
			middle = (left + right) / 2;

			if (array.get(middle)[0] > v) {
				middleHigher=true;
				right = middle;
			} else if (array.get(middle)[0] < v) {
				middleHigher=false;
				left = middle + 1;
			} else {
				hit = true;
				break;
				// return middle;
			}
		}

		if (hit) {
			float[] obj = array.get(middle);

			switch (trs) {

			case 0:
				bone.currentTranslation[0] = obj[1];
				bone.currentTranslation[1] = obj[2];
				bone.currentTranslation[2] = obj[3];
				break;
			case 1:
				quat[0] = obj[1];quat[1] = obj[2];quat[2] = obj[3];quat[3] =  -obj[4];
				// Quaternion.Quaternion3DNormalize(quat);
				Quaternion.Quaternion2Matrix(quat, bone.currentRotation);

				break;
			default:
				break;
			}

		} else {
			float[] obj0 = array.get(left);
			float[] obj1 = obj0;
			if (middleHigher) {
				int i0=0;
				
				if(middle-1>0)i0=middle-1;
				obj0 = array.get(i0);
				obj1=array.get(middle);
			}
			else{
				int i1=middle;
				if(middle+1<=n)
					i1=middle+1;
				obj0 = array.get(middle);
				obj1=array.get(i1);
			}
			
			float beginTime =  obj0[0];
			float endTime = obj1[0];
			float r = (v - beginTime) / (endTime - beginTime);
			switch (trs) {
			case 0:
				float x = obj0[1] + r * (obj1[1] - obj0[1]);
				float y = obj0[2] + r * (obj1[2] - obj0[2]);
				float z = obj0[3] + r * (obj1[3] - obj0[3]);
				bone.currentTranslation[0] = x;
				bone.currentTranslation[1] = y;
				bone.currentTranslation[2] = z;
				break;
			case 1:
				float qx = obj0[1] + r * (obj1[1] - obj0[1]);
				float qy = obj0[2] + r * (obj1[2] - obj0[2]);
				float qz = obj0[3] + r * (obj1[3] - obj0[3]);
				float qw = obj0[4] + r * (obj1[4] - obj0[4]);
				quat[0]= qx; quat[1]=qy;quat[2]= qz;quat[3]= -qw;
				Quaternion.Quaternion3DNormalize(quat);
				Quaternion.Quaternion2Matrix(quat, bone.currentRotation);
				break;
			default:
				break;
			}

		}
		return -1;
	}

	public void updateByTime(long time, GL2 gl) {
		this.time =  time;
		if(status==1)
			this.sequences.setAnimIndex(0);
		else if(status==0)
			this.sequences.setAnimIndex(2);
		else
			this.sequences.setAnimIndex(2);
		int begin= this.sequences.timeInterval[0];
		int end=this.sequences.timeInterval[1];
		if (time > end - begin)
			time = time % (end - begin);
		time = time + begin;
		
		for (Bone bone : bones) {
			if (bone.Rotation != null) {
				binarySearch(bone.Rotation, bone.Rotation.size() - 1,
						(float) time, 1, bone);
			}

			if (bone.Translation != null) {
				binarySearch(bone.Translation, bone.Translation.size() - 1,
						(float) time, 0, bone);
			}
		}
		updateBonesMatrix(gl);
	}
	final ArrayList<float[]>  matrix_stack=new ArrayList<float[]>();
	final float[] _mat_buf2={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	final float[] _mat_buf1={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	public void updateBonesMatrix(GL2 gl) {
		gl.glMatrixMode(GL2.GL_MODELVIEW);
		gl.glPushMatrix();
		gl.glLoadIdentity();
		gl.glTranslatef(0.0f, 0.0f, -1000.0f);
		gl.glTranslatef(localTrans[0], localTrans[1], localTrans[2]);
		gl.glRotatef(localRot[0], 1, 0, 0);
		gl.glRotatef(localRot[1], 0, 1, 0);
		gl.glRotatef(localRot[2], 0, 0, 1);
		gl.glPushMatrix();
		
		for (Bone i : bones) {
			// ��ǰ����
			Bone self = i;
			matrix_stack.clear();
			// ��ǰ�����任
			gl.glLoadIdentity();

			gl.glTranslatef(i.currentTranslation[0], i.currentTranslation[1],
					i.currentTranslation[2]);
			gl.glMultMatrixf(i.currentRotation, 0);
			
			gl.glTranslatef(-self.pivotPoint[0], -self.pivotPoint[1],
					-self.pivotPoint[2]);
			gl.glGetFloatv(GL2.GL_MODELVIEW_MATRIX, i.bufMatrix, 0);
			matrix_stack.add(i.bufMatrix);
			while (i.parentBone != null) {
				// ��ǰ����
				Bone child = i;
				
				i = i.parentBone;
				gl.glLoadIdentity();

				gl.glTranslatef(i.currentTranslation[0],
						i.currentTranslation[1], i.currentTranslation[2]);
				gl.glMultMatrixf(i.currentRotation, 0);
				
				float tx = child.pivotPoint[0] - i.pivotPoint[0];
				float ty = child.pivotPoint[1] - i.pivotPoint[1];
				float tz = child.pivotPoint[2] - i.pivotPoint[2];
				gl.glTranslatef(tx, ty, tz);

				gl.glGetFloatv(GL2.GL_MODELVIEW_MATRIX, i.bufMatrix, 0);
				matrix_stack.add(i.bufMatrix);
			}

			// ת����ģ������ϵ
			gl.glLoadIdentity();
			gl.glTranslatef(i.pivotPoint[0], i.pivotPoint[1], i.pivotPoint[2]);
			float[] e = _mat_buf1;
			gl.glGetFloatv(GL2.GL_MODELVIEW_MATRIX, e, 0);
			matrix_stack.add(e);
			// �ϲ�
//			gl.glLoadIdentity();
			gl.glPopMatrix();
			gl.glPushMatrix();
			int matrix_i=matrix_stack.size()-1;
			while (matrix_i>=0) {
				float[] m = matrix_stack.get(matrix_i);
				gl.glMultMatrixf(m, 0);
				matrix_i--;
			}
//			gl.glGetFloatv(GL2.GL_MODELVIEW_MATRIX,
//					self.combinedMatrix, 0);
//			gl.glPopMatrix();
//			gl.glPushMatrix();
//			gl.glMultMatrixf(self.combinedMatrix, 0);
			gl.glGetFloatv(GL2.GL_MODELVIEW_MATRIX,
					self.combinedMatrix, 0);
			gl.glLoadIdentity();
		}
		gl.glPopMatrix();
		gl.glPopMatrix();
	}
	final float[] buf0 = { 0f, 0f, 0f, 1f };
	final float[] buf1 = { 0f, 0f, 0f, 1f };
	public void drawAnimation(GL2 gl, GLU glu) {
		
		for (Geoset g : geosets) {
			if (g.Faces == null)
				continue;
			if (g.VertexGroup == null)
				continue;
			Arrays.fill(g.vertices, 0f);
			int ibuffer = 0;
			float[] vBuffer = g.vertices;
			
			float[] vec4=buf0;
			float[] result=buf1;
			for (int i = 0; i < g.nVertices; i++) {
				float[] vertex = g.Vertices.get(i);

				Bone[] bones = null;
				
				bones = g.groupsBoneList.get(g.VertexGroup.get(i)[0]);
				// float w =1f;//һ������
				float w = 1f / (float) bones.length;
				
				for (Bone b : bones) {
//					gl.glLoadIdentity();
//					gl.glMultMatrixf(transform, 0);
//					gl.glMultMatrixf(b.combinedMatrix, 0);
//					gl.glGetFloatv(GL2.GL_MODELVIEW_MATRIX, _mat_buf2, 0);
					
					vec4[0] = vertex[0];
					vec4[1] = vertex[1];
					vec4[2] = vertex[2];
					Matrix16.mult(b.combinedMatrix, vec4, result);
					vBuffer[ibuffer] += result[0] * w;
					vBuffer[ibuffer + 1] += result[1] * w;
					vBuffer[ibuffer + 2] += result[2] * w;
					// �޶�һ������
					// break;
				}
				ibuffer += 3;
			}

			gl.glLoadIdentity();
			ibuffer = 0;

			gl.glEnable(GL2.GL_TEXTURE_2D);
			gl.glEnableClientState(GL2.GL_TEXTURE_COORD_ARRAY);
			gl.glTexCoordPointer(2, GL2.GL_FLOAT, 0, g.texCoordBuf);

			Texture tex = this.textures.texArray.get(g.MaterialID);
			tex.enable();
			tex.bind();

			gl.glEnableClientState(GL2.GL_VERTEX_ARRAY);
			g.swapBuffers();
			gl.glVertexPointer(3, GL2.GL_FLOAT, 0, g.vertexBuf);
			gl.glDrawElements(GL2.GL_TRIANGLES, g.nFaces * 3,
					GL2.GL_UNSIGNED_INT, g.indexBuf);
			
		}
		
	}
	public void draw(){
		throw new RuntimeException("not implement");
	}
	public void createHierarchy() {
		if (!loaded)
			return;
		for (int i = 0; i < bones.size(); i++) {

			for (int j = 0; j < bones.size(); j++) {
				if (bones.get(j).Parent == null)
					continue;
				if (bones.get(j).Parent.intValue() == bones.get(i).ObjectId
						.intValue()) {
					bones.get(j).parentBone = bones.get(i);
					if (bones.get(i).children == null) {
						bones.get(i).children = new ArrayList<Bone>();
					}
					bones.get(i).children.add(bones.get(j));
				}
			}
		}
		for (Bone i : bones) {
			if (i.parentBone == null) {
				if (rootList == null) {
					rootList = new ArrayList<Bone>();
				}
				rootList.add(i);
			}
		}
		for (int i = 0; i < pivotPoints.size(); i++) {
			Bone b = findBoneById(i);
			if (b != null) {
				b.pivotPoint = pivotPoints.get(i);
			}
		}

		for (Geoset i : geosets) {
			if (i.Groups == null) {
				continue;
			}
			i.groupsBoneList = new ArrayList<Bone[]>(i.Groups.size());

			for (int[] g : i.Groups) {
				Bone[] ab = new Bone[g.length];
				int abi = 0;
				for (int j : g) {
					ab[abi] = findBoneById(j);
					abi++;
				}
				i.groupsBoneList.add(ab);
			}
		}
	}

	public Bone findBoneById(int id) {
		for (Bone b : bones) {
			if (b.ObjectId != null && b.ObjectId.intValue() == id) {
				return b;
			}
		}
		return null;
	}

	public War3MdlModel(String fnm) {
		try {
			BufferedReader br = new BufferedReader(new FileReader(fnm));
			readModel(br);
			br.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void readModel(BufferedReader br) throws IOException {
		String line;
		while ((line = br.readLine()) != null) {
			if (line.length() > 0) {
				line = line.trim();
			}
			if (line.startsWith("//")) { // comment
				// ע��
			} else if (line.startsWith("Version")) {
				while ((line = br.readLine()) != null) {
					line = line.trim();
					if (line.equals("}")) {
						break;
					}
				}
			} else if (line.startsWith("Model")) {
				stack.begin();
				while ((line = br.readLine()) != null) {
					line = line.trim();
					if (stack.end(line))
						break;
					StringTokenizer stringTokenizer = new StringTokenizer(line,
							"\t\n\r\f ,");
					String string = stringTokenizer.nextToken().trim();
					if (!string.equals("")) {
						if (string.equals("NumGeosets"))
							geosets = new ArrayList<Geoset>(Integer.parseInt(br
									.readLine().trim().split(" |,")[1]));
						else if (string.equals("NumBones"))
							bones = new ArrayList<Bone>(Integer.parseInt(br
									.readLine().trim().split(" |,")[1]));
					}

				}
			} else if (line.startsWith("Sequences")) {
				this.sequences=new Sequences();
				this.sequences.create(br);
			} else if (line.startsWith("GlobalSequences")) {
				stack.begin();
				while ((line = br.readLine()) != null) {
					line = line.trim();
					if (stack.end(line))
						break;

				}
			} else if (line.startsWith("Textures")) {
				textures = new Textures();
				textures.create(br);

			} else if (line.startsWith("Materials")) {
				materials = new Materials();
				materials.create(br);
			} else if (line.startsWith("Geoset")) {
				if (geosets == null) {
					geosets = new ArrayList<Geoset>();
				}
				Geoset e = new Geoset();
				geosets.add(e);
				e.create(br);
			}

			else if (line.startsWith("GeosetAnim")) {
				stack.begin();
				while ((line = br.readLine()) != null) {
					line = line.trim();
					if (stack.end(line))
						break;

				}
			}
			// ObjectId 0, ����ID��������Helper�������ȶ���Object��
			// GeosetId Multiple,������ID�����ĸ��������еĶ�����Ӱ�죿������
			// GeosetAnimId None,�����嶯��ID
			// Parent 0,
			else if (line.startsWith("Bone")) {
				if (bones == null) {
					bones = new ArrayList<Bone>();
				}
				Bone e = new Bone();
				bones.add(e);
				e.create(br);
			}
			// ObjectId 0, ����ID��������Helper�������ȶ���Object��
			// GeosetId Multiple,������ID�����ĸ��������еĶ�����Ӱ�죿������
			// GeosetAnimId None,�����嶯��ID
			// Parent 0,
			else if (line.startsWith("Helper")) {
				stack.begin();
				while ((line = br.readLine()) != null) {
					line = line.trim();
					if (stack.end(line))
						break;

				}
			} else if (line.startsWith("Attachment")) {
				stack.begin();
				while ((line = br.readLine()) != null) {
					line = line.trim();
					if (stack.end(line))
						break;

				}
			}
			// ���ĵ㣨ÿ����������ĵ㣬���ǳ�ʼ���ĵ㣩
			else if (line.startsWith("PivotPoints")) {
				int r = Integer.parseInt(line.split(" ")[1]);
				this.pivotPoints = new ArrayList<float[]>(r);
				int i = 0;
				while (i < r) {
					line = br.readLine().trim();
					StringTokenizer t = new StringTokenizer(line, " {},");
					float[] e = new float[3];
					e[0] = Float.parseFloat(t.nextToken());
					e[1] = Float.parseFloat(t.nextToken());
					e[2] = Float.parseFloat(t.nextToken());
					i++;
					this.pivotPoints.add(e);
				}
			} else if (line.startsWith("Camera")) {
				stack.begin();
				while ((line = br.readLine()) != null) {
					line = line.trim();
					if (stack.end(line))
						break;

				}
			}
			// ���ӷ�����
			else if (line.startsWith("ParticleEmitter")) {
				stack.begin();
				while ((line = br.readLine()) != null) {
					line = line.trim();
					if (stack.end(line))
						break;

				}
			} else if (line.startsWith("ParticleEmitter2")) {
				stack.begin();
				while ((line = br.readLine()) != null) {
					line = line.trim();
					if (stack.end(line))
						break;

				}
			}

		}
		loaded = true;
		createHierarchy();

	}

}
