package loader.war3mdl;

public class Matrix16 {
	/**
	 * ��λ����
	 */
	final static float[] identity=new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
	/**
	 * ����Ϊ��λ����
	 * @param mat
	 */
	public static void loadIdentityMatrix(float[] mat) {
		for (int i = 0; i < 16; i++) {
			mat[i]=identity[i];
		}
	}
	/**
	 * ����mt���ĳ�������ķ���
	 */
	  public static void mult(float[] mt, float[] vec4,float[] result) { 
		  
		  result[0]=mt[0] * vec4[0] + mt[4] * vec4[1] + mt[8] * vec4[2] + mt[12] * vec4[3];
		  result[1]= mt[1] * vec4[0] + mt[5] * vec4[1] + mt[9] * vec4[2] + mt[13] * vec4[3];
		  result[2]= mt[2] * vec4[0] + mt[6] * vec4[1] + mt[10]* vec4[2] + mt[14] * vec4[3];
//		  result[3]=mt[3] * vec4[0] + mt[7] * vec4[1] + mt[11]* vec4[2] + mt[15] * vec4[3];
		  
	  }
}
