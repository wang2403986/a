package view;

import gserver.SocketClient2;
import gserver.SocketListener;

import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.List;

import static view.Util.*;
/**
 * 
 * @author Admin
 *
 */
public class SocketHandler implements SocketListener{
	
	Renderer renderer;
	static SocketHandler socketHandler;
	static SocketClient2 socketClient2;
	static{
		socketClient2=new SocketClient2();
	}
	public static SocketHandler getDefault(){
		return socketHandler;
	}
	public SocketHandler(Renderer renderer){
		this.renderer = renderer;
		socketClient2.listener=(this);
		socketHandler = this;
	}
	
	public void onmessage(byte[] response, Socket socket) {
		if (response == null || response.length < 10)
			return;
		synchronized (renderer) {
			List<GameRole> roles = renderer.roles;
			ByteBuffer buffer = ByteBuffer.wrap(response);

			int fromClient = buffer.getInt();// fromClient
			int clientID = buffer.getInt();// this Client ID
			renderer.role.id = clientID;
			if (renderer.role.id == fromClient) {
				return;
			}
			GameRole r = findById(fromClient, roles);
			if (r == null) {
				r = new GameRole(renderer.model);
				r.id = fromClient;
				roles.add(r);
			}
			float[] localTrans = { 0, 0, 0, 0 };
			float[] localRot = { 0, 0, 0, 0 };
			float[] moveTo = { 0, 0, 0, 0 };
			float[] startPosition = { 0, 0, 0, 0 };

			for (int i = 0; i < r.localTrans.length; i++)
				localTrans[i] = buffer.getFloat();

			for (int i = 0; i < r.localRot.length; i++)
				localRot[i] = buffer.getFloat();

			for (int i = 0; i < r.moveTo.length; i++)
				moveTo[i] = buffer.getFloat();
			for (int i = 0; i < r.moveStart.length; i++)
				startPosition[i] = buffer.getFloat();
			int status = buffer.getInt();

			if (status == 1 && status == r.status
					&& vecEquals(startPosition, r.moveStart)
					&& vecEquals(moveTo, r.moveTo)) {
				// �ƶ�����δ���
			} else if (status == 1) {
				veccopy(r.moveTo, moveTo);
				veccopy(r.localRot, localRot);
				veccopy(r.moveStart, startPosition);
				veccopy(r.localTrans, localTrans);
				long elapsedTime = System.currentTimeMillis()
						- renderer.baseTime;
				r.time = elapsedTime;
				r.move(moveTo);
			} else {
				veccopy(r.localTrans, localTrans);
				veccopy(r.localRot, localRot);
			}
			r.status = status;
		}
	}
	/**
	 * �����ƶ�����
	 * @param socket
	 */
	public void sendMoveCmd(){
		byte[] bs=new byte[16*4 + 4 ];
		ByteBuffer
		 buf = ByteBuffer.wrap(bs);
		synchronized (renderer) {
			GameRole m=renderer.role;
			for(int i=0;i<m.localTrans.length;i++)
				buf.putFloat(m.localTrans[i]);
			
			for(int i=0;i<m.localRot.length;i++)
				buf.putFloat(m.localRot[i]);
			
			for(int i=0;i<m.moveTo.length;i++)
				buf.putFloat(m.moveTo[i]);
			for(int i=0;i<m.startPosition.length;i++)
				buf.putFloat(m.startPosition[i]);
			
			buf.putInt(m.status);
		}
		
		socketClient2.send(bs);
	}
	static GameRole findById(int id, List<GameRole> roles){
		for (GameRole e : roles) {
			if(e.id == id)
				return e;
		}
		return null;
	}
	@Override
	public void onerror(Socket socket) {
		// TODO Auto-generated method stub
		
	}
}
