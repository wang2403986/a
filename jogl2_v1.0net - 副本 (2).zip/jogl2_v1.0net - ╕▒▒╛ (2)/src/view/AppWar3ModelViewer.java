package view;
import java.awt.*;
import javax.swing.*;

import javax.media.opengl.*;
import com.sun.opengl.util.FPSAnimator;
import javax.media.opengl.awt.GLCanvas;
/**
 * ħ��3ģ�Ͳ鿴��ʾ������
 * @version CopyRright @ 2013 �Ϸ���ͬ��Ϣ����
 * @author <a href="http://www.zhitong.com">����<a/>
 *
 */
public class AppWar3ModelViewer extends JFrame {
	private static final long serialVersionUID = -8393664004974718690L;
	Renderer listener=new Renderer();
	static FPSAnimator animator=null;
	public AppWar3ModelViewer() throws HeadlessException {
		super("ħ��3ģ�Ͳ鿴");
		setSize(600,480);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GLCapabilities c=new GLCapabilities(GLProfile.getDefault());
//		capabilities.setRedBits(8);
		GLCanvas canvas=new GLCanvas(c);
		canvas.addGLEventListener(listener);
		canvas.addKeyListener(listener.role);
		canvas.addMouseListener(listener.role);
		canvas.addMouseMotionListener(listener.role);
		canvas.addMouseWheelListener(listener.role);
		getContentPane().add(canvas, BorderLayout.CENTER);
		animator=new FPSAnimator(canvas, 60, true);
                
		centerWindow(this);		
	}	
	private void centerWindow(Component frame) { // ���д���
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension frameSize = frame.getSize();
		if (frameSize.width > screenSize.width)
			frameSize.width = screenSize.width;
		if (frameSize.height > screenSize.height)
			frameSize.height = screenSize.height;
		frame.setLocation((screenSize.width - frameSize.width) >> 1,
				(screenSize.height - frameSize.height) >> 1);

	}
	
	public static void main(String[] args) {
		final AppWar3ModelViewer app = new AppWar3ModelViewer();
		// ��ʾ����
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				app.setVisible(true);
			}
		});
		// �����߳̿�ʼ
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				animator.start();
			}
		});
	}
}
