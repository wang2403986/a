package loader.xfile;

public class Material {
	public String name;
	public float[] faceColor;
	public float power;
	public float[] specularColor;
	public float[] emissiveColor;
	public String textureFilename;
	
}
