package loader.war3mdl;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

public class Sequences {
	
	public List<AnimationInfo> Anims;
	public int[] timeInterval=new int[2];
	
	public void create(BufferedReader br) throws IOException {
		TokenStack s=new TokenStack();
		s.begin();
		StringTokenizer tokenizer;
		String line=null;
		while((line=br.readLine())!=null){
			line=line.trim();
			if(s.end(line))break;
			String v;
			
			if (line.startsWith("Anim")) {
				
				v=line.split("\"")[1];
				if (Anims==null) {
					Anims=new ArrayList<AnimationInfo>();
				}
				AnimationInfo info=new AnimationInfo();
				info.name=v;
				v=br.readLine();
				if (v!=null) {
					v.trim();
					tokenizer=new StringTokenizer(v,"{}, ");
					info.Interval=new int[2];
					tokenizer.nextToken().trim();
					info.Interval[0]=Integer.parseInt(tokenizer.nextToken().trim());
					info.Interval[1]=Integer.parseInt(tokenizer.nextToken().trim());
				}
				Anims.add(info);
			}
		}
		if (Anims.size()>0) {
			timeInterval[0]=Anims.get(0).Interval[0];
			for (int i = 0; i < Anims.size(); i++) {
				int[] it=Anims.get(i).Interval;
				if (it[0]<timeInterval[0]) {
					timeInterval[0]=it[0];
				}
				if (it[1]>timeInterval[1]) {
					timeInterval[1]=it[1];
				}
			}
		}
	}
	public void getInterval(String name,int[] interval) {
		for (AnimationInfo anim : Anims) {
			if (anim.name!=null&&anim.name.equals(name)) {
				interval[0]=anim.Interval[0];
				interval[1]=anim.Interval[1];
				break;
			}
		}
		
	}
	/**
	 * ���ò��Ŷ�������
	 * @param index ��������
	 */
	public void setAnimIndex(int index) {
		if (index>=Anims.size()) {
			return;
		}
		timeInterval[0]=Anims.get(index).Interval[0];
		timeInterval[1]=Anims.get(index).Interval[1];
	}
	/**
	 * ���ò��Ŷ�������
	 * @param name ��������
	 */
	public void setAnimIndex(String name) {
		if (name==null||name.equals("")) {
			if (Anims.size()>0) {
				timeInterval[0]=Anims.get(0).Interval[0];
				for (int i = 0; i < Anims.size(); i++) {
					int[] it=Anims.get(i).Interval;
					if (it[0]<timeInterval[0]) {
						timeInterval[0]=it[0];
					}
					if (it[1]>timeInterval[1]) {
						timeInterval[1]=it[1];
					}
				}
			}
		}
		else {
			getInterval(name, timeInterval);
		}
	}
}
