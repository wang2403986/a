package loader.war3mdl;

public class Quaternion {
	/**
	 * 
	 * @param quat Q = |X Y Z W|
	 * @param axis
	 * @param angle
	 * @return
	 */
	public static float  Quaternion3DExtractAxisAndAngle(float[] quat, float[] axis, float angle)
	 {
//	 Quaternion3DNormalize(quat);
		float s;
		 s = (float)Math.sqrt(1.0f -(quat[3] * quat[3]));

		if (Math.abs(s) < 0.0005f) s = 1.0f;

		if(axis != null)
		 {
		 axis[0] = (quat[0] / s);
		 axis[1] = (quat[1] / s);
		 axis[2] = (quat[2] / s);
		 }

		
		 angle = (float)Math.acos(quat[3]) * 2.0f;

		
		
		
//	 float scale =(float) Math.sqrt(quat[0] * quat[0] + quat[1] * quat[1] + quat[2] * quat[2]);
//	 axis[0] = quat[0] / scale;
//	 axis[1] = quat[1] / scale;
//	 axis[2] = quat[2] / scale;
//	 angle = (float)Math.acos(quat[3]) * 2.0f;

	 return angle;
	 }
	/**
	 * http://www.j3d.org/matrix_faq/matrfaq_latest.html#Q55
	 * @param quat
	 * @param mat
	 */
	 public static void Quaternion2Matrix(float[] quat,float[] mat) {
		float xx      = quat[0] *  quat[0];
		 float   xy      =  quat[0] *  quat[1];
		 float   xz      =  quat[0] *  quat[2];
		 float    xw      = quat[0] * quat[3];
		 float    yy      = quat[1] * quat[1];
		 float   yz      = quat[1] * quat[2];
		 float    yw      = quat[1] * quat[3];
		 float   zz      = quat[2] * quat[2];
		 float    zw      = quat[2] * quat[3];
		    mat[0]  = 1 - 2 * ( yy + zz );
		    mat[1]  =     2 * ( xy - zw );
		    mat[2]  =     2 * ( xz + yw );
		    mat[4]  =     2 * ( xy + zw );
		    mat[5]  = 1 - 2 * ( xx + zz );
		    mat[6]  =     2 * ( yz - xw );
		    mat[8]  =     2 * ( xz - yw );
		    mat[9]  =     2 * ( yz + xw );
		    mat[10] = 1 - 2 * ( xx + yy );
		    mat[3]  = mat[7] = mat[11] = mat[12] = mat[13] = mat[14] = 0;
		    mat[15] = 1;
	}
	public static  float[] Quaternion3DMakeWithNLERP(float[] start, float[] finish, float progress)
	 {
	 float[] ret=new float[4];
	 float inverseProgress = 1.0f-progress;
	 ret[0]= (start[0] * inverseProgress) + (finish[0] * progress);
	 ret[1] = (start[1] * inverseProgress) + (finish[1] * progress);
	 ret[2] = (start[2] * inverseProgress) + (finish[2] * progress);
	 ret[3] = (start[3] * inverseProgress) + (finish[3] * progress);
	 Quaternion3DNormalize(ret);
	 return ret;
	 }
	
	public static  void Quaternion3DNormalize(float[] quaternion)
	 {
		double magnitude;
		double x = quaternion[0];
		double y = quaternion[1];
		double z = quaternion[2];
		double w = quaternion[3];
		magnitude = (float) Math.sqrt(x * x + y * y + z * z + w * w);
		float r_magnitude = (float) (1d / magnitude);
		quaternion[0] *= r_magnitude;
		quaternion[1] *= r_magnitude;
		quaternion[2] *= r_magnitude;
		quaternion[3] *= r_magnitude;
	 }
	
	public static void main(String[] s) {
		float[] quat=new float[]{0, 0.258819f, 0, 0.9659258f};
		//quat=new float[]{quat[]};
		float[] axis=new float[3];
		float angle=0;
		
		Quaternion3DNormalize(quat);
		angle=Quaternion3DExtractAxisAndAngle(quat, axis, angle);
		System.out.println();
	}

}
