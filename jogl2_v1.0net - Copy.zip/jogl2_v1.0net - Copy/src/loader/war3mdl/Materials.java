package loader.war3mdl;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class Materials {

	public void create(BufferedReader br) throws IOException {
		TokenStack s=new TokenStack();
		s.begin();
		StringTokenizer tokenizer;
		String line=null;
		while((line=br.readLine())!=null){
			line=line.trim();
			if(s.end(line))break;
			String v;
			
			if (line.startsWith("Material")) {
				
			}
			else if (line.startsWith("static TextureID")) {
				
			}
		}
	}

}
