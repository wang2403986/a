package loader.war3mdl;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
/**
 * Bone Or Helper are similar
 * @author wangTao
 * {@link www.zhitong.com}
 */
public class Bone {
	/**
	 * ��ǰ֡����
	 */
	public int frameIndex;
	/**
	 * ������ʼλ��
	 */
	public float[] pivotPoint;
	/**
	 * Ψһ���
	 */
	public Integer ObjectId;
	/**
	 * ���������
	 */
	public Integer Parent;
	/**
	 * ��������
	 */
	public int GeosetId;
	/**
	 * �����嶯��id
	 */
	public int GeosetAnimId;
	/**
	 * ָ�򸸹���
	 */
	public Bone parentBone;
	/**
	 * ���к��ӹ����ڵ�
	 */
	public List<Bone> children;
	/**
	 * ָ�򼸺���
	 */
	public Geoset geoset;
	/**
	 * λ�Ƽ�����
	 */
	public List<float[]> Translation;
	/**
	 * ��ת������
	 */
	public List<float[]> Rotation ;
	/**
	 * ���ű任
	 */
	public List<float[]> Scaling ;
	/**
	 * ���ӱ任
	 */
	public List<float[]> Visibility;
	/**
	 * ��ǰλ�Ʊ任
	 */
	public float[] currentTranslation=new float[3];
	/**
	 * ��ǰ��ת
	 */
	public float[] currentRotation=new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
	/**
	 * ��ǰλ����
	 */
	public float[] currentScaling;
	/**
	 * ��ǰ���ϱ任
	 */
	public float[] combinedMatrix=new float[]{1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f};
	
	/**
	 * ���ڼ���
	 */
	public float[] bufMatrix=new float[16];
	public float[] normalMatrix = new float[16];
	
	public void create(BufferedReader br) throws IOException {
		TokenStack s=new TokenStack();
		s.begin();
		StringTokenizer tokenizer;
		String line=null;
		while((line=br.readLine())!=null){
			line=line.trim();
			if(s.end(line))break;
			String v;
			
			if (line.startsWith("ObjectId")) {
				ObjectId=Integer.parseInt( line.split(" |,")[1]);
			}
			else if (line.startsWith("Parent")) {
				Parent=Integer.parseInt( line.split(" |,")[1]);
			}
			
			else if (line.startsWith("Rotation")) {
				int r= Integer.parseInt( line.trim().split(" ")[1]);
				Rotation=new ArrayList<float[]>(r);
				br.readLine();
				int i=0;
				while (i<r) {
					line=br.readLine().trim();
					tokenizer=new StringTokenizer(line, ": ,{}");
					int c= tokenizer.countTokens();
					float[] e=new float[c];
					int i2=0;
					while (i2<c) {
						e[i2]=Float.parseFloat( tokenizer.nextToken().trim());
						i2++;
					}
					Rotation.add(e);
					i++;
				}
			}
			else if (line.startsWith("Translation")) {
				int r= Integer.parseInt( line.trim().split(" ")[1]);
				Translation=new ArrayList<float[]>(r);
				br.readLine();
				int i=0;
				while (i<r) {
					line=br.readLine().trim();
					tokenizer=new StringTokenizer(line, ": ,{}");
					int c= tokenizer.countTokens();
					float[] e=new float[c];
					int i2=0;
					while (i2<c) {
						e[i2]=Float.parseFloat( tokenizer.nextToken().trim());
						i2++;
					}
					Translation.add(e);
					i++;
				}
			}
			else if (line.startsWith("Scaling")) {
				br.readLine();
				br.readLine();
				br.readLine();
			}
		}
	}
}
