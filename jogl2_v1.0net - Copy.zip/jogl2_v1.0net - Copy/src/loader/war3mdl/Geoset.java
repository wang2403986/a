package loader.war3mdl;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.sun.opengl.util.BufferUtil;

public class Geoset {
	public int nVertices;
	public int nFaces;
	public List<float[]> Vertices;
	public List<float[]> Normals;
	public List<float[]> TVertices;
	public List<int[]> VertexGroup;
	public List<Bone[]> groupsBoneList;
	public List<int[]> Groups;
	public List<int[]> Faces;
	public int[] indices;
	public float[] vertices;
	public float[] texCoords;
	FloatBuffer vertexBuf;
	FloatBuffer texCoordBuf;
	IntBuffer indexBuf;
	
	public List<int[]> Triangles;
	public Integer MaterialID;
	
	public void fillIndexsBuffer() {
		int ibuf = 0;
		for (int[] is: Faces) {
			for (int i = 0; i < is.length; i++) {
				indices[ibuf]=is[i];
				ibuf++;
			}
			
		}
//		Faces.clear();
//		Faces=null;
		indexBuf = BufferUtil.newIntBuffer(indices);
	}
	public void swapBuffers() {
		vertexBuf.position(0);
		vertexBuf.put(vertices);
		vertexBuf.position(0);
	}
	public void resetBuffer() {
		int ibuf=0;
		for (float[] fs :Vertices) {
			for (int i = 0; i < fs.length; i++) {
				vertices[ibuf]=fs[i];
				ibuf++;
			}
		}
		
//		ibuf=0;
//		for (int[] is: Faces) {
//			for (int i = 0; i < is.length; i++) {
//				indices[ibuf]=is[i];
//				ibuf++;
//			}
//			
//		}
	}
	public void create(BufferedReader br) throws IOException {
		TokenStack s=new TokenStack();
		s.begin();
		StringTokenizer tokenizer;
		String line=null;
		while((line=br.readLine())!=null){
			line=line.trim();
			if(s.end(line))break;
			String v;
			
			if (line.startsWith("Vertices")) {
				tokenizer=new StringTokenizer(line, War3MdlModel.delim);
				if (tokenizer.hasMoreTokens()) {
					v=tokenizer.nextToken();
					v=tokenizer.nextToken();
					nVertices=Integer.parseInt(v.trim());
					Vertices=new ArrayList<float[]>(nVertices);
					vertices=new float[nVertices*3];
					vertexBuf = BufferUtil.newFloatBuffer(vertices);
				}
				int i=0;
				while (i<nVertices) {
					line= br.readLine();
					if (line!=null) {
						line=line.trim();
						tokenizer=new StringTokenizer(line, "\t\n\r\f ,{}");
						float[] fs=new float[3];
						fs[0]=Float.parseFloat( tokenizer.nextToken());
						fs[1]=Float.parseFloat( tokenizer.nextToken());
						fs[2]=Float.parseFloat( tokenizer.nextToken());
						Vertices.add(fs);
					}
					i++;
				}
				
			}
			else if (line.startsWith("TVertices")) {
				 v=line.split(" ")[1];
				 TVertices=new ArrayList<float[]>(nVertices);
				 int i=0;
					while (i<nVertices) {
						line= br.readLine();
						if (line!=null) {
							line=line.trim();
							tokenizer=new StringTokenizer(line, "\t\n\r\f ,{}");
							float[] fs=new float[3];
							fs[0]=Float.parseFloat( tokenizer.nextToken());
							fs[1]=Float.parseFloat( tokenizer.nextToken());
							TVertices.add(fs);
						}
						i++;
					}
					
					texCoords=new float[2*nVertices];
					i=0;
					for (float[] fs: TVertices) {
						texCoords[i]=fs[0];
						texCoords[i+1]=fs[1];
						i+=2;
					}
					TVertices.clear();
					TVertices=null;
					texCoordBuf = BufferUtil.newFloatBuffer(texCoords);
			}
			else if (line.startsWith("VertexGroup")) {
				VertexGroup=new ArrayList<int[]>(nVertices);
				int i=0;
				while (i<nVertices) {
					line= br.readLine();
					if (line!=null) {
						line=line.trim();
						tokenizer=new StringTokenizer(line, "\t\n\r\f ,{}");
						int j;
						j=Integer.parseInt( tokenizer.nextToken());
						VertexGroup.add(new int[]{j});
					}
					i++;
				}
			}
			else if (line.startsWith("Faces")) {
				nFaces = Integer.parseInt(line.split(" ")[2]) / 3;
				int nl = Integer.parseInt(line.split(" ")[1]);
				// nFaces=nFaces-nl;
				Faces = new ArrayList<int[]>(nFaces);
				indices=new int[nFaces*3];
				line = br.readLine();
				if ((line = br.readLine()) != null) {
					line = line.trim();
					tokenizer = new StringTokenizer(line, " ,{}");
					int i = 0;
					while (i < nFaces) {
						int[] js = new int[3];
						js[0] = Integer.parseInt(tokenizer.nextToken());
						js[1] = Integer.parseInt(tokenizer.nextToken());
						js[2] = Integer.parseInt(tokenizer.nextToken());
						// System.out.println(js[0]+","+js[1]+","+js[2]+",");
						// System.out.println(i);
						Faces.add(js);
						i += 1;
					}
					fillIndexsBuffer();
				}
				br.readLine();
			}
			else if (line.startsWith("Groups")) {
				String[] strings= line.split(" ");
				
				int row=Integer.parseInt( strings[1]);
				int num= Integer.parseInt(strings[2]);
				Groups=new ArrayList<int[]>(row);
				int i=0;
				while (i<row) {
					line=br.readLine();
					if (line!=null) {
						line=line.trim();
						line=line.substring(line.indexOf('{')+1, line.lastIndexOf('}')).trim();
						tokenizer=new StringTokenizer(line, ", ");
						int c= tokenizer.countTokens();
						int[] js=new int[c];
						int j=0;
						while (j<c) {
							js[j]=Integer.parseInt( tokenizer.nextToken());
							j++;
						}
						Groups.add(js);
					}
					i++;
				}
				
			}
			else if (line.startsWith("Normals")) {
				 v=line.split(" ")[1];
				 Normals=new ArrayList<float[]>(nVertices);
				 int i=0;
					while (i<nVertices) {
						if ((line= br.readLine())!=null) {
							line=line.trim();
							tokenizer=new StringTokenizer(line, "\t\n\r\f ,{}");
							float[] fs=new float[3];
							fs[0]=Float.parseFloat( tokenizer.nextToken());
							fs[1]=Float.parseFloat( tokenizer.nextToken());
							fs[2]=Float.parseFloat( tokenizer.nextToken());
							Normals.add(fs);
						}
						i++;
					}
			}
			else if (line.startsWith("MaterialID")) {
				MaterialID=Integer.parseInt(line.split(" |,")[1]);
			}
			
			
		}
	}
}
