package loader.war3mdl;

import java.util.Stack;

public class TokenStack {
	static final String symbol="{";
	Stack<Object> stack=new Stack<Object>();
	public  void resetStack() {
		stack.clear();
	}

	public void begin() {
		resetStack();
		stack.push(symbol);
	}
	public boolean end(String line) {
		boolean closed= checkPop(line);
		if(closed)
			return true;
		pushStack(line);
		return false;
		
	}
	private  boolean checkPop(String line) {
		if (line.charAt(0) == '}') {
			stack.pop();
			if (stack.empty()) {
				return true;
			}
		}
		return false;

	}

	private void pushStack(String line) {
		if (line.endsWith("{")) {
			stack.push(symbol);
		}
	}
}
