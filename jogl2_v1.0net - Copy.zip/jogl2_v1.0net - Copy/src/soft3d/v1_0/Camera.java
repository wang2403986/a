package soft3d.v1_0;

import soft3d.v1_0.compiler.types.*;
import static soft3d.v1_0.GLM.*;

import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;

import javax.swing.JFrame;

public class Camera {
float FAR_DIST =200.0f, LIGHT_FOV =45.0f, CAMERA_FOV = 45.0f;

  vec3 position =vec3(0.0f,0.0f,0.0f),
   target=vec3(0, 0, 1),
   up=vec3(0, 1, 0);
  Camera self = this;Rectangle viewport ;
  CameraTracker tracker = new CameraTracker(self);

  Camera _this=this;
public Camera ( JFrame frame) {
//  self.position=(t_position);
//  self.target=(t_target);
//  self.up=(t_up) ;
  position= vec3(75.5f, 30.0f, -110.0f);//Math.PI / 3, 1, 0.01, 900
  target=vec3(-0.7f, 0.0f, 0.7f);
  
  MouseAdapter m  = new MouseAdapter() {
		 @Override
		public void mousePressed(MouseEvent e) {
			 _this.mouse(e.getButton(), e.getClickCount(), e.getX(), e.getY());
		} 
		 @Override
		public void mouseReleased(MouseEvent e) {
//			 _this.mouse(0, 0, 0, 0);
		}
		@Override
		public void mouseDragged(MouseEvent e) {
			_this.motion(e.getX(), e.getY());
		}
		 @Override
		public void mouseWheelMoved(MouseWheelEvent e) {
//			 _this.m
		}
	};
	  
	  KeyAdapter k  = new KeyAdapter() {
		  @Override
		public void keyPressed(KeyEvent e) {
			  _this.key_down(e.getKeyChar(), 0, 0);
		}
		  @Override
		public void keyReleased(KeyEvent e) {
			  _this.key_up(e.getKeyChar(), 0, 0);
		}
		};
		frame.addMouseListener(m);
		  frame.addMouseMotionListener(m);
		  frame.addMouseWheelListener(m);
		  frame.addKeyListener(k);
}
public void update (float dt) {
  self.tracker.update(dt);
}
/** */
public void rotate(float angle,vec3  axis) {
	vec3 ret =new vec3();
	mat4 tmp =Matrix4.rotateAxis(new mat4() , axis, angle);
  vec3 n_target=mul(tmp,self.target) ;
  n_target=normalize(n_target);
//  var n_target = rotate(self.target, angle, axis);
  self.target = n_target;

}
mat4 t_view_matrix=new mat4();
/** */
public mat4 view_matrix () {
	vec3 n_target = add(self.position , self.target);
	Matrix4.lookAt(t_view_matrix,  self.position, n_target, self.up);
  return t_view_matrix;
}

boolean  m_uniform_offsets = false,m_uniform_poisson = false;

vec3 cam_pos = vec3(75.5f, 30.0f, -110f);
vec3 cam_view = vec3(-0.7f, 0.0f, 0.7f);

//GLfloat light_dir[4] = {0.2f, 0.99f, 0.0f , 0.0f};
vec4 m_light_dir = vec4(0.2f, 0.99f, 0.0f, 0.0f);


float sensitivity = 0.005f;
float walk_speed = 0.5f;

float old_x, old_y;
float half_width, half_height;

void get_camera() {
  return ;//m_camera;
}

void rotate_view(vec3 view,  float angle,float   x,float   y,float   z) {
	float new_x;
	float new_y;
	float new_z;

	float c = (float) Math.cos(angle);
	float s = (float) Math.sin(angle);

  new_x  = (x*x*(1-c) + c)  * view.x;
  new_x += (x*y*(1-c) - z*s)  * view.y;
  new_x += (x*z*(1-c) + y*s)  * view.z;
  
  new_y  = (y*x*(1-c) + z*s)  * view.x;
  new_y += (y*y*(1-c) + c)  * view.y;
  new_y += (y*z*(1-c) - x*s)  * view.z;

  new_z  = (x*z*(1-c) - y*s)  * view.x;
  new_z += (y*z*(1-c) + x*s)  * view.y;
  new_z += (z*z*(1-c) + c)  * view.z;

  view.x = new_x;
  view.y = new_y;
  view.z = new_z;

  Vector3.copy(view, normalize(view));
}

public void  motion(float x,float  y) {

	float orig_x = x;
	float orig_y = y;
	float rot_x, rot_y;
	vec3 rot_axis=vec3(3,3,3);

  x -= half_width;
  y -= half_height;

  rot_x = -(x - old_x) * sensitivity;
  rot_y = -(y - old_y) * sensitivity;

  old_x = x;
  old_y = y;

  //if(GetAsyncKeyState(VK_SHIFT))
    tracker.track(orig_x, orig_y);

    rotate_view(cam_view, rot_x, 0.0f, 1.0f, 0.0f);

    rot_axis.x = -cam_view.z;
    rot_axis.y = 0.0f;
    rot_axis.z = cam_view.x;

    rot_axis=normalize(  rot_axis);

    rotate_view(cam_view, rot_y, rot_axis.x, rot_axis.y, rot_axis.z);
}

public void mouse(int button,int  state,float  x, float y) {
  old_x = x - half_width;
  old_y = y - half_height;
  tracker.begin(x, y);
}

public void key_down(char c, float x,float y) {
  switch (c) {
    case 27: //escape key
    case 'q':
    	tracker.up=(true); break;
    case 'z':
    	tracker.down=(true); break;
//    case 'r': {
//      rotate_light_dir = true; break;
//    }
    case 'w': {
      tracker.forward=(true); break;
    }
    case 's': {
      tracker.backward=(true); break;
    }
    case 'a': {
      tracker.left=(true); break;
    }
    case 'd': {
      tracker.right=(true); break;
    }
  }
}

public void key_up(char c, float x,float  y) {
  switch (c) {
    case 'q':
  	  tracker.up=(false); break;
    case 'z':
  	  tracker.down=(false); break;
//    case 'r': {
//      rotate_light_dir = false; break;
//    }
    case 'w': {
      tracker.forward=(false); break;
    }
    case 's': {
      tracker.backward=(false); break;
    }
    case 'a': {
      tracker.left=(false); break;
    }
    case 'd': {
      tracker.right=(false); break;
    }
  }
}

public void keys(int  c, float x,float  y) {
  
  switch (c) {
    case 27: //escape key
    case 'q':
    case 'Q':
      break;
    case 'w': {
      cam_pos.x += cam_view.x * walk_speed;
      cam_pos.y += cam_view.y * walk_speed;
      cam_pos.z += cam_view.z * walk_speed;
      break;
    }
    case 's': {
      cam_pos.x -= cam_view.x * walk_speed;
      cam_pos.y -= cam_view.y * walk_speed;
      cam_pos.z -= cam_view.z * walk_speed;
      break;
    }
    case 'a': {
      cam_pos.x += cam_view.z * walk_speed;
      cam_pos.z -= cam_view.x * walk_speed;
      break;
    }
    case 'd': {
      cam_pos.x -= cam_view.z * walk_speed;
      cam_pos.z += cam_view.x * walk_speed;
      break;
    }
  }
//  glutPostRedisplay();
}
int width=1024,height=680;
public void reshape(int w, int h) {
  width = w;
  height = h;
  half_height = height/2;
  half_width = width/2;

  float ratio = width / height;   
  ratio=1;
//  m_camera.position=[75.5, 30.0, -110.0];//Math.PI / 3, 1, 0.01, 900
//  m_camera.target=[-0.7, 0.0, 0.7];
//  m_camera.viewport.set(0, 0, width, height);
//  m_camera.frustum.set(radians(45.0), ratio, 1.0, FAR_DIST);//(45.0), ratio, 1.0, FAR_DIST

  position= vec3(75.5f, 30.0f, -110.0f);//Math.PI / 3, 1, 0.01, 900
  target=vec3(-0.7f, 0.0f, 0.7f);
  
}
static class CameraTracker {
	Camera m_camera;
	CameraTracker (Camera camera){
		m_camera = camera;
	}
  vec3 m_prev_point = vec3(0.0f,0.0f,0.0f);float m_sensitivity=(0.005f);
		  CameraTracker  self = this;
		private boolean forward;
		private boolean backward;
		private boolean left;
		private boolean right;
		private boolean up;
		private boolean down;
  void begin (float x, float y) {
    if(m_camera==null) { return; }
    m_prev_point = vec3(x - m_camera.half_width, y - m_camera.half_height,0);
  }
  /** */
  void track (float x,float  y) {
    if(m_camera==null) { return; }

    vec3 n_point =vec3(x, y,0);//vec2
    vec3 n_rotation= vec3(0, 0,0);//vec2
    vec3 t_rotation_axis =vec3(0.0f, 1.0f, 0.0f);//vec3

    n_point.x -= m_camera.half_width;
    n_point.y -= m_camera.half_height;

    n_rotation.x = -(n_point.x - m_prev_point.x) * m_sensitivity;
    n_rotation.y = -(n_point.y - m_prev_point.y) * m_sensitivity;

    m_camera.rotate(n_rotation.x, t_rotation_axis);

    vec3 t_camtarget = m_camera.target;
    t_rotation_axis = normalize( vec3(-t_camtarget.z, 0.0f, t_camtarget.x));
    m_camera.rotate(n_rotation.y, t_rotation_axis);

    Vector3.copy( m_prev_point , n_point);
  }
  public void update (float dt00) {
	  float dt=dt00;
	  vec3 t_campos =  Vector3.copy( new vec3(), m_camera.position);
	  vec3 t_camtarget = m_camera.target;

    // Move 5 units per second
    float t_speed = 5.0f * dt;

    vec3 tmp0 =new vec3();
    if(self.forward) {
      t_campos = add( t_campos, mul(  t_camtarget , t_speed));
    } else if(self.backward) {
      //t_campos -= t_camtarget * t_speed;
      t_campos =sub( t_campos, mul(  t_camtarget , t_speed));
    }

    if(self.left) {
      t_campos = add( t_campos, mul(  vec3(t_camtarget.z, 0.0f, -t_camtarget.x), t_speed));
    } else if(self.right) {
      t_campos = add(  t_campos, mul(  vec3(-t_camtarget.z, 0.0f, t_camtarget.x), t_speed));
    }
    
    if(self.up) {
    	t_campos.y -= t_speed;
    } else if(self.down) {
    	t_campos.y += t_speed;
    }

    Vector3.copy(m_camera.position, t_campos);
  }
}
}
