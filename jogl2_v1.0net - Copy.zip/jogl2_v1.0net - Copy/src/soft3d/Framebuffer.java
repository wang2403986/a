package soft3d;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.util.Arrays;
import java.util.List;

import soft3d.Matrix;
import soft3d.Texture;
import soft3d.Vec3;


public class Framebuffer {
	public static int height;
	public static int width;

	/**
	 * ͸�ӽ���
	 */
	public static float focusZ = -256;// 256
	/**
	 * ͶӰƽ��
	 */
	public static float screenZ = -240;// 255

	public static Texture texture;
	public static List<Texture> textureList;
	public static final float[][] transform = { { 1, 0, 0, 0 }, { 0, 1, 0, 0 },
			{ 0, 0, 1, 0 }, { 0, 0, 0, 1 } };
	public static int[] pixels;
	public static float[] zBuffer;
	/**
	 * ���ڻ��Ƶ�ͼƬԴ
	 */
	BufferedImage image;
	Graphics graphics2D, bufferedGraphics;

	public Framebuffer(Graphics graphics2d, int w, int h) {
		width = w;
		height = h;
		zBuffer = new float[h * w];
		this.graphics2D = graphics2d;
		Matrix.loadIdentity(transform);
		image = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
		pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
		bufferedGraphics = image.createGraphics();
	}
	public void resize(int w, int h){
		if (w * h > zBuffer.length || w * h > width * height) {
			zBuffer = new float[h * w];
			image = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
			pixels = ((DataBufferInt) image.getRaster().getDataBuffer())
					.getData();
			bufferedGraphics = image.createGraphics();
		}
		width = w;
		height = h;
	}
//
//	public static final void project(Vec3 vertex, float halfW, float halfH) {
////		float halfW = width >> 1, halfH = height >> 1;
//		float difZ = screenZ - focusZ;
//		float r = 1, z = vertex.z;
//		if (z != focusZ)
//			r = difZ / (z - focusZ);
//		float ratio = 512.0f * r;
//		vertex.x = vertex.x * ratio + halfW;
//		/** ����ƽ��ֱ������ϵ��Ϊ����ֱ������ϵ */
//		vertex.y = -vertex.y * ratio + halfH;
//	}
//	public final void drawTriangleList(float[] vertices, int[] indices,
//			float[] uvs, float[] normals, float[] screenBuf, int[] faceMaterials) {
//		Point3D v1 = pointA, v2 = pointB, v3 = pointC;
//		boolean lightState = LIGHT_ON;
//		boolean textureState = TEXTURE_ON;
//		boolean faceMtrl = faceMaterials != null;
//		boolean hasUV = textureState && uvs != null;
//		boolean hasTexList = faceMtrl && textureList != null && hasUV;
//		if (normals == null)
//			LIGHT_ON = false;
//		int faceIndex = 0;
//		
//		int off2d0 = 0, off2d1, off2d2, offs0, offs1, offs2;
//		
//		for (int i = 0; i < indices.length; i += 3, faceIndex++) {
//			TEXTURE_ON = false;
//			if (hasTexList)
//				texture = textureList.get(faceMaterials[faceIndex]);
//			if (hasUV && texture != null)
//				TEXTURE_ON = true;
////			float[] ws= SoftGraphics3D.tmp_w;
////			v1.w = ws[indices[i]];v2.w = ws[indices[i + 1]];v3.w = ws[indices[i + 2]];
//			
//			offs0 = indices[i] * 3;
//			v1.objX = vertices[offs0];
//			v1.objY = vertices[offs0 + 1];
//			v1.objZ = vertices[offs0 + 2];
//			offs1 = indices[i + 1] * 3;
//			v2.objX = vertices[offs1];
//			v2.objY = vertices[offs1 + 1];
//			v2.objZ = vertices[offs1 + 2];
//			offs2 = indices[i + 2] * 3;
//			v3.objX = vertices[offs2];
//			v3.objY = vertices[offs2 + 1];
//			v3.objZ = vertices[offs2 + 2];
//			off2d0 = indices[i] << 1;
//			v1.winX = screenBuf[off2d0];
//			v1.winY = screenBuf[off2d0 + 1];
//			off2d1 = indices[i + 1] << 1;
//			v2.winX = screenBuf[off2d1];
//			v2.winY = screenBuf[off2d1 + 1];
//			off2d2 = indices[i + 2] << 1;
//			v3.winX = screenBuf[off2d2];
//			v3.winY = screenBuf[off2d2 + 1];
//			if (!drawPass1() || (CULL_BACK && isBackFace())
//					|| (CULL_FRONT && !isBackFace()))
//				continue;
//			if (TEXTURE_ON) {
//				v1.texX = uvs[off2d0];
//				v1.texY = uvs[off2d0 + 1];
//				v2.texX = uvs[off2d1];
//				v2.texY = uvs[off2d1 + 1];
//				v3.texX = uvs[off2d2];
//				v3.texY = uvs[off2d2 + 1];
//			}
//			if (LIGHT_ON) {
//				v1.nrmX = normals[offs0];
//				v1.nrmY = normals[offs0 + 1];
//				v1.nrmZ = normals[offs0 + 2];
//				v2.nrmX = normals[offs1];
//				v2.nrmY = normals[offs1 + 1];
//				v2.nrmZ = normals[offs1 + 2];
//				v3.nrmX = normals[offs2];
//				v3.nrmY = normals[offs2 + 1];
//				v3.nrmZ = normals[offs2 + 2];
//				lighting();
//			}
//			fragPass.id = faceIndex;
//			drawTriangle();// TODO
//		}
//		LIGHT_ON = lightState;
//		TEXTURE_ON = textureState;
//	}
	public static float zBufferInit=999999999f;//999999999f
	public final void beginScene() {
		Arrays.fill(zBuffer, zBufferInit);// -32767f
		Arrays.fill(pixels, 0);
	}

	public final void present() {
		graphics2D.drawImage(image, 8, 30, java.awt.Color.black, null);
	}

	/**
	 * ���㶥�㷨��
	 * 
	 * @param vertices
	 * @param indices
	 * @param normals
	 */
	public static void computeNormals(float[] vertices, int[] indices,
			float[] normals) {
		Arrays.fill(normals, 0f);
		int offs0, offs1, offs2;
		float[] vec0 = { 0, 0, 0 }, vec1 = { 0, 0, 0 }, result = { 0, 0, 0 };
		for (int i = 0; i < indices.length; i += 3) {
			offs0 = indices[i] * 3;
			offs1 = indices[i + 1] * 3;
			offs2 = indices[i + 2] * 3;
			vec0[0] = vertices[offs1] - vertices[offs0];
			vec0[1] = vertices[offs1 + 1] - vertices[offs0 + 1];
			vec0[2] = vertices[offs1 + 2] - vertices[offs0 + 2];
			vec1[0] = vertices[offs2] - vertices[offs1];
			vec1[1] = vertices[offs2 + 1] - vertices[offs1 + 1];
			vec1[2] = vertices[offs2 + 2] - vertices[offs1 + 2];
			Vec3.cross(vec0, vec1, result);
			Vec3.normalize(result);
			normals[offs0] += result[0];
			normals[offs0 + 1] += result[1];
			normals[offs0 + 2] += result[2];
			normals[offs1] += result[0];
			normals[offs1 + 1] += result[1];
			normals[offs1 + 2] += result[2];
			normals[offs2] += result[0];
			normals[offs2 + 1] += result[1];
			normals[offs2 + 2] += result[2];
		}
		Vec3.normalizeAll(normals);
	}

	public void drawString(String str, int x, int y) {
		bufferedGraphics.drawString(str, x, y);
	}
}