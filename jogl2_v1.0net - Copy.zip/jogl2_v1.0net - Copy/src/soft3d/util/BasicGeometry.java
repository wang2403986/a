package soft3d.util;

import soft3d.Vec3;

/**
 * �������弸��ͼ��
 * @author Administrator
 *
 */
public class BasicGeometry {
	/**
	 * ��������
	 * @param width
	 * @param height
	 * @param m
	 * @param n
	 * @param mesh
	 */
	public static void CreateGrid(float width, float height, int m, int n, Mesh mesh)
	{
//		mesh.vertices.clear();
//		mesh.indices.clear();
		//ÿ�ж�������ÿ�ж�����
		int nVertsRow = m + 1;
		int nVertsCol = n + 1;
		//��ʼx��z����
		float oX = -width * 0.5f;
		float oZ = height * 0.5f;
		//ÿһ����������仯
		float dx = width / m;
		float dz = height /n;

		//������������nVertsRow * nVertsCol
		mesh.rawVertices=new CustomVertex[nVertsRow * nVertsCol];
		for (int i = 0; i < mesh.rawVertices.length; i++) {
			mesh.rawVertices[i]=new CustomVertex();
		}

		//������Ӷ���
		for(int i=0; i<nVertsCol; ++i)
		{
			float tmpZ = oZ - dz * i;
			for(int j=0; j<nVertsRow; ++j)
			{
				int index = nVertsRow * i + j;
				mesh.rawVertices[index].pos=new float[3];
				mesh.rawVertices[index].pos[0] = oX + dx * j;
				mesh.rawVertices[index].pos[1] = 0.f;
				mesh.rawVertices[index].pos[2] = tmpZ;

				mesh.rawVertices[index].normal = new float[]{0.f,1.f,0.f};
				mesh.rawVertices[index].tangent = new float[]{1.f,0.f,0.f};
				
				mesh.rawVertices[index].tex = new float[]{dx*j/width,dx*i/height};
			}
		}

		//�ܸ�������:m * n
		//�������������: 6 * m * n
		int nIndices = m * n * 6;
		mesh.indices=new int[nIndices];
		int tmp = 0;
		for(int i=0; i<n; ++i)
		{
			for(int j=0; j<m; ++j)
			{
				mesh.indices[tmp] = i * nVertsRow + j;
				mesh.indices[tmp+1] = i * nVertsRow + j + 1;
				mesh.indices[tmp+2] = (i + 1) * nVertsRow + j;
				mesh.indices[tmp+3] = i * nVertsRow + j + 1;
				mesh.indices[tmp+4] = (i + 1) * nVertsRow + j + 1;
				mesh.indices[tmp+5] = (i + 1) * nVertsRow + j;
				
				tmp += 6;
			}
		}
	}
	/**
	 * ����������
	 * @param width ��
	 * @param height ��
	 * @param depth ��
	 * @param mesh
	 */
	public static void CreateBox(float width, float height, float depth, Mesh mesh)
	{
//		mesh.vertices.clear();
//		mesh.indices.clear();

		//һ��24������(ÿ��4��)
		mesh.rawVertices=new CustomVertex[24];
		for (int i = 0; i < mesh.rawVertices.length; i++) {
			mesh.rawVertices[i]=new CustomVertex();
		}
		//һ��36������(ÿ��6��)
		mesh.indices=new int[36];

		float halfW = width * 0.5f;
		float halfH = height * 0.5f;
		float halfD = depth * 0.5f;

		//�۾�����z��������
		//��������
		//ǰ��
		mesh.rawVertices[0].pos = new float[]{-halfW,-halfH,-halfD};
		mesh.rawVertices[0].normal = new float[]{0.f,0.f,-1.f};
		mesh.rawVertices[0].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[0].tex = new float[]{0.f,1.f};
		mesh.rawVertices[1].pos = new float[]{-halfW,halfH,-halfD};
		mesh.rawVertices[1].normal = new float[]{0.f,0.f,-1.f};
		mesh.rawVertices[1].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[1].tex = new float[]{0.f,0.f};
		mesh.rawVertices[2].pos = new float[]{halfW,halfH,-halfD};
		mesh.rawVertices[2].normal = new float[]{0.f,0.f,-1.f};
		mesh.rawVertices[2].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[2].tex = new float[]{1.f,0.f};
		mesh.rawVertices[3].pos = new float[]{halfW,-halfH,-halfD};
		mesh.rawVertices[3].normal = new float[]{0.f,0.f,-1.f};
		mesh.rawVertices[3].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[3].tex = new float[]{1.f,1.f};
		//�����
		mesh.rawVertices[4].pos = new float[]{-halfW,-halfH,halfD};
		mesh.rawVertices[4].normal = new float[]{-1.f,0.f,0.f};
		mesh.rawVertices[4].tangent = new float[]{0.f,0.f,-1.f};
		mesh.rawVertices[4].tex = new float[]{0.f,1.f};
		mesh.rawVertices[5].pos = new float[]{-halfW,halfH,halfD};
		mesh.rawVertices[5].normal = new float[]{-1.f,0.f,0.f};
		mesh.rawVertices[5].tangent = new float[]{0.f,0.f,-1.f};
		mesh.rawVertices[5].tex = new float[]{0.f,0.f};
		mesh.rawVertices[6].pos = new float[]{-halfW,halfH,-halfD};
		mesh.rawVertices[6].normal = new float[]{-1.f,0.f,0.f};
		mesh.rawVertices[6].tangent = new float[]{0.f,0.f,-1.f};
		mesh.rawVertices[6].tex = new float[]{1.f,0.f};
		mesh.rawVertices[7].pos = new float[]{-halfW,-halfH,-halfD};
		mesh.rawVertices[7].normal = new float[]{-1.f,0.f,0.f};
		mesh.rawVertices[7].tangent = new float[]{0.f,0.f,-1.f};
		mesh.rawVertices[7].tex = new float[]{1.f,1.f};
		//����
		mesh.rawVertices[8].pos = new float[]{halfW,-halfH,halfD};
		mesh.rawVertices[8].normal = new float[]{0.f,0.f,1.f};
		mesh.rawVertices[8].tangent = new float[]{-1.f,0.f,0.f};
		mesh.rawVertices[8].tex = new float[]{0.f,1.f};
		mesh.rawVertices[9].pos = new float[]{halfW,halfH,halfD};
		mesh.rawVertices[9].normal = new float[]{0.f,0.f,1.f};
		mesh.rawVertices[9].tangent = new float[]{-1.f,0.f,0.f};
		mesh.rawVertices[9].tex = new float[]{0.f,0.f};
		mesh.rawVertices[10].pos = new float[]{-halfW,halfH,halfD};
		mesh.rawVertices[10].normal = new float[]{0.f,0.f,1.f};
		mesh.rawVertices[10].tangent = new float[]{-1.f,0.f,0.f};
		mesh.rawVertices[10].tex = new float[]{1.f,0.f};
		mesh.rawVertices[11].pos = new float[]{-halfW,-halfH,halfD};
		mesh.rawVertices[11].normal = new float[]{0.f,0.f,1.f};
		mesh.rawVertices[11].tangent = new float[]{-1.f,0.f,0.f};
		mesh.rawVertices[11].tex = new float[]{1.f,1.f};
		//�Ҳ���
		mesh.rawVertices[12].pos = new float[]{halfW,-halfH,-halfD};
		mesh.rawVertices[12].normal = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[12].tangent = new float[]{0.f,0.f,1.f};
		mesh.rawVertices[12].tex = new float[]{0.f,1.f};
		mesh.rawVertices[13].pos = new float[]{halfW,halfH,-halfD};
		mesh.rawVertices[13].normal = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[13].tangent = new float[]{0.f,0.f,1.f};
		mesh.rawVertices[13].tex = new float[]{0.f,0.f};
		mesh.rawVertices[14].pos = new float[]{halfW,halfH,halfD};
		mesh.rawVertices[14].normal = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[14].tangent = new float[]{0.f,0.f,1.f};
		mesh.rawVertices[14].tex = new float[]{1.f,0.f};
		mesh.rawVertices[15].pos = new float[]{halfW,-halfH,halfD};
		mesh.rawVertices[15].normal = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[15].tangent = new float[]{0.f,0.f,1.f};
		mesh.rawVertices[15].tex = new float[]{1.f,1.f};
		//����
		mesh.rawVertices[16].pos = new float[]{-halfW,halfH,-halfD};
		mesh.rawVertices[16].normal = new float[]{0.f,1.f,0.f};
		mesh.rawVertices[16].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[16].tex = new float[]{0.f,1.f};
		mesh.rawVertices[17].pos = new float[]{-halfW,halfH,halfD};
		mesh.rawVertices[17].normal = new float[]{0.f,1.f,0.f};
		mesh.rawVertices[17].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[17].tex = new float[]{0.f,0.f};
		mesh.rawVertices[18].pos = new float[]{halfW,halfH,halfD};
		mesh.rawVertices[18].normal = new float[]{0.f,1.f,0.f};
		mesh.rawVertices[18].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[18].tex = new float[]{1.f,0.f};
		mesh.rawVertices[19].pos = new float[]{halfW,halfH,-halfD};
		mesh.rawVertices[19].normal = new float[]{0.f,1.f,0.f};
		mesh.rawVertices[19].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[19].tex = new float[]{1.f,1.f};
		//����
		mesh.rawVertices[20].pos = new float[]{-halfW,-halfH,halfD};
		mesh.rawVertices[20].normal = new float[]{0.f,-1.f,0.f};
		mesh.rawVertices[20].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[20].tex = new float[]{0.f,1.f};
		mesh.rawVertices[21].pos = new float[]{-halfW,-halfH,-halfD};
		mesh.rawVertices[21].normal = new float[]{0.f,-1.f,0.f};
		mesh.rawVertices[21].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[21].tex = new float[]{0.f,0.f};
		mesh.rawVertices[22].pos = new float[]{halfW,-halfH,-halfD};
		mesh.rawVertices[22].normal = new float[]{0.f,-1.f,0.f};
		mesh.rawVertices[22].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[22].tex = new float[]{1.f,0.f};
		mesh.rawVertices[23].pos = new float[]{halfW,-halfH,halfD};
		mesh.rawVertices[23].normal = new float[]{0.f,-1.f,0.f};
		mesh.rawVertices[23].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[23].tex = new float[]{1.f,1.f};
		
		//��������
		mesh.indices[0] = 0;
		mesh.indices[1] = 1;
		mesh.indices[2] = 2;
		mesh.indices[3] = 0;
		mesh.indices[4] = 2;
		mesh.indices[5] = 3;
		
		mesh.indices[6] = 4;
		mesh.indices[7] = 5;
		mesh.indices[8] = 6;
		mesh.indices[9] = 4;
		mesh.indices[10] = 6;
		mesh.indices[11] = 7;
		
		mesh.indices[12] = 8;
		mesh.indices[13] = 9;
		mesh.indices[14] = 10;
		mesh.indices[15] = 8;
		mesh.indices[16] = 10;
		mesh.indices[17] = 11;
		
		mesh.indices[18] = 12;
		mesh.indices[19] = 13;
		mesh.indices[20] = 14;
		mesh.indices[21] = 12;
		mesh.indices[22] = 14;
		mesh.indices[23] = 15;
		
		mesh.indices[24] = 16;
		mesh.indices[25] = 17;
		mesh.indices[26] = 18;
		mesh.indices[27] = 16;
		mesh.indices[28] = 18;
		mesh.indices[29] = 19;
		
		mesh.indices[30] = 20;
		mesh.indices[31] = 21;
		mesh.indices[32] = 22;
		mesh.indices[33] = 20;
		mesh.indices[34] = 22;
		mesh.indices[35] = 23;
	}
	/**
	 * ��������
	 * @param radius
	 * @param slice
	 * @param stack
	 * @param mesh
	 */
	public static void CreateSphere(float radius, int slice, int stack, Mesh mesh)
	{
//		mesh.vertices.clear();
//		mesh.indices.clear();

		int vertsPerRow = slice + 1;
		int nRows = stack - 1;

		int nVerts = vertsPerRow * nRows + 2;
		int nIndices = (nRows-1)*slice*6 + slice * 6;

		mesh.rawVertices=new CustomVertex[nVerts];
		for (int i = 0; i < mesh.rawVertices.length; i++) {
			mesh.rawVertices[i]=new CustomVertex();
		}
		mesh.indices=new int[nIndices];

		for(int i=1; i<=nRows; ++i)
		{
			float phy = (float)Math.PI * i / stack;//XM_PI
			float tmpRadius = radius * (float)Math.sin(phy);
			for(int j=0; j<vertsPerRow; ++j)
			{
				float theta = (float)Math.PI*2 * j / slice;//XM_2PI
				int index = (i-1)*vertsPerRow+j;

				float x = tmpRadius*(float)Math.cos(theta);
				float y = radius*(float)Math.cos(phy);
				float z = tmpRadius*(float)Math.sin(theta);

				//λ������
				mesh.rawVertices[index].pos = new float[]{x,y,z};
				//����
				float[] N = new float[]{x,y,z,0.f};
				Vec3.normalize1(N);
				mesh.rawVertices[index].normal=N;
				//����
//				XMVECTOR T = XMVectorSet(-sin(theta),0.f,cos(theta),0.f);
//				XMStoreFloat3(&mesh.vertices[index].tangent,XMVector3Normalize(T));
				//��������
				mesh.rawVertices[index].tex = new float[]{j*1.f/slice,i*1.f/stack};
			}
		}

		int size = vertsPerRow * nRows;
		//���Ӷ����͵ײ�����������Ϣ
		mesh.rawVertices[size].pos = new float[]{0.f,radius,0.f};
		mesh.rawVertices[size].normal = new float[]{0.f,1.f,0.f};
		mesh.rawVertices[size].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[size].tex = new float[]{0.f,0.f};

		mesh.rawVertices[size+1].pos = new float[]{0.f,-radius,0.f};
		mesh.rawVertices[size+1].normal = new float[]{0.f,-1.f,0.f};
		mesh.rawVertices[size+1].tangent = new float[]{1.f,0.f,0.f};
		mesh.rawVertices[size+1].tex = new float[]{0.f,1.f};
		
		int tmp=(0);
		int start1 = 0;
		int start2 = mesh.rawVertices.length - vertsPerRow - 2;
		int top = size;
		int bottom = size + 1;
		for(int i=0; i<slice; ++i)
		{
			mesh.indices[tmp] = top;
			mesh.indices[tmp+1] = start1+i+1;
			mesh.indices[tmp+2] = start1+i;

			tmp += 3;
		}

		for(int i=0; i<slice; ++i)
		{
			mesh.indices[tmp] = bottom;
			mesh.indices[tmp+1] = start2 + i;
			mesh.indices[tmp+2] = start2 + i + 1;

			tmp += 3;
		}

		for(int i=0; i<nRows-1; ++i)
		{
			for(int j=0; j<slice; ++j)
			{
				mesh.indices[tmp] = i * vertsPerRow + j;
				mesh.indices[tmp+1] = (i + 1) * vertsPerRow + j + 1;
				mesh.indices[tmp+2] = (i + 1) * vertsPerRow + j;
				mesh.indices[tmp+3] = i * vertsPerRow + j;
				mesh.indices[tmp+4] = i * vertsPerRow + j + 1;
				mesh.indices[tmp+5] = (i + 1) * vertsPerRow + j + 1;

				tmp += 6;
			}
		}
	}


}
