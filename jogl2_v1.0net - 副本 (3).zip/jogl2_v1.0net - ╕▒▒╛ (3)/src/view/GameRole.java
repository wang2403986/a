package view;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

import javax.media.opengl.GL2;
import javax.media.opengl.glu.GLU;

import soft3d.Vec3;
import loader.war3mdl.War3MdlModel;
import static view.Util.*;

public class GameRole implements KeyListener,MouseListener,MouseMotionListener,MouseWheelListener{

	public GameRole(War3MdlModel m){
		model = m;
	}
	public War3MdlModel model;
	public final float[] localRot=new float[4];
	public final float[] localTrans=new float[4];
	public final float[] localScale=new float[]{1,1,1};
	public final float[] moveTo={0,0,0,0};
	/** ״̬��0��վ��,1:�ƶ��� */
	public int status = 0;
	public int id;
	
	public long time=System.currentTimeMillis();
	public long moveStartTime,moveEndTime;
	public final float[] moveStart= {0,0,0,0};
	public final float[] startPosition=new float[4];
	public synchronized void move(float[] moveTo){
		for(int i=0;i<localTrans.length;i++){
			startPosition[i] = localTrans[i];
		}
		moveStartTime = time;
		float[] dif=Vec3.sub(moveTo, localTrans);
		dif[2]=0;
		float angleZ=(float) Math.toDegrees(Util.axesAngleOfVector(dif));
//		System.out.println("x:"+dif[0]+"y:"+dif[1]+"angleZ:"+angleZ);
		float[] rot = {0,0,angleZ,0};
		veccopy(localRot,rot);
		double d=Math.sqrt(dif[0]*dif[0]+dif[1]*dif[1]+dif[2]*dif[2]);
		moveEndTime = (int) d*100;
		moveEndTime = time +3000;
		status =1;
		veccopy(this.moveTo, moveTo);
	}
	public void updatePosition(long timesq){
		if(status!=1){
			return;
		}
		if(timesq>=moveEndTime)
		{
			veccopy(localTrans ,  moveTo);
			status = 0;
		} else {
			float[] dif=
					Vec3.sub(moveTo, startPosition);
			float r=(timesq-moveStartTime)/(float)(moveEndTime-moveStartTime);
			dif =Vec3.mul(r, dif);
			veccopy(localTrans , Vec3.add(startPosition, dif));
			
		}
	}
	public void updateByTime(long time, GL2 gl) {
		this.time = time;
		updatePosition(time);
		for (int i = 0; i < localRot.length; i++) {
			model.localRot[i]=localRot[i];
		}
		for (int i = 0; i < localScale.length; i++) {
			model.localScale[i]=localScale[i];
		}
		for (int i = 0; i < localTrans.length; i++) {
			model.localTrans[i]=localTrans[i];
		}
		model.status = status;
		model.updateByTime(time, gl);
		
	}
	public void draw(GL2 gl, GLU glu) {
		model.drawAnimation(gl, glu);
	}
	@Override
	public void keyTyped(KeyEvent e) {
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int vk = e.getKeyCode();
		switch (vk) {
		case KeyEvent.VK_DOWN:
			break;
		default:
			break;
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		System.out.println(localTrans[0]+","+localTrans[1]+","+localTrans[2]+",");

		int h=e.getComponent().getSize().height;
		int w = e.getComponent().getSize().width;
		float x=e.getX()/(float)w*1500 -780;
		float y=-e.getY()/(float)h*900 +450;
		float[] fs={x,y,0,0};//-600,600,-780  -450,450
		System.out.println("mouse pos:" +e.getX()+","+e.getY());
		System.out.println("width:" +e.getComponent().getSize().width);
		move(fs);
		SocketHandler.getDefault().sendMoveCmd();
	}

	@Override
	public void mousePressed(MouseEvent e) {
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		
	}

	@Override
	public void mouseWheelMoved(MouseWheelEvent e) {
		int num = e.getWheelRotation();
		localTrans[2]+=num/4f;
	}

	@Override
	public void mouseDragged(MouseEvent e) {
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		
	}
}
