package view;
import static java.lang.Math.PI;
import static java.lang.Math.atan;
public class Util {

	/**
     *  �õ�һ�������ڼ������µĽǶ�
     * @param vector
     * @return
     */
    public static double axesAngleOfVector(float[] vector)
    {
        double x=vector[0];
        double y=vector[1];
        
        if (x == 0f)
        {
            if (y == 0f)
                return 0;
            else if (y > 0)
                return PI/2;//    90;
            else
                return PI+PI/2;
        }

        if (y == 0f)
        {
            if (x > 0)
                return 0;
            else
                return PI;
        }
        //��һ����
        if (x >= 0 && y >= 0)
        {
            return atan(y / x);
        }
        //�ڶ�����
        else if (x <= 0 && y >= 0)
        {
            return PI +atan(y / x);
        }
        //��3����
        else if (x <= 0 && y <= 0)
        {
            return PI + atan(y / x);
        }
        //��4����
        else if (x >= 0 && y <= 0)
        {
            return PI*2+atan(y / x);
        }
        return Double.NaN;
    }
    /**
     * vector equals
     * @param a1
     * @param a2
     * @return
     */
    public static boolean vecEquals(float[] a1, float[] a2){
		for (int i = 0; i < 3; i++) {
			if(a1[i]!=a2[i])
				return false;
		}
		return true;
	}
    /**
     * vector copy
     * @param dst
     * @param src
     */
    public static void veccopy(float[] dst, float[] src){
		for (int i = 0; i < 3; i++) {
			dst[i]=src[i];
		}
	}
    /**
     * vector copy
     * @param dst
     * @param src
     */
    public static void vec4copy(float[] dst, float[] src){
		for (int i = 0; i < 4; i++) {
			dst[i]=src[i];
		}
	}
    public static void arraycopy(float[] dst, float[] src){
    	for (int i = 0; i < src.length; i++) {
    		dst[i]=src[i];
		}
    }
    public static void arraycopy(float[] dst, float[] src, int length){
    	for (int i = 0; i < length; i++) {
    		dst[i]=src[i];
		}
    }
}
