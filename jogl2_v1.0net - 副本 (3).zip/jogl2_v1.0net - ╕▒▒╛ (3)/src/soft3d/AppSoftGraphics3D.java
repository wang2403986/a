package soft3d;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.Timer;

import loader.xfile.XModel;
import loader.xfile.XModelSerializer;
import soft3d.util.BasicGeometry;
import soft3d.util.Extent;
import soft3d.util.Mesh;
import soft3d.Framebuffer;
import soft3d.v1_0.Camera;
import soft3d.v1_0.GLM;
import soft3d.v1_0.Matrix4;
import soft3d.v1_0.MipmapEXT;
import soft3d.v1_0.TinyGL;
import soft3d.v1_0.TrackballControls;
import soft3d.v1_0.compiler.ShaderCompiler;
import soft3d.v1_0.compiler.types.*;

import static soft3d.Matrix.loadIdentity;
import static soft3d.Framebuffer.VIEWMATRIX;
import static soft3d.v1_0.VertexAttribPointer.*;

public class AppSoftGraphics3D extends JFrame implements ActionListener{	
	private static final long serialVersionUID = 1L;
	String folder="D:/Download/anew/models/exp/";//a1-18 a13
	String f0=System.getProperty("user.dir")+"\\models\\";
	String f1="D:/Download/anew/models/models/";//teapot a1 tiny lxq
	String f2="D:/Download/anew/models/tmp/";//a1 a2 a3
	String f3="D:/�û�Ŀ¼/Downloads/Xģ��/";//������ ��ӣ�� Ů�� ��Ů
	String t1="D:/�û�Ŀ¼/Documents/20140822/�����/";
	String f4=t1+"\\model-2014-5\\";//a1-7
	String f5=t1+"\\tmp2\\";//a1-6 teapot teapot1-3
	String f6=t1+"/newModels/";//a1
	String f7="C:\\Users\\Administrator\\Desktop\\X Exporter\\a1\\";
	String f8="C:\\Users\\Administrator\\Desktop\\X Exporter\\a2\\aaa\\";
	String f9="C:\\Users\\Administrator\\Desktop\\X Exporter\\a2\\";
//	LoopSubdivision subdivision=new LoopSubdivision();
//	PNTriangles PN=new PNTriangles();
//	PhongTessellation phongTess=new PhongTessellation();
	Mesh mesh1=new Mesh();
	public AppSoftGraphics3D() {
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		folder = f7;
		xfile = "a.X";
		init();
		model=new XModelSerializer().importFromFile(folder+xfile);
//		folder=folder+xfile.substring(0, xfile.length()-2)+"/";
		model.loadTexture(folder);
//		model.updateByTime(200);model.calcExtent(extent,true);
//		BasicGeometry.CreateGrid(16, 16,1,1, meshData);
//		BasicGeometry.CreateBox(16, 16, 8, meshData);
//		BasicGeometry.CreateSphere(16,160, 160, meshData);//160
//		BasicGeometry.CreateGrid(200, 200, 8, 8, mesh1);
//		meshData.passConvert();
		
//		meshData=MeshData.create(model.frames.get(0).mesh);
//		PN.tessellate(meshData);PN.convertToMesh();
//		phongTess.tessellate(meshData);phongTess.convertToMesh();
//		meshData.creatSimpleMesh2();
//		meshData.passConvert();
//		SoftGraphics3D.computeNormals(meshData.vertices, meshData.indices, meshData.normals);
//		subdivision.loadModel(meshData);//model.frames.get(0).mesh
//		for (int i = 0; i < 4; i++)
//		subdivision.loopSubdivision();
//		subdivision.convertToMesh();
		initGL();
	}
	long frameTime=System.currentTimeMillis();
	int frameCount=0,frameRate=0;
	ArrayList<BufferedImage> bufferedImages;
	public void initGL(){
		glBindAttribLocation(0, 0, "position");//position
		glBindAttribLocation(0, 1, "texCoord");//texCoord
		glBindAttribLocation(0, 2, "normal");//normal
		glVertexAttribPointer(0, 3, 0, true, 0, 0);//position
		glVertexAttribPointer(1, 2, 0, true, 0, 0);//texCoord
		glVertexAttribPointer(2, 3, 0, true, 0, 0);//normal
		gl = new soft3d.v1_0.TinyGLImpl2();
//		gl=ShaderCompiler.createProgram("kernels/vertexShader.txt","kernels/fragShader.txt");
		gl.texture0 = Framebuffer.texture;
//		bufferedImages = MipmapEXT.createMipmapEXT(gl.texture0);
		framebuffer=new Framebuffer(getGraphics(),1024,680);
		gl.glBindFramebuffer(framebuffer);
		trackball=new TrackballControls(this);
		trackball.handleResize(TinyGL.width, TinyGL.height);
		camera = new Camera(this);
		camera.reshape(gl.width,gl.height);
	}
	TrackballControls trackball;
	Camera camera;
	protected void render() {
		Matrix4.identity(TinyGL.GLProjectionMatrix);
		Matrix4.identity(TinyGL.GLViewMatrix);
		
		Matrix4.perspective(TinyGL.GLProjectionMatrix,45, 1f, 1f, 1000.0f);
		trackball.update();
		vec3 eye=trackball.object.position, target= trackball.object.target,
				up=trackball.object.up;
		Matrix4.lookAt(TinyGL.GLViewMatrix, eye, target, up);
//		camera.update(.1f);
//		Matrix4.copy(TinyGL.GLViewMatrix, camera.view_matrix());
		
//		Matrix4.translate(TinyGL.GLProjectionMatrix, 10, 13, 0);
//		Matrix4.rotateY(TinyGL.GLViewMatrix, (float)Math.toRadians(90));
//		Matrix4.scale(TinyGL.GLViewMatrix, 2, 2, 2);
//		Matrix4.translate(TinyGL.GLViewMatrix, 0, 13, -20);//39 20   13 -10
		Matrix4.copy(VIEWMATRIX, TinyGL.GLViewMatrix);//�� (arg2)  ��(arg1),
		if (!isShowing()) {
			return;
		}
		gl.glClear(0);
		long time=System.currentTimeMillis()-beginTime;
		model.updateByTime(time<<2);  model.draw(gl);
//		meshData.update();
//		gl.texture0 = Framebuffer.texture;
//		glBindBufferData(0, 0, 0, meshData.verticesBuf, 0);//position
//		glBindBufferData(0, 1, 0, meshData.texCoords, 0);//texCoord
//		glBindBufferData(0, 2, 0, meshData.normalsBuf, 0);//normal
//		gl.glDrawElements(0, 0, 0, meshData.indices);
		
//		subdivision.update();subdivision.draw(graphics3d);
//		PN.update();PN.draw(graphics3d);
//		phongTess.update();phongTess.draw(graphics3d);
//		model.updateByTime(time<<2);
		if(System.currentTimeMillis()-frameTime>1000){
			frameTime=System.currentTimeMillis();
			frameRate=frameCount;
			frameCount=0;
		}
		frameCount++;
		framebuffer.drawString("����֡�ʣ�"+frameRate, 20,20);
		int height=0;
		if(bufferedImages!=null)
		for (BufferedImage i: bufferedImages) {
			framebuffer.bufferedGraphics.drawImage(i, height, 40, null);
			height+=i.getWidth();
		}
		gl.glFinish(0);
		 
	}
	
	public static void main(String[] s) {
		AppSoftGraphics3D app=new AppSoftGraphics3D();
		app.setVisible(true);
		Timer timer=new Timer(10, app);
		timer.start();
	}
	Framebuffer framebuffer;
	TinyGL gl; 
	void init(){
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setSize(1048, 700);
		this.setVisible(true);
		try {
			Framebuffer.texture=new Texture("D:/�û�Ŀ¼/Pictures/a1.png");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		ComponentAdapter adapter = new ComponentAdapter() {
			@Override
			public void componentResized(ComponentEvent e) {
				Container contentPane=AppSoftGraphics3D.this.getContentPane();
				contentPane.getLocationOnScreen();// ע��ֻ�д�����ʾ��getLocationOnScreen�ſ��Ե��ã��������
				Dimension size = contentPane.getSize(); // ��������Ĵ�С
				gl.glViewport(size.width, size.height);
				trackball.handleResize(size.width, size.height);
			}
		};
		this.addComponentListener(adapter);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		render();
	}
	float rx=0,ry=0,tx=0,ty=0;
	final float[][] mat4 ={{0,0,0,0},{0,0,0,0},{0,0,0,0},{0,0,0,0}};
	
	XModel model=null;
	Mesh meshData=new Mesh();
	final Extent extent=new Extent();
	long beginTime=System.currentTimeMillis();
	String xfile="";
}
