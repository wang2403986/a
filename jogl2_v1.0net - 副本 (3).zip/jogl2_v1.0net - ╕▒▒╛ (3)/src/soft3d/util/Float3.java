package soft3d.util;

public class Float3 {

	public static void main(String[] args) {
		float[] v0={1,1,1};
		float[] v1={1,1,1};
		add(v0, v1);
		add(v0);
		float[] v2={1,1,1};
		add(v0, v1,v2);
	}
	public static float[] float3(float x,float y,float z) {
		float[] r={x,y,z};
		return r;
	}
	public static float[] add(float[] v0,float[] v1) {
		float[] r={v0[0]+v1[0],v0[1]+v1[1],v0[2]+v1[2]};
		return r;
		
	}
	public static float[] add(float[]...vs ) {
		float[] r={0,0,0};
		int len=vs.length;
		for (int i = 0; i < len; i++) {
			r[0]+=vs[i][0];
			r[1]+=vs[i][1];
			r[2]+=vs[i][2];
		}
		return r;
		
	}
	public static float[] sub(float[]v0, float[]v1) {
		float[] r={v0[0]-v1[0],v0[1]-v1[1],v0[2]-v1[2]};
		
		return r;
		
	}
	public static float dot(float[]v0, float[]v1) {
		float x0=v0[0],y0=v0[1],z0=v0[2];
		float x1=v1[0],y1=v1[1],z1=v1[2];
		return x0*x1+y0*y1+z0*z1;
	}
	/**
	 ������a=(a1,b1,c1)������b=(a2,b2,c2)�� 
������ <br />
��������a������b= <br />
����| i j k |<br />
����|a1 b1 c1|<br />
����|a2 b2 c2| <br />
����=(b1c2-b2c1,c1a2-a1c2,a1b2-a2b1) 
	 * @param v0
	 * @param v1
	 */
	public static float[] cross(float[] v0,float[] v1) {
		float a1=v0[0],b1=v0[1],c1=v0[2];
		float a2=v1[0],b2=v1[1],c2=v1[2];
		float[] r={b1*c2-b2*c1,c1*a2-a1*c2,a1*b2-a2*b1};
		return r;
	}
	public static float[] mul(float[]v0, float[]v1) {
		float x0=v0[0],y0=v0[1],z0=v0[2];
		float x1=v1[0],y1=v1[1],z1=v1[2];
		float[] r={x0*x1,y0*y1,z0*z1};
		return r;
		
	}
	public static float[] mul(float[] v0,float k ) {
		float[] r={ (k*v0[0]), (k*v0[1]), (k*v0[2])};
		
		return r;
		
	}
	public static float[] mul(float k,float[] v0) {
		float[] r={k*v0[0],k*v0[1],k*v0[2]};
		
		return r;
		
	}
}
