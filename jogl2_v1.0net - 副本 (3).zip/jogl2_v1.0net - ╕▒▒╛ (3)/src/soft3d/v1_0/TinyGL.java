package soft3d.v1_0;

import java.util.HashMap;
import java.util.Map;

import soft3d.Framebuffer;
import soft3d.Texture;
import soft3d.v1_0.compiler.types.mat4;
import soft3d.v1_0.compiler.types.vec4;

public abstract class TinyGL {
	
	public int primitiveID=0;
	public static int GLDepthFunc = 0;
	Framebuffer framebuffer;
	public boolean useLastVSOutput;
	public static final float FAR_CLIP_PLANE = 100000;
	
	public Object[] uniforms = null;
	public Map<String, Integer> uniformsMap = new HashMap<>();
	
	public static int width = 1024, height = 680;
	
	public Texture texture0, texture1, texture2, texture3, texture4;
	
	public static VertexAttribPointer[] vertexAttribPointers = new VertexAttribPointer[10];

	static {
		for (int i = 0; i < vertexAttribPointers.length; i++) {
			vertexAttribPointers[i] = new VertexAttribPointer();
		}
	}

	public boolean isBackFace(vec4 a, vec4 b, vec4 c) {
		float cax = c.x - a.x;
		float cay = c.y - a.y;
		float bcx = b.x - c.x;
		float bcy = b.y - c.y;
//		return false;
		
		return cax * bcy < cay * bcx;
//		return cax * bcy > cay * bcx;
	}
	public final static mat4 GLViewMatrix=new mat4();
	public final static mat4 GLProjectionMatrix=new mat4();
	
	public void glDrawElements(int mode, int count, int type, int[] indices) {

	}
	
	public final void glUniforms(int location, Object[] value​) {
		uniforms[location] = value​;
	}
	public final void glUniform(int location, Object value​) {
		uniforms[location] = value​;
	}
	public final int getUniformLocation(String name​) {
		Integer i = uniformsMap.get(name​);
		return i==null? -1 : i.intValue();
	}
	public void glUniform1fv(int location, float value​) {
		uniforms[location] = value​;
	}
	public final void glViewport(int w, int h) {
		width = w; height = h;
		framebuffer.resize(w, h);
	}
	public final void glBindFramebuffer(Framebuffer fb) {
		framebuffer = fb;
	}
	public final void glClear(int flag) {
		framebuffer.beginScene();
	}
	public final void glFinish(int flag) {
		framebuffer.swapBuffers();
	}
	
//	public static void project(vec4 point) {
//	float halfW = width >> 1, halfH = height >> 1;
////	float difZ = soft3d.SoftGraphics3D.screenZ - soft3d.SoftGraphics3D.focusZ;
////	float w = 1.0f / (point.z - soft3d.SoftGraphics3D.focusZ);
////	float r = difZ * w;
////	float ratio = soft3d.SoftGraphics3D.scaling * r;
////	point.x = point.x * ratio + halfW;
////	/** 右手平面直角坐标系变为左手直角坐标系 */
////	point.y = -point.y * ratio + halfH;
////	point.w = w;
//}
}