package soft3d.v1_0;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.ConvolveOp;
import java.awt.image.DataBufferInt;
import java.awt.image.Kernel;
import java.util.ArrayList;

import soft3d.Texture;
import soft3d.v1_0.GLM;
import soft3d.v1_0.compiler.types.ivec4;
import soft3d.v1_0.compiler.types.vec2;
import soft3d.v1_0.compiler.types.vec3;
import soft3d.v1_0.compiler.types.vec4;

public final class MipmapEXT {
  static int previous_power_of_two( int x ) {
    if (x == 0) {
        return 0;
    }
     x--; //Uncomment this, if you want a strictly less than 'x' result.
    x |= (x >> 1);
    x |= (x >> 2);
    x |= (x >> 4);
    x |= (x >> 8);
    x |= (x >> 16);
    return x - (x >> 1);
}
  static int upper_power_of_two(int v)
  {
      v--;
      v |= v >> 1;
      v |= v >> 2;
      v |= v >> 4;
      v |= v >> 8;
      v |= v >> 16;
      v++;
      return (int) v;

  }
  public static final ArrayList<BufferedImage> createMipmapEXT(Texture tex){
	  ArrayList<BufferedImage> bufferedImages=new ArrayList<BufferedImage>();
	  int start = 4;
	    int end = tex.width;
	    int iii=end -1;
	    BufferedImage image = new BufferedImage(tex.width, tex.height,
	        BufferedImage.TYPE_INT_ARGB);//����һ������ΪԤ����ͼ������֮һ�� BufferedImage��
	    image.setRGB(0, 0, tex.width, tex.height, tex.intData, 0, tex.width);
	    ArrayList<Texture> mipmaps = new ArrayList<Texture>();
	    bufferedImages.add(image);
	    while(previous_power_of_two(iii)>=start){
	      int size = previous_power_of_two(iii);
	      System.err.println(size);
	      if (size*tex.height/tex.width<1) {
	        break;
	      }
	      BufferedImage newImg =scale(image, size ,size*tex.height/tex.width);
	      bufferedImages.add(newImg);
	      Texture tex0= new Texture();
	      tex0.setSize(newImg.getWidth(), newImg.getHeight());
	      tex0.intData = ((DataBufferInt) newImg.getRaster().getDataBuffer()).getData();
	      mipmaps.add(tex0);
	      iii=previous_power_of_two(iii);
	    }
	    
		return bufferedImages;
	    
  }
  public static final void createMipmap(Texture tex){
    int start = 4;
    int end = tex.width;
    int iii=end -1;
    BufferedImage image = new BufferedImage(tex.width, tex.height,
        BufferedImage.TYPE_INT_ARGB);//����һ������ΪԤ����ͼ������֮һ�� BufferedImage��
    image.setRGB(0, 0, tex.width, tex.height, tex.intData, 0, tex.width);
    ArrayList<Texture> mipmaps = new ArrayList<Texture>();
    mipmaps.add(tex);
    while(previous_power_of_two(iii)>=start){
      int size = previous_power_of_two(iii);
      System.err.println(size);
      if (size*tex.height/tex.width<1) {
        break;
      }
      BufferedImage newImg =scale(image, size ,size*tex.height/tex.width);
      Texture tex0= new Texture();
      tex0.setSize(newImg.getWidth(), newImg.getHeight());
      tex0.intData = ((DataBufferInt) newImg.getRaster().getDataBuffer()).getData();
      mipmaps.add(tex0);
      iii=previous_power_of_two(iii);
    }
    tex.mipmap=new Texture[mipmaps.size()];
    mipmaps.toArray(tex.mipmap);
  }
  public static final ivec4 texture2D(Texture tex,vec3 UV) {
	  return texture2D(tex, GLM.vec2(UV.x,UV.y), UV.z);
  }
  public static final ivec4 texture2D(Texture tex,vec2 UV, float mipmap) {
    int Level = (int) (mipmap);
    if (Level<0) 
      Level=0;
    int length = tex.mipmap.length;
    if (Level>= length)
      Level=length-1;
//    final ivec4 color=GLM.texture2D(tex.mipmap[Level], GLM.vec2(UV.x,UV.y));
    final ivec4 color=new ivec4();
    tex.mipmap[Level].bilinearFilter(color, UV.x,UV.y);
    if (mipmap>0 && Level+1<length) {
//      ivec4 color1=GLM.texture2D(tex.mipmap[Level+1], GLM.vec2(UV.x,UV.y));
      final ivec4 color1=new ivec4();
      tex.mipmap[Level+1].bilinearFilter(color1, UV.x,UV.y);
      float ratio =(mipmap-Level);
      int pm0=(int) (ratio*(2048));
	  int pm1=(2048-pm0);
//	  color.x =  (pm1*color.x+ pm0*color1.x)>>11;
	  color.y =  (pm1*color.y+ pm0*color1.y)>>11;
      color.z =  (pm1*color.z+ pm0*color1.z)>>11;
      color.w =  (pm1*color.w+ pm0*color1.w)>>11;
//      color.y = (int) ((1-ratio)*color.y+ ratio*color1.y);
//      color.z = (int) ((1-ratio)*color.z+ ratio*color1.z);
//      color.w = (int) ((1-ratio)*color.w+ ratio*color1.w);
    }
    return color;
  }
  private static final double HALF_INVLOG2 = 0.5 / Math.log(2);
  public static final float mipmapLevel(Texture texture,vec2 UV, vec2 ddx_UV, vec2 ddy_UV,
	      float w,float ddx_w,float ddy_w) {
	  if(texture==null) return 0;
	    float textureSizeX = texture.width;
	    float textureSizeY = texture.height;
	   
	    float tmp0 = (w+ddx_w)==0?w: 1/(w+ddx_w);
	    float tmp1 = (w+ddy_w)==0?w: 1/(w+ddy_w);
	   final vec2 UVxw = UV;
	   UV = GLM.mul(UV, 1.0f/w);
	    float Ux = (UVxw.x + ddx_UV.x)*tmp0  - UV.x;
	    float Vx = (UVxw.y + ddx_UV.y)*tmp0  - UV.y;
	    
	    float Uy = (UVxw.x + ddy_UV.x)*tmp1  - UV.x;
	    float Vy = (UVxw.y + ddy_UV.y)*tmp1  - UV.y;
	    
//	    float Uy = UV0.x + a * u01 + b * u02 - UV.x;
	    Ux = Ux * textureSizeX;
	    Uy = Uy * textureSizeX;
	    Vx = Vx * textureSizeY;
	    Vy = Vy * textureSizeY;
	    float d = Math.max((Ux * Ux + Vx * Vx), (Uy * Uy + Vy * Vy));
	    double level = Math.log(d) * HALF_INVLOG2;
	    return (float) level*w;
	  }
//  public final static BufferedImage scale(BufferedImage srcImage, int width, int height, boolean bb) {
//      BufferedImage dst = new BufferedImage(width, height,
//          BufferedImage.TYPE_INT_ARGB);
//        double ratio = 0.0;
//        BufferedImage bi =srcImage;
//       if ((bi.getHeight() >= height) || (bi.getWidth() >= width)) {
//           double   ratioHeight = (new Integer(height)).doubleValue()/ bi.getHeight();
//           double   ratioWhidth = (new Integer(width)).doubleValue()/ bi.getWidth();
//           if(ratioHeight>ratioWhidth){
//               ratio= ratioHeight;
//           }else{
//               ratio= ratioWhidth;
//           }
//            AffineTransformOp op = new AffineTransformOp(AffineTransform//����ת��
//                    .getScaleInstance(ratio, ratio), AffineTransformOp.TYPE_BICUBIC);
//             op.filter(bi, dst);//
//            return dst;
//        }
//    return null;
//  }
  public static BufferedImage scale(BufferedImage originalFile, 
          int newWidth, int newHeight)  {  

      Image i = originalFile;  
      Image resizedImage = null;  

      resizedImage = i.getScaledInstance(newWidth ,  
    		  newHeight, Image.SCALE_AREA_AVERAGING);  


      Image temp = resizedImage;  
      // Create the buffered image.  
      BufferedImage bufferedImage = new BufferedImage(temp.getWidth(null),  
              temp.getHeight(null), BufferedImage.TYPE_INT_ARGB);  

      // Copy image to buffered image.  
      Graphics2D g = bufferedImage.createGraphics(); 
      RenderingHints renderHints =       
    		  new
    		  RenderingHints(RenderingHints.KEY_ANTIALIASING,                          
    		  RenderingHints.VALUE_ANTIALIAS_ON);     
    		  renderHints.put(RenderingHints.KEY_RENDERING,                     
    		  RenderingHints.VALUE_RENDER_QUALITY);
    		  g.setRenderingHints(renderHints);
    		  

//      g.setColor(new Color(0, 0, 0, 0));
      // Clear background and paint the image.  
//      g.fillRect(0, 0, temp.getWidth(null), temp.getHeight(null));  
      g.drawImage(temp, 0, 0, null);  
      g.dispose();  

      // Soften.  
      float softenFactor = 0.05f;  
      float[] softenArray = { 0,  softenFactor*0.5f,             softenFactor,            softenFactor*0.5f,       0, 
    		  0,                  softenFactor*0.5f,        softenFactor,            softenFactor*0.5f,       0, 
    		  softenFactor*0.5f,  softenFactor,                  1 - (softenFactor * 12),  softenFactor,       softenFactor*0.5f, 
			  0,                  softenFactor*0.5f,        softenFactor,            softenFactor*0.5f,       0, 
			    		    0,    softenFactor*0.5f,             softenFactor,            softenFactor*0.5f,       0, 
			    		    };  
      int kernelSize=5;//3
      Kernel kernel = new Kernel(kernelSize, kernelSize, softenArray); 
      ConvolveOp cOp = new ConvolveOp(kernel, ConvolveOp.EDGE_NO_OP, renderHints);
//      bufferedImage = cOp.filter(bufferedImage, null);  

      return (bufferedImage);  
  } // Example usage
}
