package soft3d;

public class Material {

	public float[] ambient;
	public float[] diffuse;
	public float[] specular;
	public float shininess;
	public float[] emission;
}
