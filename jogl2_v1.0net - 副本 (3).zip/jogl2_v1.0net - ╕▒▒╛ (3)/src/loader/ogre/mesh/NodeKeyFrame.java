package loader.ogre.mesh;

public class NodeKeyFrame {
	public float time;
	public float[] rotation;
	public float[] translate;
	public float[] scale;
}
