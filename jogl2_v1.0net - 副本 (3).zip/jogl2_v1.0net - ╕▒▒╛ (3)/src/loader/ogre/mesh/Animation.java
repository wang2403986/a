package loader.ogre.mesh;

import java.util.ArrayList;
import java.util.List;

public class Animation {
	public String name;
	public float length;
	
	public List<NodeAnimationTrack> nodeAnimationTracks=new ArrayList<NodeAnimationTrack>();
}
