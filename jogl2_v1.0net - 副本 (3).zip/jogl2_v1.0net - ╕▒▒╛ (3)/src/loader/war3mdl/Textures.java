package loader.war3mdl;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import com.sun.opengl.util.texture.Texture;

public class Textures {
	public List<String> imageNames;
	public List<Texture> texArray;
	public void create(BufferedReader br) throws IOException {
		TokenStack s=new TokenStack();
		s.begin();
		StringTokenizer tokenizer;
		String line=null;
		while((line=br.readLine())!=null){
			line=line.trim();
			if(s.end(line))break;
			String v;
			
			if (line.startsWith("Bitmap")) {
				if (imageNames==null) {
					imageNames=new ArrayList<String>();
				}
				line=br.readLine().trim();
				imageNames.add(line.split("\"")[1].trim());
			}
		}
	}

}
